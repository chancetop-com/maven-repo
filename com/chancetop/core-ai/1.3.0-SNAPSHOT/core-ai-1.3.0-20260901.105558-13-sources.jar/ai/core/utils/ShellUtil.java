package ai.core.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * @author stephen
 */
public class ShellUtil {
    private static final Set<String> UNIX_SHELLS = Set.of("zsh", "bash", "sh");
    private static final List<String> WINDOWS_NATIVE_SHELLS = List.of("pwsh.exe", "powershell.exe", "cmd.exe");
    private static final String POWERSHELL_ENCODING_SETUP = "$OutputEncoding=[System.Text.UTF8Encoding]::new();[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new();";

    public static boolean isCommandExists(Platform os, String command) {
        try {
            return switch (os) {
                case LINUX_X64, MACOS_X64 -> run(List.of("which", command)) == 0;
                case WINDOWS_X64 -> run(List.of("where.exe", command)) == 0;
                default -> false;
            };
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static int run(List<String> commands) {
        try {
            var process = Runtime.getRuntime().exec(commands.toArray(String[]::new));
            return process.waitFor();
        } catch (IOException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static String execute(List<String> commands, Path workDir) {
        try {
            var process = new ProcessBuilder(commands)
                    .directory(workDir.toFile())
                    .redirectErrorStream(true)
                    .start();
            return readProcessOutput(process);
        } catch (Exception e) {
            return "";
        }
    }

    private static String readProcessOutput(Process process) throws Exception {
        try (var reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
            var sb = new StringBuilder();
            String line = reader.readLine();
            while (line != null) {
                if (!sb.isEmpty()) sb.append('\n');
                sb.append(line);
                line = reader.readLine();
            }
            process.waitFor(5, TimeUnit.SECONDS);
            return sb.toString().trim();
        }
    }

    public static String getPreferredShell(Platform os) {
        return switch (os) {
            case WINDOWS_X64 -> getWindowsPreferredShell();
            case LINUX_X64, MACOS_X64 -> getFirstExistsShell(os, UNIX_SHELLS);
            default -> throw new RuntimeException("Unsupported OS: " + os);
        };
    }

    private static String getWindowsPreferredShell() {
//        // Prefer Unix-like shells (Git Bash, MSYS2, Cygwin, WSL) on Windows
//        // when available, then fall back to Windows native shells.
//        for (var shell : UNIX_SHELLS) {
//            if (isCommandExists(Platform.WINDOWS_X64, shell)) {
//                return shell;
//            }
//        }
        return getFirstExistsShell(Platform.WINDOWS_X64, WINDOWS_NATIVE_SHELLS);
    }

    private static String getFirstExistsShell(Platform os, java.util.Collection<String> shells) {
        return shells.stream().filter(v -> isCommandExists(os, v)).findFirst().orElseThrow();
    }

    private static boolean isUnixShell(String shell) {
        return UNIX_SHELLS.contains(shell);
    }

    public static boolean isPowerShell(String shell) {
        return shell != null && (shell.contains("pwsh") || shell.contains("powershell"));
    }

    public static String getPreferredShellCommandPrefix(Platform os) {
        var shell = getPreferredShell(os);
        if (isUnixShell(shell)) {
            return shell + " -c ";
        }
        if (isPowerShell(shell)) {
            return shell + " -NoProfile -Command ";
        }
        return shell + " /c ";
    }

    public static String wrapCommand(String shell, String command) {
        if (command != null && isPowerShell(shell)) {
            return POWERSHELL_ENCODING_SETUP + command;
        }
        return command;
    }
}
