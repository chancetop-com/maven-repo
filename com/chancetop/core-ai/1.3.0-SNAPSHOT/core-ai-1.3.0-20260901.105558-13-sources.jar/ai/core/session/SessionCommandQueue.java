package ai.core.session;

import ai.core.agent.AttachedContent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Session-level priority command queue.
 * USER_INPUT has higher priority than TASK_NOTIFICATION.
 * drainSameMode() ensures messages of different modes are never mixed in one batch.
 */
public class SessionCommandQueue {

    private final Queue<QueuedCommand> queue = new PriorityQueue<>(
            Comparator.comparingInt(a -> a.mode().priority)
    );
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition notEmpty = lock.newCondition();

    public void enqueueUserInput(String value, Map<String, Object> variables) {
        enqueueUserInput(value, variables, null);
    }

    public void enqueueUserInput(String value, Map<String, Object> variables, List<AttachedContent> attachedContents) {
        enqueue(new QueuedCommand(CommandMode.USER_INPUT, new QueuedMessage(value, variables, attachedContents)));
    }

    public void enqueueTaskNotification(String value) {
        enqueue(new QueuedCommand(CommandMode.TASK_NOTIFICATION, new QueuedMessage(value, null, null)));
    }

    private void enqueue(QueuedCommand command) {
        lock.lock();
        try {
            queue.add(command);
            notEmpty.signalAll();
        } finally {
            lock.unlock();
        }
    }

    /**
     * Drains all commands of the highest-priority mode present in the queue.
     * Returns a CommandBatch with the shared mode and all values.
     */
    public CommandBatch drainSameMode() {
        lock.lock();
        try {
            if (queue.isEmpty()) return new CommandBatch(null, List.of());
            var targetMode = queue.peek().mode();
            var values = new ArrayList<QueuedMessage>();
            while (!queue.isEmpty() && queue.peek().mode() == targetMode) {
                values.add(queue.poll().value());
            }
            return new CommandBatch(targetMode, values);
        } finally {
            lock.unlock();
        }
    }

    /**
     * Blocks until the queue is non-empty. Zero CPU consumption.
     */
    public void awaitNonEmpty() throws InterruptedException {
        lock.lock();
        try {
            while (queue.isEmpty()) {
                notEmpty.await();
            }
        } finally {
            lock.unlock();
        }
    }

    /**
     * Blocks until the queue is non-empty or the timeout expires.
     * Returns true if the queue is non-empty, false if timeout expired.
     */
    public boolean awaitNonEmpty(long timeout, TimeUnit unit) throws InterruptedException {
        var deadline = System.nanoTime() + unit.toNanos(timeout);
        lock.lock();
        try {
            while (queue.isEmpty()) {
                var remaining = deadline - System.nanoTime();
                if (remaining <= 0) {
                    return false;
                }
                notEmpty.await(remaining, TimeUnit.NANOSECONDS);
            }
            return true;
        } finally {
            lock.unlock();
        }
    }

    public boolean isEmpty() {
        lock.lock();
        try {
            return queue.isEmpty();
        } finally {
            lock.unlock();
        }
    }

    /**
     * Removes all TASK_NOTIFICATION commands from the queue.
     * Called after a turn is cancelled to prevent stale task notifications
     * from spawning spurious turns.
     */
    public void drainTaskNotifications() {
        lock.lock();
        try {
            queue.removeIf(cmd -> cmd.mode() == CommandMode.TASK_NOTIFICATION);
        } finally {
            lock.unlock();
        }
    }

    public enum CommandMode {
        USER_INPUT(0),
        TASK_NOTIFICATION(1);

        final int priority;

        CommandMode(int priority) {
            this.priority = priority;
        }
    }

    public record QueuedMessage(String value, Map<String, Object> variables, List<AttachedContent> attachedContents) {

    }

    public record QueuedCommand(CommandMode mode, QueuedMessage value) {

    }

    public record CommandBatch(CommandMode mode, List<QueuedMessage> values) {
        public boolean isEmpty() {
            return values.isEmpty();
        }
    }
}
