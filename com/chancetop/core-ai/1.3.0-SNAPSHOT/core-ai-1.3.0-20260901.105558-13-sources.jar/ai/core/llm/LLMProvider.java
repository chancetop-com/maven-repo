package ai.core.llm;

import ai.core.agent.AttachedContent;
import ai.core.agent.internal.AgentHelper;
import ai.core.llm.streaming.AsyncStreamingCallback;
import ai.core.llm.streaming.BufferedStreamingCallback;
import ai.core.llm.streaming.DefaultStreamingCallback;
import ai.core.llm.streaming.StreamingCallback;
import ai.core.llm.domain.CaptionImageRequest;
import ai.core.llm.domain.CaptionImageResponse;
import ai.core.llm.domain.CompletionRequest;
import ai.core.llm.domain.CompletionResponse;
import ai.core.llm.domain.Content;
import ai.core.llm.domain.EmbeddingRequest;
import ai.core.llm.domain.EmbeddingResponse;
import ai.core.llm.domain.FinishReason;
import ai.core.llm.domain.Message;
import ai.core.llm.domain.RerankingRequest;
import ai.core.llm.domain.RerankingResponse;
import ai.core.llm.domain.ResponseFormat;
import ai.core.llm.domain.RoleType;
import ai.core.llm.domain.StreamOptions;
import ai.core.telemetry.LLMTracer;
import ai.core.utils.JsonUtil;
import core.framework.util.Strings;
import io.opentelemetry.api.trace.SpanContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * @author stephen
 */
public abstract class LLMProvider {
    private static final Logger LOGGER = LoggerFactory.getLogger(LLMProvider.class);
    private static final Pattern IMAGE_REJECTION_PATTERN = Pattern.compile(
            "unknown variant .{0,2}image_url|image[ _a-z]{0,24}not supported|does not support image", Pattern.CASE_INSENSITIVE);
    private static final Set<String> UNKNOWN_MODALITY_WARNED = ConcurrentHashMap.newKeySet();
    protected LLMTracer tracer;
    protected ModelModalityRegistry modalityRegistry = SeedModelModalityRegistry.INSTANCE;
    public LLMProviderConfig config;

    public LLMProvider(LLMProviderConfig config) {
        this.config = config;
    }

    public void setModalityRegistry(ModelModalityRegistry modalityRegistry) {
        this.modalityRegistry = modalityRegistry;
    }

    public ModelModalityRegistry getModalityRegistry() {
        return modalityRegistry;
    }

    public void setConfig(LLMProviderConfig config) {
        this.config = config;
    }

    public void setTracer(LLMTracer tracer) {
        this.tracer = tracer;
    }

    public LLMTracer getTracer() {
        return tracer;
    }

    public final <T> T completionFormatAttachedContent(String systemPrompt, String query, AttachedContent attachedContent, String model, Class<T> clazz) {
        return completionFormatAttachedContent(systemPrompt, query, attachedContent, model, clazz, null);
    }

    public final <T> T completionFormatAttachedContent(String systemPrompt, String query, AttachedContent attachedContent, String model, Class<T> clazz, Integer timeoutSeconds) {
        var request = CompletionRequest.of(new CompletionRequest.CompletionRequestOptions(
                List.of(Message.of(RoleType.SYSTEM, systemPrompt),
                        AgentHelper.buildUserMessage(query, attachedContent)),
                null,
                null,
                model,
                null,
                Boolean.FALSE,
                ResponseFormat.of(clazz),
                null
        ));
        request.setTimeoutSeconds(timeoutSeconds);
        return completionFormat(request, clazz);
    }

    public final <T> T completionFormat(String systemPrompt, String userPrompt, String model, Class<T> clazz) {
        return completionFormat(systemPrompt, userPrompt, model, clazz, null);
    }

    public final <T> T completionFormat(String systemPrompt, String userPrompt, String model, Class<T> clazz, Integer timeoutSeconds) {
        return completionFormat(systemPrompt, userPrompt, model, clazz, ResponseFormat.of(clazz), timeoutSeconds);
    }

    public final <T> T completionFormat(String systemPrompt, String userPrompt, String model, Class<T> clazz, ResponseFormat responseFormat, Integer timeoutSeconds) {
        var request = CompletionRequest.of(new CompletionRequest.CompletionRequestOptions(
                List.of(Message.of(RoleType.SYSTEM, systemPrompt),
                        Message.of(RoleType.USER, userPrompt)),
                null,
                null,
                model,
                null,
                Boolean.FALSE,
                responseFormat,
                null
        ));
        request.setTimeoutSeconds(timeoutSeconds);
        return completionFormat(request, clazz);
    }

    public <T> T completionFormat(CompletionRequest request, Class<T> clazz) {
        var response = completion(request);
        var content = response.choices.getFirst().message.content;
        return JsonUtil.fromJson(clazz, content);
    }

    public final CompletionResponse completion(CompletionRequest request) {
        return completionStream(request, new DefaultStreamingCallback());
    }

    public final CompletionResponse completionStream(CompletionRequest request, StreamingCallback callback) {
        return completionStream(request, callback, null);
    }

    public final CompletionResponse completionStream(CompletionRequest request, StreamingCallback callback, Consumer<SpanContext> llmSpanContextSink) {
        return completionStream(request, callback, llmSpanContextSink, true);
    }

    public final CompletionResponse completionStream(CompletionRequest request, StreamingCallback callback, Consumer<SpanContext> llmSpanContextSink, boolean withTracing) {
        request.model = getModel(request);
        enforceModalities(request);
        preprocess(request);
        request.stream = Boolean.TRUE;
        request.streamOptions = new StreamOptions();
        if (request.getExtraBody() != null && config.resolveExtraBody(request.model) != null) {
            LOGGER.warn("both request and provider config set extra body, provider config extra body will be ignored, request extra body={}, config extra body={}", request.getExtraBody(), config.resolveExtraBody(request.model));
        }
        var wrappedCallback = wrapCallback(callback);
        CompletionResponse response;
        try {
            response = invokeCompletionStream(request, wrappedCallback, llmSpanContextSink, withTracing);
        } catch (RuntimeException e) {
            if (request.isPassthrough() || !shouldRetryWithoutImages(request, e)) throw e;
            // safe to reuse the wrapped callback: image-rejection 400s fail at connection time,
            // before any SSE data reaches the callback; mid-stream failures never match the pattern check above
            LOGGER.warn("upstream rejected image input, marking model={} as text-only and retrying downgraded, error={}", request.model, e.getMessage());
            ModalityRuntimeOverrides.markUnsupported(request.model, InputModality.IMAGE);
            enforceModalities(request);
            response = invokeCompletionStream(request, wrappedCallback, llmSpanContextSink, withTracing);
        }
        postprocess(request, response);
        return response;
    }

    private CompletionResponse invokeCompletionStream(CompletionRequest request, StreamingCallback wrappedCallback, Consumer<SpanContext> llmSpanContextSink, boolean withTracing) {
        if (tracer != null && withTracing) {
            return tracer.traceLLMCompletion(name(), request, () -> doCompletionStream(request, wrappedCallback), llmSpanContextSink, wrappedCallback::isCancelled);
        }
        return doCompletionStream(request, wrappedCallback);
    }

    private void enforceModalities(CompletionRequest request) {
        if (request.isPassthrough()) return;
        var result = ModalityEnforcer.enforce(request.messages, request.model, modalityRegistry);
        if (result.downgradedCount() > 0) {
            LOGGER.warn("downgraded {} content part(s) not supported by model={}", result.downgradedCount(), request.model);
        }
        if (result.unknownModalityPresent() && UNKNOWN_MODALITY_WARNED.add(request.model)) {
            LOGGER.warn("model modality unknown, passing non-text content through, model={}", request.model);
        }
        request.messages = result.messages();
    }

    private boolean shouldRetryWithoutImages(CompletionRequest request, RuntimeException e) {
        if (e.getMessage() == null || !IMAGE_REJECTION_PATTERN.matcher(e.getMessage()).find()) return false;
        return request.messages != null && request.messages.stream().anyMatch(message -> message.content != null
                && message.content.stream().anyMatch(part -> part.type == Content.ContentType.IMAGE_URL));
    }

    private StreamingCallback wrapCallback(StreamingCallback callback) {
        int bufferSize = config.getStreamBufferSize();
        if (bufferSize <= 0) return new AsyncStreamingCallback(callback);
        return new BufferedStreamingCallback(new AsyncStreamingCallback(callback), bufferSize);
    }

    public void preprocess(CompletionRequest dto) {
        dto.temperature = dto.temperature != null ? dto.temperature : config.getTemperature();
        if (dto.model.startsWith("o1") || dto.model.startsWith("o3")) {
            dto.temperature = null;
        }
        if (dto.model.contains("gpt-5")) {
            dto.temperature = 1.0;
        }
        dto.messages.forEach(message -> {
            message.name = null;
            if (message.role == RoleType.SYSTEM && dto.model.startsWith("o1")) {
                message.role = RoleType.USER;
            }
            if (message.toolCalls != null && message.toolCalls.isEmpty()) {
                message.toolCalls = null;
            }
        });
    }

    private void postprocess(CompletionRequest request, CompletionResponse response) {
        // todo: reasoning effort finish reason handling can be more generic
        var m = response.choices.getFirst().message;
        // gpt-5.1 also tool call return finish reason stop
        if (m.toolCalls != null && !m.toolCalls.isEmpty()) {
            response.choices.getFirst().finishReason = FinishReason.TOOL_CALLS;
        }
        if (request.model.contains("gpt-5") && !Strings.isBlank(m.reasoningContent)) {
            m.content = Strings.format("<think>{}</think>\n{}", m.reasoningContent, m.content);
        }
    }

    protected abstract CompletionResponse doCompletion(CompletionRequest request);

    protected abstract CompletionResponse doCompletionStream(CompletionRequest request, StreamingCallback callback);

    public abstract EmbeddingResponse embeddings(EmbeddingRequest request);

    public abstract RerankingResponse rerankings(RerankingRequest request);

    public abstract CaptionImageResponse captionImage(CaptionImageRequest request);

    public int maxTokens() {
        var info = LLMModelContextRegistry.getInstance().getModelInfo(config.getModel());
        return info != null ? info.contextWindow() : 0;
    }

    public abstract String name();

    public String getModel(CompletionRequest request) {
        return Strings.isBlank(request.model) ? config.getModel() : request.model;
    }
}
