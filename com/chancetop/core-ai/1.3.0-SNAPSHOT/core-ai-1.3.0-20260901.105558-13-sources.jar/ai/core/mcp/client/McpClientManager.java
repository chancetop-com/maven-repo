package ai.core.mcp.client;

import ai.core.tool.ToolCallResult;
import io.modelcontextprotocol.spec.McpSchema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serial;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author stephen
 */
public class McpClientManager implements AutoCloseable {
    private static final Logger LOGGER = LoggerFactory.getLogger(McpClientManager.class);

    @SuppressWarnings("unchecked")
    public static McpClientManager fromConfig(Map<String, Object> mcpServersConfig) {
        var manager = new McpClientManager();
        for (var entry : mcpServersConfig.entrySet()) {
            if (entry.getValue() instanceof Map<?, ?> serverConfig) {
                var config = McpServerConfig.fromMap(entry.getKey(), (Map<String, Object>) serverConfig);
                manager.addServer(config);
            }
        }
        manager.registerShutdownHook();
        return manager;
    }

    public static McpClientManager of(List<McpServerConfig> configs) {
        var manager = new McpClientManager();
        for (var config : configs) {
            manager.addServer(config);
        }
        manager.registerShutdownHook();
        return manager;
    }

    public static McpClientManager of(McpServerConfig... configs) {
        return of(List.of(configs));
    }

    private final Map<String, McpServerConfig> configs = new ConcurrentHashMap<>();
    private final Map<String, McpClientService> clients = new ConcurrentHashMap<>();
    private final Map<String, ConnectionState> states = new ConcurrentHashMap<>();
    private final Map<String, Object> locks = new ConcurrentHashMap<>();
    private final List<ConnectionStateListener> listeners = new CopyOnWriteArrayList<>();
    private final Object connectionMonitorLock = new Object();
    private McpConnectionMonitor connectionMonitor;
    private volatile boolean connectionMonitorInitialized = false;
    private Thread shutdownHook;
    private volatile boolean closed = false;

    private McpConnectionMonitor getConnectionMonitor() {
        if (!connectionMonitorInitialized) {
            synchronized (connectionMonitorLock) {
                if (!connectionMonitorInitialized) {
                    this.connectionMonitor = new McpConnectionMonitor(
                        () -> configs,
                        () -> clients,
                        this::getState,
                        this::handleDisconnection,
                        new ManagerReconnectCallback()
                    );
                    connectionMonitorInitialized = true;
                }
            }
        }
        return connectionMonitor;
    }

    public void addServer(McpServerConfig config) {
        String name = config.getName();
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Server config must have a name");
        }
        configs.put(name, config);
        states.put(name, ConnectionState.NOT_CONNECTED);
        locks.put(name, new Object());
        getConnectionMonitor().addServer(name);
        LOGGER.debug("Added MCP server config: {}", name);
    }

    public void removeServer(String serverName) {
        getConnectionMonitor().removeServer(serverName);
        closeClient(serverName);
        configs.remove(serverName);
        states.remove(serverName);
        locks.remove(serverName);
        LOGGER.debug("Removed MCP server: {}", serverName);
    }

    public Set<String> getServerNames() {
        return Set.copyOf(configs.keySet());
    }

    public boolean hasServer(String serverName) {
        return configs.containsKey(serverName);
    }

    public McpClientService getClient(String serverName) {
        var config = configs.get(serverName);
        if (config == null) {
            throw new IllegalArgumentException("Server not configured: " + serverName);
        }

        var existingClient = clients.get(serverName);
        if (existingClient != null) {
            return existingClient;
        }

        // short-circuit when ConnectionMonitor is already driving recovery: callers must not trigger another
        // createClient() because each attempt allocates native resources (HttpClient/SSE stream/stdio process)
        var currentState = getState(serverName);
        if (currentState == ConnectionState.FAILED || currentState == ConnectionState.RECONNECTING) {
            throw new McpClientException("MCP server " + serverName + " unavailable, state=" + currentState, null);
        }

        var lock = locks.get(serverName);
        synchronized (lock) {
            existingClient = clients.get(serverName);
            if (existingClient != null) return existingClient;
            currentState = getState(serverName);
            if (currentState == ConnectionState.FAILED || currentState == ConnectionState.RECONNECTING) {
                throw new McpClientException("MCP server " + serverName + " unavailable, state=" + currentState, null);
            }
            return createClient(serverName, config);
        }
    }

    public Optional<McpClientService> getClientIfPresent(String serverName) {
        return Optional.ofNullable(clients.get(serverName));
    }

    public ConnectionState getState(String serverName) {
        return states.getOrDefault(serverName, ConnectionState.NOT_CONNECTED);
    }

    public Map<String, ConnectionState> getAllStates() {
        return Map.copyOf(states);
    }

    public void warmup() {
        LOGGER.debug("Warming up {} MCP clients...", configs.size());
        configs.keySet().parallelStream().forEach(serverName -> {
            try {
                getClient(serverName);
            } catch (Exception e) {
                LOGGER.warn("Failed to warmup client: {}", serverName, e);
            }
        });
        LOGGER.debug("MCP clients warmup completed");

        boolean anyHeartbeatEnabled = configs.values().stream()
            .anyMatch(McpServerConfig::isEnableHeartbeat);
        if (anyHeartbeatEnabled) {
            startHeartbeat();
        }
    }

    public void startHeartbeat() {
        getConnectionMonitor().startHeartbeat();
    }

    public void stopHeartbeat() {
        getConnectionMonitor().stopHeartbeat();
    }

    public void reconnect(String serverName) {
        if (!configs.containsKey(serverName)) {
            throw new IllegalArgumentException("Server not configured: " + serverName);
        }
        LOGGER.debug("Manual reconnect requested for server: {}", serverName);
        getConnectionMonitor().resetReconnectAttempts(serverName);
        handleDisconnection(serverName);
        var config = configs.get(serverName);
        if (config != null && !config.isAutoReconnect()) {
            getConnectionMonitor().scheduleReconnect(serverName);
        }
    }

    public boolean isReconnecting(String serverName) {
        return states.get(serverName) == ConnectionState.RECONNECTING;
    }

    public Map<String, McpClientService> getAllClients() {
        return Map.copyOf(clients);
    }

    public List<String> safeListToolNames(String serverName) {
        return safeListTools(serverName).stream().map(McpSchema.Tool::name).toList();
    }

    public List<McpSchema.Tool> safeListTools(String serverName) {
        return safeListTools(serverName, null);
    }

    public List<McpSchema.Tool> safeListTools(String serverName, List<String> namespaces) {
        try {
            return getClient(serverName).listTools(namespaces);
        } catch (McpClientException first) {
            LOGGER.warn("MCP listTools failed for {}, sync reconnect once: {}", serverName, first.getMessage());
            handleDisconnection(serverName);
            if (!reconnectNow(serverName)) {
                throw first;
            }
            getConnectionMonitor().resetReconnectAttempts(serverName);
            return getClient(serverName).listTools(namespaces);
        }
    }

    public ToolCallResult safeCallTool(String serverName, String name, String text) {
        try {
            return getClient(serverName).callToolWithResult(name, text);
        } catch (McpClientException e) {
            LOGGER.warn("MCP callTool failed for {}/{}, scheduling reconnect: {}", serverName, name, e.getMessage());
            if (clients.containsKey(serverName)) {
                handleDisconnection(serverName);
                getConnectionMonitor().scheduleReconnect(serverName);
            }
            return ToolCallResult.failed("MCP server " + serverName + " unavailable: " + e.getMessage());
        } catch (Exception e) {
            // Application-level error (e.g., HTTP 405 from MCP server, invalid tool name) —
            // do NOT trigger reconnection, just return the failure result
            LOGGER.warn("MCP callTool failed for {}/{}: {}", serverName, name, e.getMessage());
            return ToolCallResult.failed("MCP tool call failed: " + e.getMessage());
        }
    }

    private boolean reconnectNow(String serverName) {
        var config = configs.get(serverName);
        if (config == null) return false;
        try {
            updateState(serverName, ConnectionState.CONNECTING);
            var client = new McpClientService(config);
            clients.put(serverName, client);
            updateState(serverName, ConnectionState.CONNECTED);
            return true;
        } catch (Exception e) {
            LOGGER.warn("Sync reconnect failed for server {}: {}", serverName, e.getMessage());
            updateState(serverName, ConnectionState.FAILED);

            // Check if this is an authentication/permission error — retrying will never succeed,
            // so mark the server as permanently failed to prevent reconnect storms.
            if (isAuthError(e)) {
                getConnectionMonitor().markPermanentlyFailed(serverName);
                LOGGER.error("Permanent failure for server {}: reconnection stopped due to authentication error. Check the MCP server configuration (credentials, session ID, etc.).", serverName);
            }

            return false;
        }
    }

    /**
     * Determine whether the exception is caused by an authentication/permission error
     * that cannot be resolved by retrying the connection.
     */
    private boolean isAuthError(Exception e) {
        String message = e.getMessage();
        if (message == null) {
            var cause = e.getCause();
            if (cause != null) {
                message = cause.getMessage();
            }
        }
        if (message == null) return false;
        var lower = message.toLowerCase(Locale.ENGLISH);
        return lower.contains("401") || lower.contains("unauthorized")
            || lower.contains("session id is required") || lower.contains("403")
            || lower.contains("forbidden") || lower.contains("authentication failed")
            || lower.contains("auth failed");
    }

    public void addListener(ConnectionStateListener listener) {
        listeners.add(listener);
    }

    public void removeListener(ConnectionStateListener listener) {
        listeners.remove(listener);
    }

    public void closeClient(String serverName) {
        var client = clients.remove(serverName);
        if (client != null) {
            try {
                client.close();
                updateState(serverName, ConnectionState.DISCONNECTED);
                LOGGER.debug("Closed MCP client: {}", serverName);
            } catch (Exception e) {
                updateState(serverName, ConnectionState.FAILED);
                LOGGER.warn("Error closing MCP client: {}", serverName, e);
            }
        }
    }

    @Override
    public void close() {
        if (closed) {
            return;
        }
        closed = true;
        LOGGER.debug("Closing McpClientManager with {} clients...", clients.size());
        getConnectionMonitor().close();
        for (String serverName : List.copyOf(clients.keySet())) {
            closeClient(serverName);
        }
        listeners.clear();
        removeShutdownHook();
        disposeReactorSchedulers();
        LOGGER.debug("McpClientManager closed");
    }

    private void handleDisconnection(String serverName) {
        var client = clients.remove(serverName);
        if (client != null) {
            try {
                client.close();
            } catch (Exception e) {
                LOGGER.warn("Error closing disconnected client: {}", serverName, e);
            }
        }
        updateState(serverName, ConnectionState.DISCONNECTED);
    }

    private void disposeReactorSchedulers() {
        try {
            reactor.core.scheduler.Schedulers.shutdownNow();
            LOGGER.debug("Reactor schedulers shut down");
        } catch (Exception e) {
            LOGGER.warn("Error shutting down Reactor schedulers: {}", e.getMessage());
        }
    }

    // Register a JVM shutdown hook as a safety net for MCP subprocess cleanup.
    // Note: GraalVM native-image may not guarantee orderly shutdown hook execution
    // on SIGINT (Ctrl+C). CliApp also registers a separate shutdown hook that calls
    // closeShutdownResources(), which in turn calls McpClientManager.close(), as an
    // additional layer of defense.
    void registerShutdownHook() {
        shutdownHook = new Thread(() -> {
            if (!closed) {
                LOGGER.debug("JVM shutdown hook triggered, closing McpClientManager...");
                close();
            }
        }, "mcp-client-shutdown-hook");
        Runtime.getRuntime().addShutdownHook(shutdownHook);
    }

    private void removeShutdownHook() {
        if (shutdownHook != null) {
            try {
                Runtime.getRuntime().removeShutdownHook(shutdownHook);
            } catch (IllegalStateException e) {
                LOGGER.info("Failed to remove shutdown hook, JVM is shutting down");
            }
            shutdownHook = null;
        }
    }

    private McpClientService createClient(String serverName, McpServerConfig config) {
        updateState(serverName, ConnectionState.CONNECTING);
        try {
            var client = new McpClientService(config);
            clients.put(serverName, client);
            updateState(serverName, ConnectionState.CONNECTED);
            getConnectionMonitor().resetReconnectAttempts(serverName);
            LOGGER.debug("Created MCP client: {}, transport: {}", serverName, config.getTransportType());
            return client;
        } catch (Exception e) {
            updateState(serverName, ConnectionState.FAILED);
            // hand initial failure off to ConnectionMonitor so future retries follow exponential backoff
            // instead of the caller (e.g. scheduled job) hammering createClient every fixed interval
            if (!closed && config.isAutoReconnect()) {
                scheduleReconnectSafely(serverName);
            }
            throw new McpClientException("Failed to create client for server: " + serverName, e);
        }
    }

    private void scheduleReconnectSafely(String serverName) {
        try {
            getConnectionMonitor().scheduleReconnect(serverName);
        } catch (Exception e) {
            LOGGER.warn("Failed to schedule reconnect for {}: {}", serverName, e.getMessage());
        }
    }

    private void updateState(String serverName, ConnectionState newState) {
        var oldState = states.put(serverName, newState);
        if (oldState != newState) {
            notifyListeners(serverName, oldState, newState);
        }
    }

    private void notifyListeners(String serverName, ConnectionState oldState, ConnectionState newState) {
        for (var listener : listeners) {
            try {
                listener.onStateChanged(serverName, oldState, newState);
            } catch (Exception e) {
                LOGGER.warn("Error notifying listener for server: {}", serverName, e);
            }
        }
    }

    public enum ConnectionState {
        NOT_CONNECTED,
        CONNECTING,
        CONNECTED,
        DISCONNECTED,
        RECONNECTING,
        FAILED
    }

    @FunctionalInterface
    public interface ConnectionStateListener {
        void onStateChanged(String serverName, ConnectionState oldState, ConnectionState newState);
    }

    public static class McpClientException extends RuntimeException {
        @Serial
        private static final long serialVersionUID = -1002912289095930440L;

        public McpClientException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    private final class ManagerReconnectCallback implements McpConnectionMonitor.ReconnectCallback {
        @Override
        public void onReconnecting(String serverName) {
            updateState(serverName, ConnectionState.RECONNECTING);
        }

        @Override
        public boolean attemptReconnect(String serverName, McpServerConfig config) {
            return reconnectNow(serverName);
        }

        @Override
        public void onReconnectFailed(String serverName) {
            updateState(serverName, ConnectionState.FAILED);
        }
    }
}
