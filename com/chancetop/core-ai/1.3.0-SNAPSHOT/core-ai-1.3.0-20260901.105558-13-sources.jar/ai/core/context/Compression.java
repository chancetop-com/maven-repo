package ai.core.context;

import ai.core.document.Tokenizer;
import ai.core.llm.LLMModelContextRegistry;
import ai.core.llm.LLMProvider;
import ai.core.llm.domain.CompletionRequest;
import ai.core.llm.domain.FunctionCall;
import ai.core.llm.domain.Message;
import ai.core.llm.domain.RoleType;
import ai.core.prompt.Prompts;
import ai.core.utils.MessageTokenCounterUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * @author xander
 */
public class Compression {
    public static final String COMPRESSION_TOOL_NAME = "memory_compress";
    private static final Logger LOGGER = LoggerFactory.getLogger(Compression.class);

    private static final double DEFAULT_TRIGGER_THRESHOLD = 0.8;
    private static final double DEFAULT_TOOL_RESULT_RATIO = 0.5;
    private static final int FALLBACK_MAX_TOOL_RESULT_TOKENS = 64000;
    private static final int FALLBACK_MAX_CONTEXT_TOKENS = 128000;
    private static final int HEAD_TOKENS = 500;
    private static final int TAIL_TOKENS = 500;
    private static final String TEMP_DIR_NAME = "core-ai";
    private static final int DEFAULT_KEEP_RECENT_TURNS = 5;
    private static final int DEFAULT_KEEP_TOKENS = 15000;
    private static final int MIN_SUMMARY_TOKENS = 500;
    private static final int MAX_SUMMARY_TOKENS = 4000;
    private final double triggerThreshold;
    private final int keepRecentTurns;
    private final int keepTokens;
    private final int maxContextTokens;
    private final double toolResultRatio;
    private final int maxToolResultTokens;
    private final LLMProvider llmProvider;
    private final String summaryModel;
    private final List<CompressionListener> listeners = new ArrayList<>();

    public Compression(LLMProvider llmProvider, String agentModel) {
        this(DEFAULT_TRIGGER_THRESHOLD, DEFAULT_KEEP_RECENT_TURNS, DEFAULT_KEEP_TOKENS, llmProvider, agentModel, agentModel);
    }
    public Compression(double triggerThreshold, int keepRecentTurns, LLMProvider llmProvider, String agentModel, String summaryModel) {
        this(triggerThreshold, keepRecentTurns, DEFAULT_KEEP_TOKENS, llmProvider, agentModel, summaryModel);
    }
    public Compression(double triggerThreshold, int keepRecentTurns, int keepMinTokens, LLMProvider llmProvider, String agentModel, String summaryModel) {
        this.triggerThreshold = triggerThreshold;
        this.keepRecentTurns = keepRecentTurns;
        this.keepTokens = keepMinTokens;
        this.toolResultRatio = DEFAULT_TOOL_RESULT_RATIO;
        this.llmProvider = llmProvider;
        this.summaryModel = summaryModel;
        var modelInfo = agentModel != null ? LLMModelContextRegistry.getInstance().getModelInfo(agentModel) : null;
        this.maxContextTokens = modelInfo != null ? modelInfo.contextWindow() : FALLBACK_MAX_CONTEXT_TOKENS;
        this.maxToolResultTokens = calculateMaxToolResultTokens();
    }
    private int calculateMaxToolResultTokens() {
        if (maxContextTokens <= 0) {
            return FALLBACK_MAX_TOOL_RESULT_TOKENS;
        }
        return (int) (maxContextTokens * toolResultRatio);
    }
    public void addListener(CompressionListener listener) {
        this.listeners.add(listener);
    }
    public void setListener(CompressionListener listener) {
        this.listeners.clear();
        this.listeners.add(listener);
    }
    public boolean shouldCompress(int currentTokens) {
        if (llmProvider == null) {
            return false;
        }
        return currentTokens >= (int) (maxContextTokens * triggerThreshold);
    }
    public List<Message> compress(List<Message> messages) {
        if (messages == null || messages.isEmpty() || llmProvider == null) {
            return messages;
        }

        int currentTokens = MessageTokenCounterUtil.count(messages);
        if (!shouldCompress(currentTokens)) {
            return messages;
        }

        LOGGER.debug("Compressing messages: currentTokens={}, threshold={}", currentTokens, (int) (maxContextTokens * triggerThreshold));
        return doCompress(messages, false);
    }
    public List<Message> forceCompress(List<Message> messages) {
        if (messages == null || messages.isEmpty() || llmProvider == null) {
            return messages;
        }
        return doCompress(messages, true);
    }
    private List<Message> doCompress(List<Message> messages, boolean force) {
        var systemMsg = extractSystemMessage(messages);
        var conversationMsgs = extractConversationMessages(messages);

        if (conversationMsgs.size() <= 2) {
            return messages;
        }

        int lastUserIndex = findLastUserIndex(conversationMsgs);
        if (lastUserIndex < 0) {
            return messages;
        }

        int keepFromIndex;
        if (force) {
            keepFromIndex = calculateForceKeepFromIndex(conversationMsgs);
        } else {
            keepFromIndex = calculateKeepFromIndex(conversationMsgs, lastUserIndex);
        }
        if (keepFromIndex <= 0) {
            return messages;
        }

        List<Message> toCompress = new ArrayList<>(conversationMsgs.subList(0, keepFromIndex));
        List<Message> toKeep = new ArrayList<>(conversationMsgs.subList(keepFromIndex, conversationMsgs.size()));
        if (toCompress.isEmpty()) {
            return messages;
        }

        Message preservedUserMsg = findPreservedUserMessage(toCompress, toKeep);
        if (preservedUserMsg != null) {
            toCompress.remove(preservedUserMsg);
        }

        int overhead = 2 + (preservedUserMsg != null ? 1 : 0) + (systemMsg != null ? 1 : 0);
        if (toCompress.size() <= overhead) {
            LOGGER.debug("Too few messages to compress effectively, skipping");
            return messages;
        }

        notifyListener(messages.size(), toCompress.size(), false);
        var summary = summarize(toCompress);
        if (summary.isBlank()) {
            LOGGER.warn("Summarization returned empty result, keeping original messages");
            return messages;
        }

        var result = buildCompressedResult(systemMsg, summary, preservedUserMsg, toKeep);
        if (result.size() >= messages.size()) {
            LOGGER.debug("Compression did not reduce message count, keeping original");
            return messages;
        }
        notifyListener(messages.size(), result.size(), true);
        LOGGER.debug("Compression complete: {} -> {} messages", messages.size(), result.size());
        return result;
    }
    private Message findPreservedUserMessage(List<Message> toCompress, List<Message> toKeep) {
        boolean hasUserInKeep = toKeep.stream().anyMatch(m -> m.role == RoleType.USER);
        if (hasUserInKeep) {
            return null;
        }
        return toCompress.stream()
            .filter(m -> m.role == RoleType.USER)
            .reduce((first, second) -> second)
            .orElse(null);
    }
    private int calculateForceKeepFromIndex(List<Message> conversationMsgs) {
        int accumulatedTokens = 0;
        int keepFromIndex = conversationMsgs.size() - 1;
        for (int i = conversationMsgs.size() - 1; i >= 0; i--) {
            accumulatedTokens += MessageTokenCounterUtil.count(conversationMsgs.get(i));
            if (accumulatedTokens > keepTokens) {
                keepFromIndex = adjustToToolSegmentBoundary(conversationMsgs, i);
                break;
            }
        }
        if (keepFromIndex <= 0) {
            keepFromIndex = Math.max(1, conversationMsgs.size() / 2);
        }
        return keepFromIndex;
    }
    private int adjustToToolSegmentBoundary(List<Message> msgs, int index) {
        for (int i = index; i < msgs.size(); i++) {
            Message msg = msgs.get(i);
            if (msg.role == RoleType.ASSISTANT && (msg.toolCalls == null || msg.toolCalls.isEmpty())) {
                return i;
            }
            if (msg.role == RoleType.USER) {
                return i;
            }
        }
        return index + 1;
    }
    private List<Message> buildCompressedResult(Message systemMsg, String summary, Message preservedUserMsg, List<Message> toKeep) {
        var toolCallId = COMPRESSION_TOOL_NAME + "_" + System.currentTimeMillis();
        var compressCall = FunctionCall.of(toolCallId, "function", COMPRESSION_TOOL_NAME, "{}");
        var toolCallMsg = Message.of(RoleType.ASSISTANT, null, null, null, List.of(compressCall), "");
        var toolResultMsg = Message.of(RoleType.TOOL, summary, COMPRESSION_TOOL_NAME, toolCallId, null);

        var result = new ArrayList<Message>();
        if (systemMsg != null) {
            result.add(systemMsg);
        }
        result.add(toolCallMsg);
        result.add(toolResultMsg);
        if (preservedUserMsg != null) {
            result.add(preservedUserMsg);
        }
        result.addAll(toKeep);
        return ToolCallPruning.dropOrphanToolMessages(result);
    }
    public double getTriggerThreshold() {
        return triggerThreshold;
    }
    public int getKeepRecentTurns() {
        return keepRecentTurns;
    }
    private Message extractSystemMessage(List<Message> messages) {
        return messages.stream()
            .filter(m -> m.role == RoleType.SYSTEM)
            .findFirst()
            .orElse(null);
    }
    private List<Message> extractConversationMessages(List<Message> messages) {
        return messages.stream()
            .filter(m -> m.role != RoleType.SYSTEM)
            .toList();
    }
    private int calculateKeepFromIndex(List<Message> conversationMsgs, int lastUserIndex) {
        var keepFromIndex = findKeepFromIndexByTurnsAndTokens(conversationMsgs, lastUserIndex);
        var tokensFromKeep = MessageTokenCounterUtil.countFrom(conversationMsgs, keepFromIndex);
        var threshold = (int) (maxContextTokens * triggerThreshold);
        if (tokensFromKeep >= threshold) {
            return Math.max(keepFromIndex, conversationMsgs.size() - 1);
        }
        return keepFromIndex;
    }
    private int findLastUserIndex(List<Message> messages) {
        for (int i = messages.size() - 1; i >= 0; i--) {
            if (messages.get(i).role == RoleType.USER) {
                return i;
            }
        }
        return -1;
    }
    private int findKeepFromIndexByTurnsAndTokens(List<Message> conversationMsgs, int lastUserIndex) {
        int turnCount = 0;
        int accumulatedTokens = 0;
        int indexByTurns = lastUserIndex;
        int indexByTokens = 0;
        boolean tokenBudgetExceeded = false;
        boolean pendingTokenSplit = false;

        for (int i = conversationMsgs.size() - 1; i >= 0; i--) {
            Message msg = conversationMsgs.get(i);
            boolean isAssistantWithTools = msg.role == RoleType.ASSISTANT
                && msg.toolCalls != null && !msg.toolCalls.isEmpty();

            if (!tokenBudgetExceeded) {
                accumulatedTokens += MessageTokenCounterUtil.count(msg);
            }
            if (!tokenBudgetExceeded && accumulatedTokens > keepTokens) {
                pendingTokenSplit = msg.role == RoleType.TOOL;
                tokenBudgetExceeded = !pendingTokenSplit;
                indexByTokens = pendingTokenSplit ? indexByTokens : i;
            }

            if (pendingTokenSplit && isAssistantWithTools) {
                indexByTokens = i;
                tokenBudgetExceeded = true;
                pendingTokenSplit = false;
            }

            if (i < lastUserIndex && turnCount < keepRecentTurns) {
                indexByTurns = i;
                turnCount += msg.role == RoleType.USER ? 1 : 0;
            }
        }

        return Math.max(indexByTurns, indexByTokens);
    }
    private String summarize(List<Message> messagesToSummarize) {
        String content = formatMessages(messagesToSummarize);
        if (content.isBlank()) return "";
        int targetTokens = Math.min(MAX_SUMMARY_TOKENS, Math.max(MIN_SUMMARY_TOKENS, maxContextTokens / 10));
        String prompt = String.format(Prompts.COMPRESSION_PROMPT, (int) (targetTokens * 0.75), content);
        String summary = callLLM(prompt);
        if (summary.isBlank()) return "";
        return Prompts.COMPRESSION_SUMMARY_PREFIX + summary + Prompts.COMPRESSION_SUMMARY_SUFFIX;
    }
    private String callLLM(String prompt) {
        try {
            var msgs = List.of(Message.of(RoleType.USER, prompt));
            var request = CompletionRequest.of(msgs, null, 0.3, summaryModel, "memory-compressor");
            var response = llmProvider.completion(request);

            if (response != null && response.choices != null && !response.choices.isEmpty()) {
                var choice = response.choices.getFirst();
                if (choice.message != null && choice.message.content != null) {
                    return choice.message.content.trim();
                }
            }
        } catch (Exception e) {
            LOGGER.error("Failed to call LLM for compression", e);
        }
        return "";
    }
    private String formatMessages(List<Message> messages) {
        StringBuilder sb = new StringBuilder(1024);
        for (Message msg : messages) {
            if (msg.role == RoleType.SYSTEM) {
                continue;
            }

            if (msg.toolCalls != null && !msg.toolCalls.isEmpty()) {
                String toolNames = msg.toolCalls.stream()
                    .map(tc -> tc.function != null ? tc.function.name : "unknown")
                    .collect(java.util.stream.Collectors.joining(", "));
                sb.append("Assistant: [Called tools: ").append(toolNames).append("]\n");
            }

            String joined = msg.getJoinedTextContent();
            String content = joined != null ? joined : "";
            if (!content.isBlank()) {
                String role = switch (msg.role) {
                    case USER -> "User";
                    case ASSISTANT -> "Assistant";
                    case TOOL -> "Tool";
                    default -> "Unknown";
                };
                sb.append(role).append(": ").append(content).append('\n');
            }
        }
        return sb.toString();
    }
    public String compressToolResult(String toolName, String result, String sessionId) {
        if (result == null || result.isEmpty()) {
            return result;
        }

        int tokenCount = Tokenizer.tokenCount(result);

        if (tokenCount <= maxToolResultTokens) {
            return result;
        }

        try {
            Path filePath = writeToolResultToFile(toolName, result, sessionId);
            String summary = buildToolResultSummary(toolName, result, tokenCount, filePath);

            LOGGER.debug("Long tool result from {} saved to file: {} ({} tokens, max: {})",
                toolName, filePath, tokenCount, maxToolResultTokens);

            return summary;
        } catch (IOException e) {
            LOGGER.error("Failed to write long tool result to file, keeping original", e);
            return result;
        }
    }
    public boolean shouldCompressToolResult(String result) {
        if (result == null || result.isEmpty()) {
            return false;
        }
        int tokenCount = Tokenizer.tokenCount(result);
        return tokenCount > maxToolResultTokens;
    }
    private Path writeToolResultToFile(String toolName, String content, String sessionId) throws IOException {
        String sid = sessionId != null ? sessionId : "default";
        Path baseTempDir = Path.of(System.getProperty("java.io.tmpdir"), TEMP_DIR_NAME);
        Path sessionDir = baseTempDir.resolve(sid);

        if (!Files.exists(sessionDir)) {
            Files.createDirectories(sessionDir);
        }

        String fileName = String.format("%s_%d.txt", sanitizeFileName(toolName), Instant.now().toEpochMilli());
        Path filePath = sessionDir.resolve(fileName);
        Files.writeString(filePath, content);
        return filePath;
    }
    private String buildToolResultSummary(String toolName, String content, int tokenCount, Path filePath) {
        String headContent = truncateToTokens(content);
        String tailContent = extractTailTokens(content);

        return String.format("[Tool result truncated - full content saved to file]%n"
            + "Tool: %s%n"
            + "File: %s%n"
            + "Total: %d tokens (exceeds %d token limit)%n%n"
            + "=== HEAD (first %d tokens) ===%n"
            + "%s%n%n"
            + "=== ... truncated ... ===%n%n"
            + "=== TAIL (last %d tokens) ===%n"
            + "%s%n%n"
            + "[WARNING: This is a large file. Do NOT read the full file directly as it will be truncated again."
            + " Use file related tools to read specific parts of the file as needed.],%n"
            + "File path: %s",
            toolName, filePath, tokenCount, maxToolResultTokens,
            HEAD_TOKENS, headContent,
            TAIL_TOKENS, tailContent,
            filePath);
    }
    private String truncateToTokens(String content) {
        List<Integer> tokens = Tokenizer.encode(content);
        if (tokens.size() <= HEAD_TOKENS) {
            return content;
        }
        return Tokenizer.decode(tokens.subList(0, HEAD_TOKENS));
    }
    private String extractTailTokens(String content) {
        List<Integer> tokens = Tokenizer.encode(content);
        if (tokens.size() <= TAIL_TOKENS) {
            return content;
        }
        int startIndex = tokens.size() - TAIL_TOKENS;
        return Tokenizer.decode(tokens.subList(startIndex, tokens.size()));
    }
    private String sanitizeFileName(String name) {
        return name.replaceAll("[^a-zA-Z0-9_-]", "_");
    }
    public int getMaxContextTokens() {
        return maxContextTokens;
    }
    public int getMaxToolResultTokens() {
        return maxToolResultTokens;
    }
    private void notifyListener(int beforeCount, int afterCount, boolean completed) {
        for (CompressionListener l : listeners) {
            l.onCompression(beforeCount, afterCount, completed);
        }
    }
}
