package ai.core.tool.tools;

import ai.core.AgentRuntimeException;
import ai.core.agent.Agent;
import ai.core.agent.ExecutionContext;
import ai.core.agent.Task;
import ai.core.agent.profile.AgentProfile;
import ai.core.agent.profile.AgentProfileRegistry;
import ai.core.defaultagents.DefaultCodeSimplifierAgent;
import ai.core.defaultagents.DefaultExploreAgent;
import ai.core.defaultagents.DefaultGeneralAgent;
import ai.core.defaultagents.DeepResearchAgent;
import ai.core.llm.LLMProvider;
import ai.core.llm.domain.ReasoningEffort;
import ai.core.llm.domain.RoleType;
import ai.core.llm.domain.Tool;
import ai.core.prompt.PromptInject;
import ai.core.tool.ToolCall;
import ai.core.tool.ToolCallParameters;
import ai.core.tool.ToolCallResult;
import ai.core.tool.registry.ToolRegistry;

import java.util.ArrayList;
import java.util.UUID;

/**
 * author: lim chen
 * date: 2026/3/23
 * description: task
 */
public class TaskTool extends ToolCall {
    public static final String TOOL_NAME = "task";
    private static final String TOOL_DESC = """
            Launch a new agent to handle complex, multistep tasks autonomously.

            Available agent types and the tools they have access to:

            %s

            When using the Task tool, you must specify a subagent_type parameter to select which agent type to use.


            Usage notes:
            1. Launch multiple agents concurrently whenever possible, to maximize performance; to do that, use a single message with multiple tool uses
            2. When the agent is done, it will return a single message back to you. The result returned by the agent is not visible to the user. To show the user the result, you should send a text message back to the user with a concise summary of the result. The output includes a task_id you can reuse later to continue the same subagent session.
            3. Each agent invocation starts with a fresh context unless you provide task_id to resume the same subagent session (which continues with its previous messages and tool outputs). When starting fresh, your prompt should contain a highly detailed task description for the agent to perform autonomously and you should specify exactly what information the agent should return back to you in its final and only message to you.
            4. The agent's outputs should generally be trusted
            5. Clearly tell the agent whether you expect it to write code or just to do research (search, file reads, web fetches, etc.), since it is not aware of the user's intent. Tell it how to verify its work if possible (e.g., relevant test commands).
            6. If the agent description mentions that it should be used proactively, then you should try your best to use it without the user having to ask for it first. Use your judgement.

            Example usage (NOTE: The agents below are fictional examples for illustration only - use the actual agents listed above):

            <example_agent_descriptions>
            "code-reviewer": use this agent after you are done writing a significant piece of code
            "greeting-responder": use this agent when to respond to user greetings with a friendly joke
            </example_agent_description>
            
            <example>
            user: "Please write a function that checks if a number is prime"
            assistant: Sure let me write a function that checks if a number is prime
            assistant: First let me use the Write tool to write a function that checks if a number is prime
            assistant: I'm going to use the Write tool to write the following code:
            <code>
            function isPrime(n) {
              if (n <= 1) return false
              for (let i = 2; i * i <= n; i++) {
                if (n % i === 0) return false
              }
              return true
            }
            </code>
            <commentary>
            Since a significant piece of code was written and the task was completed, now use the code-reviewer agent to review the code
            </commentary>
            assistant: Now let me use the code-reviewer agent to review the code
            assistant: Uses the Task tool to launch the code-reviewer agent
            </example>
            
            <example>
            user: "Hello"
            <commentary>
            Since the user is greeting, use the greeting-responder agent to respond with a friendly joke
            </commentary>
            assistant: "I'm going to use the Task tool to launch the with the greeting-responder agent"
            </example>
            
            """;

    public static Builder builder() {
        return new Builder();
    }

    private static String extractLastAssistantText(Agent agent) {
        var messages = agent.getMessages();
        for (int i = messages.size() - 1; i >= 0; i--) {
            var message = messages.get(i);
            if (message.role == RoleType.ASSISTANT) {
                var text = message.getTextContent();
                return text != null ? text : "";
            }
        }
        return "";
    }

    @Override
    public Tool toTool(ExecutionContext context) {
        if (context != null && context.getAgentProfileRegistry() != null) {
            var profiles = context.getAgentProfileRegistry().listAll();
            if (!profiles.isEmpty()) {
                var sb = new StringBuilder();
                for (var profile : profiles) {
                    sb.append("- ").append(profile.name()).append(": ").append(profile.description()).append('\n');
                }
                setDescription(TOOL_DESC.replace("%s", sb.toString()));
            }
        }
        return super.toTool(context);
    }

    @Override
    public long getTimeoutMs() {
        return 30 * 60 * 1000L;
    }

    @Override
    public ToolCallResult execute(String text) {
        throw new AgentRuntimeException("TASK_TOOL_FAILED", "TaskTool requires ExecutionContext");
    }

    @Override
    public ToolCallResult execute(String arguments, ExecutionContext context) {
        long startTime = System.currentTimeMillis();
        try {
            var argsMap = parseArguments(arguments);
            var prompt = getStringValue(argsMap, "prompt");
            var subagentType = getStringValue(argsMap, "subagent_type");
            var runInBackground = Boolean.TRUE.equals(argsMap.get("run_in_background"));

            var taskManager = context.getTaskManager();
            var description = getStringValue(argsMap, "description");
            var taskId = getStringValue(argsMap, "task_id");
            var subContext = buildSubContext(subagentType, context, taskId, description);
            var subAgent = createAgent(subagentType, subContext);
            if (runInBackground && taskManager != null) {
                var model = resolveModel(subagentType, context);
                var handle = taskManager.submit(taskId, () -> {
                    subAgent.run(prompt, subContext);
                    return extractLastAssistantText(subAgent);
                }, context.getCancellationToken());
                taskManager.register(new Task(taskId, description, context.getTaskId(), handle.future(), subContext));
                return ToolCallResult.asyncLaunched(taskId, buildAsyncLaunchedNotificationXml(taskId, handle.outputRef(), description, subagentType, model))
                        .withDuration(System.currentTimeMillis() - startTime);
            } else {
                subAgent.run(prompt, subContext);
                return ToolCallResult.completed(extractLastAssistantText(subAgent))
                        .withDuration(System.currentTimeMillis() - startTime);
            }


        } catch (Exception e) {
            var error = "Failed to parse task tool arguments: " + e.getMessage();
            return ToolCallResult.failed(error, e)
                    .withDuration(System.currentTimeMillis() - startTime);
        }
    }


    private String buildAsyncLaunchedNotificationXml(String taskId, String outputRef, String description, String subagentType, String model) {
        var outputRefXml = outputRef != null ? "<output-ref>" + outputRef + "</output-ref>\n" : "";
        var reminder = "  Async agent launched successfully.%n  agentId: %s (internal ID - do not mention to user. Use SendMessage with to: %s to continue this agent.)%n  The agent is working in the background. You will be notified automatically when it completes.%n  Do not duplicate this agent's work — avoid working with the same files or topics it is using. Work on non-overlapping tasks, or briefly tell the user what you launched and end%n  your response.%n  output_file: %s%n  If asked, you can check progress before completion by using %s or %s tail on the output file.%n".formatted(taskId, taskId, outputRef, ReadFileTool.TOOL_NAME, ShellCommandTool.TOOL_NAME);
        return "<task-notification>%n<task-id>%s</task-id>%n<task-type>%s</task-type>%n<task-description>%s</task-description>%n<task-model>%s</task-model>%n<status>%s</status>%n%s%n<system-reminder>%s</system-reminder>%n</task-notification>%n".formatted(taskId, subagentType, description, model != null ? model : "default", "async_launched", outputRefXml, reminder);
    }

    private ExecutionContext buildSubContext(String subagentType, ExecutionContext context, String taskId, String taskName) {
        var subContext = ExecutionContext.builder()
                .sessionId("subagent:" + subagentType + "-" + System.currentTimeMillis())
                .userId(context.getUserId())
                .caller(context.getCaller())
                .customVariables(context.getCustomVariables())
                .asyncTaskManager(context.getAsyncTaskManager())
                .attachedContent(context.getAttachedContent())
                .persistenceProvider(context.getPersistenceProvider())
                .taskManager(context.getTaskManager() != null ? context.getTaskManager().createChild() : null)
                .promptSections(context.getPromptSections())
                .sandbox(context.getSandbox())
                .taskId(taskId)
                .taskName(taskName)
                .build();
        subContext.setLlmProvider(context.getLlmProvider());
        subContext.setModel(context.getModel());
        subContext.setLifecycles(context.getLifecycle());
        subContext.setTokenCostCallback(context.getTokenCostCallback());
        subContext.setSubAgentConfigs(context.getSubAgentConfigs());
        subContext.setToolRegistry(context.getToolRegistry());
        subContext.setAgentProfileRegistry(context.getAgentProfileRegistry());
        return subContext;
    }

    private Agent createAgent(String subagentType, ExecutionContext context) {
        var llmProvider = resolveLlmProvider(subagentType, context);
        var model = resolveModel(subagentType, context);
        var maxTurnNumber = resolveMaxTurnNumber(subagentType, context);
        var toolRegistry = context.getToolRegistry();
        AgentProfileRegistry profileRegistry = context.getAgentProfileRegistry();
        if (profileRegistry != null) {
            AgentProfile profile = profileRegistry.get(subagentType).orElse(null);
            if (profile != null) {
                return buildAgentFromProfile(profile, llmProvider, model, maxTurnNumber, toolRegistry, context);
            }
            throw new RuntimeException("Unknown subagent type: " + subagentType);
        }
        return createBuiltinAgent(subagentType, llmProvider, model, maxTurnNumber, toolRegistry, context);
    }

    private Agent createBuiltinAgent(String subagentType, LLMProvider llmProvider, String model, int maxTurnNumber, ToolRegistry toolRegistry, ExecutionContext context) {
        if (DeepResearchAgent.AGENT_NAME.equals(subagentType)) {
            return DeepResearchAgent.of(toolRegistry, llmProvider, model, context, maxTurnNumber);
        }
        if (DefaultExploreAgent.AGENT_NAME.equals(subagentType)) {
            return DefaultExploreAgent.of(toolRegistry, llmProvider, model, context, maxTurnNumber);
        }
        if (DefaultCodeSimplifierAgent.AGENT_NAME.equals(subagentType)) {
            return DefaultCodeSimplifierAgent.of(toolRegistry, llmProvider, model, context, maxTurnNumber);
        }
        if (DefaultGeneralAgent.AGENT_NAME.equals(subagentType)) {
            return DefaultGeneralAgent.of(toolRegistry, llmProvider, model, context, maxTurnNumber);
        }
        throw new RuntimeException("Unknown subagent type: " + subagentType);
    }

    private Agent buildAgentFromProfile(AgentProfile profile, LLMProvider llmProvider, String model, int maxTurnNumber, ToolRegistry toolRegistry, ExecutionContext context) {
        var builder = Agent.builder()
                .name(profile.name())
                .description(profile.description())
                .systemPrompt(profile.systemPrompt() != null ? profile.systemPrompt() : "")
                .llmProvider(llmProvider)
                .model(profile.model() != null ? profile.model() : model)
                .maxTurn(profile.maxTurnNumber() != null ? profile.maxTurnNumber() : maxTurnNumber)
                .streamingCallback(context.getStreamingCallback())
                .agentLifecycle(context.getLifecycle())
                .toolRegistry(toolRegistry);
        if (profile.tools() != null && !profile.tools().isEmpty()) {
            builder.toolNames(new ArrayList<>(profile.tools()));
        }
        builder.systemPromptSections(context.getPromptSections().stream()
                .filter(s -> s.type() == PromptInject.SectionType.ENVIRONMENT
                        || s.type() == PromptInject.SectionType.INSTRUCTIONS
                        || s.type() == PromptInject.SectionType.MEMORY)
                .toList());
        if (profile.reasoningEffort() != null) {
            var effort = ReasoningEffort.fromString(profile.reasoningEffort());
            if (effort != null) builder.reasoningEffort(effort);
        }
        if (profile.temperature() != null) {
            builder.temperature(profile.temperature());
        }
        return builder.build();
    }

    private int resolveMaxTurnNumber(String subagentType, ExecutionContext context) {
        var configs = context.getSubAgentConfigs();
        if (configs != null) {
            var config = configs.get(subagentType);
            if (config != null && config.maxTurnNumber() != null) {
                return config.maxTurnNumber();
            }
        }
        return 200;
    }

    private String resolveModel(String subagentType, ExecutionContext context) {
        var configs = context.getSubAgentConfigs();
        if (configs != null) {
            var config = configs.get(subagentType);
            if (config != null && config.model() != null && !config.model().isBlank()) {
                return config.model();
            }
        }
        return context.getModel();
    }

    private LLMProvider resolveLlmProvider(String subagentType, ExecutionContext context) {
        var configs = context.getSubAgentConfigs();
        if (configs != null) {
            var config = configs.get(subagentType);
            if (config != null && config.llmProvider() != null) {
                return config.llmProvider();
            }
        }
        return context.getLlmProvider();
    }

    public static class Builder extends ToolCall.Builder<Builder, TaskTool> {
        @Override
        protected Builder self() {
            return this;
        }

        public TaskTool build() {
            var subagentType = "- "
                    + String.join(":", DeepResearchAgent.AGENT_NAME, DeepResearchAgent.AGENT_DESCRIPTION)
                    + "\n- "
                    + String.join(":", DefaultExploreAgent.AGENT_NAME, DefaultExploreAgent.AGENT_DESCRIPTION)
                    + "\n- "
                    + String.join(":", DefaultCodeSimplifierAgent.AGENT_NAME, DefaultCodeSimplifierAgent.AGENT_DESCRIPTION)
                    + "\n- "
                    + String.join(":", DefaultGeneralAgent.AGENT_NAME, DefaultGeneralAgent.AGENT_DESCRIPTION);
            this.name(TOOL_NAME);
            this.description(TOOL_DESC.replace("%s", subagentType));
            this.parameters(ToolCallParameters.of(
                    ToolCallParameters.ParamSpec.of(String.class, "task_id", "A unique identifier for this task. If not provided, one will be auto-generated.")
                            .optional()
                            .defaultValue(() -> "sa-" + UUID.randomUUID().toString().substring(0, 8)),
                    ToolCallParameters.ParamSpec.of(String.class, "description", "A short (3-5 words) description of the task").required(),
                    ToolCallParameters.ParamSpec.of(String.class, "prompt", "The task for the agent to perform").required(),
                    ToolCallParameters.ParamSpec.of(String.class, "subagent_type", "The type of specialized agent to use for this task").required(),
                    ToolCallParameters.ParamSpec.of(Boolean.class, "run_in_background",
                            "Set to true to run this agent in the background."
                                    + "Setting up background processing can effectively support multiple tasks running in parallel. "
                                    + "Returns immediately with a taskId. "
                                    + "You will receive a <task-notification> when the agent completes. "
                                    + "Launch multiple agents concurrently by calling task() with run_in_background=true multiple times in a single message.")
            ));
            var tool = new TaskTool();
            build(tool);
            return tool;
        }
    }
}
