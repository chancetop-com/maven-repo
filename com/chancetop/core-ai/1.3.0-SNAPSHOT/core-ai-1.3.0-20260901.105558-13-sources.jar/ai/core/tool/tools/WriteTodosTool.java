package ai.core.tool.tools;

import ai.core.agent.ExecutionContext;
import ai.core.api.tool.function.CoreAiMethod;
import ai.core.api.tool.function.CoreAiParameter;
import ai.core.tool.ToolCall;
import ai.core.tool.function.Functions;
import ai.core.utils.JsonUtil;
import core.framework.api.json.Property;

import java.util.List;

public class WriteTodosTool {
    private static final String WT_TOOL_DESC = """
            Use this tool to create and manage a structured task list for your current work session. This helps you track progress, organize complex tasks, and demonstrate thoroughness to the user.
            
            Only use this tool if you think it will be helpful in staying organized. If the user's request is trivial and takes less than 3 steps, it is better to NOT use this tool and just do the task directly.
            
            ## Complete End-to-End Planning
            
            When creating a todo list, plan the **full lifecycle** of the task, not just the implementation. A complete plan should cover these phases:
            
            1. **Exploration / Research**: Understand the current state, gather context, examine relevant materials, and research approaches before acting.
            2. **Implementation / Build**: Execute the core work — write, build, create, configure, or transform.
            3. **Validation / Verification**: Verify correctness after each implementation step — test, review, check, proofread, or confirm results.
            4. **Finalization / Polish**: Clean up, handle edge cases, ensure quality standards are met, and confirm nothing was missed.
            
            **Critical planning rules:**
            - Every implementation task should have a corresponding validation task — do not stop at "done writing," verify it works.
            - Plan the full journey from start to finish, not just the first few steps. A partial plan leads to incomplete work.
            - Think about dependencies: what must be done before other tasks? What can run in parallel?
            - The task is only complete when validated, not just when implemented.
            
            ## When to Use This Tool
            Use this tool in these scenarios:
            
            1. Complex multi-step tasks - When a task requires 3 or more distinct steps or actions
            2. Non-trivial and complex tasks - Tasks that require careful planning or multiple operations
            3. User explicitly requests todo list - When the user directly asks you to use the todo list
            4. User provides multiple tasks - When users provide a list of things to be done (numbered or comma-separated)
            5. The plan may need future revisions or updates based on results from the first few steps
            
            ## How to Use This Tool
            1. When you start working on a task - Mark it as in_progress BEFORE beginning work.
            2. After completing a task - Mark it as completed and add any new follow-up tasks discovered during implementation.
            3. You can also update future tasks, such as deleting them if they are no longer necessary, or adding new tasks that are necessary. Don't change previously completed tasks.
            4. You can make several updates to the todo list at once. For example, when you complete a task, you can mark the next task you need to start as in_progress.
            
            ## When NOT to Use This Tool
            It is important to skip using this tool when:
            1. There is only a single, straightforward task
            2. The task is trivial and tracking it provides no benefit
            3. The task can be completed in less than 3 trivial steps
            4. The task is purely conversational or informational
            
            ## Task States and Management
            
            1. **Task States**: Use these states to track progress:
               - pending: Task not yet started
               - in_progress: Currently working on (you can have multiple tasks in_progress at a time if they are not related to each other and can be run in parallel)
               - completed: Task finished successfully
            
            2. **Task Management**:
               - Update task status in real-time as you work
               - Mark tasks complete IMMEDIATELY after finishing (don't batch completions)
               - Complete current tasks before starting new ones
               - Remove tasks that are no longer relevant from the list entirely
               - IMPORTANT: When you write this todo list, you should mark your first task (or tasks) as in_progress immediately!.
               - IMPORTANT: Unless all tasks are completed, you should always have at least one task in_progress to show the user that you are working on something.
            
            3. **Task Completion Requirements**:
               - ONLY mark a task as completed when you have FULLY accomplished it
               - If you encounter errors, blockers, or cannot finish, keep the task as in_progress
               - When blocked, create a new task describing what needs to be resolved
               - Never mark a task as completed if:
                 - There are unresolved issues or errors
                 - Work is partial or incomplete
                 - You encountered blockers that prevent completion
                 - You couldn't find necessary resources or dependencies
                 - Quality standards haven't been met
            
            4. **Task Breakdown**:
               - Create specific, actionable items
               - Break complex tasks into smaller, manageable steps
               - Use clear, descriptive task names
               - Include validation/verification steps after each implementation task to ensure quality
            
            Being proactive with task management demonstrates attentiveness and ensures you complete all requirements successfully
            Remember: If you only need to make a few tool calls to complete a task, and it is clear what you need to do, it is better to just do the task directly and NOT call this tool at all.
            """;
    public static final String WT_TOOL_NAME = "write_todos";

    public static ToolCall self() {
        var todos = new WriteTodosTool();
        return Functions.from(todos, "writeTodos").getFirst();
    }

    @CoreAiMethod(name = WT_TOOL_NAME, description = WT_TOOL_DESC)
    public String writeTodos(@CoreAiParameter(name = "todos", description = "The updated todo list") List<Todo> todos, ExecutionContext context) {
        var todosJson = JsonUtil.toJson(todos);
        return ("Todos have been modified successfully.%n"
                    + "<system-reminder>%n"
                    + "Your todo list has changed. DO NOT mention this explicitly to the user.%n"
                    + "Here are the latest contents of your todo list:%n%n"
                    + "%s%n%n"
                    + "Continue on with the tasks at hand if applicable.%n"
                    + "</system-reminder>%n").formatted(todosJson);
    }

    public enum Status {
        @Property(name = "pending")
        PENDING,
        @Property(name = "in_progress")
        IN_PROGRESS,
        @Property(name = "completed")
        COMPLETED
    }

    public static class Todo {
        public String content;
        public Status status;

    }
}
