package ai.core.agent;

import ai.core.agent.internal.AgentHelper;
import ai.core.agent.slashcommand.SlashCommandParser;
import ai.core.context.Compression;
import ai.core.defaultagents.DefaultRagQueryRewriteAgent;
import ai.core.llm.LLMProvider;
import ai.core.llm.domain.Choice;
import ai.core.llm.domain.CompletionRequest;
import ai.core.llm.domain.CompletionResponse;
import ai.core.llm.domain.EmbeddingRequest;
import ai.core.llm.domain.FinishReason;
import ai.core.llm.domain.FunctionCall;
import ai.core.llm.domain.Message;
import ai.core.llm.domain.ReasoningEffort;
import ai.core.llm.domain.RerankingRequest;
import ai.core.llm.domain.RoleType;
import ai.core.llm.domain.Tool;
import ai.core.prompt.Prompts;
import ai.core.prompt.engines.MustachePromptTemplate;
import ai.core.rag.RagConfig;
import ai.core.rag.SimilaritySearchRequest;
import ai.core.reflection.ReflectionConfig;
import ai.core.reflection.ReflectionEvaluation;
import ai.core.reflection.ReflectionEvaluator;
import ai.core.reflection.ReflectionHistory;
import ai.core.reflection.ReflectionListener;
import ai.core.reflection.ReflectionStatus;
import ai.core.telemetry.AgentTracer;
import ai.core.telemetry.context.AgentTraceContext;
import ai.core.tool.ToolCall;
import ai.core.tool.ToolExecutor;
import ai.core.tool.tools.SubAgentToolCall;
import core.framework.crypto.Hash;
import core.framework.json.JSON;
import core.framework.util.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author stephen
 */
public class Agent extends Node<Agent> {
    public static AgentBuilder builder() {
        return new AgentBuilder();
    }

    private final Logger logger = LoggerFactory.getLogger(Agent.class);
    private volatile boolean cancelled = false;
    String systemPrompt;
    String promptTemplate;
    LLMProvider llmProvider;
    List<ToolCall> toolCalls;
    RagConfig ragConfig;
    Double temperature;
    String model;
    ReflectionConfig reflectionConfig;
    ReflectionListener reflectionListener;
    Boolean useGroupContext;
    Integer maxTurnNumber;
    Boolean authenticated = false;
    ToolExecutor toolExecutor;
    Compression compression;
    ReasoningEffort reasoningEffort;
    List<SubAgentToolCall> subAgents = new ArrayList<>();

    @Override
    String execute(String query, Map<String, Object> variables) {
        var activeTracer = (AgentTracer) getTracer();
        if (activeTracer != null) {
            var execContext = getExecutionContext();
            var context = AgentTraceContext.builder()
                    .name(getName())
                    .id(getId())
                    .input(query)
                    .withTools(toolCalls != null && !toolCalls.isEmpty())
                    .withRag(ragConfig != null && ragConfig.useRag())
                    .sessionId(execContext.getSessionId())
                    .userId(execContext.getUserId())
                    .build();

            return activeTracer.traceAgentExecution(context, () -> {
                var result = doExecute(query, variables, false);
                context.setOutput(getOutput());
                context.setStatus(getNodeStatus().name());
                context.setMessageCount(getMessages().size());
                return result;
            });
        }
        return doExecute(query, variables, false);
    }
    private void chatCommand(String query, Map<String, Object> variables) {
        chatTurns(query, variables, this::constructionFakeSlashCommandAssistantMsg);
    }

    private void chatLoops(String query, Map<String, Object> variables, boolean skipReflection) {
        var prompt = promptTemplate + query;
        Map<String, Object> context = variables == null ? Maps.newConcurrentHashMap() : new HashMap<>(variables);
        if (ragConfig.useRag()) {
            rag(getInput(), context);
            prompt += RagConfig.AGENT_RAG_CONTEXT_TEMPLATE;
        }

        prompt = new MustachePromptTemplate().execute(prompt, context, Hash.md5Hex(promptTemplate));

        chatTurns(prompt, variables, this::handLLM);

        if (reflectionConfig != null && reflectionConfig.enabled() && !skipReflection) {
            reflectionLoop(variables);
        }
    }

    private String doExecute(String query, Map<String, Object> variables, boolean skipReflection) {
        boolean isFirstExecution = getInput() == null;
        if (isFirstExecution) {
            setInput(query);
            if (getNodeStatus() == NodeStatus.WAITING_FOR_USER_INPUT && Prompts.CONFIRMATION_PROMPT.equalsIgnoreCase(query)) {
                authenticated = true;
            }
            updateNodeStatus(NodeStatus.RUNNING);
        }
        commandOrLoops(query, variables, skipReflection);
        if (isFirstExecution && getNodeStatus() == NodeStatus.RUNNING) {
            updateNodeStatus(NodeStatus.COMPLETED);
        }
        return getOutput();
    }

    private void commandOrLoops(String query, Map<String, Object> variables, boolean skipReflection) {
        if (SlashCommandParser.isSlashCommand(query)) {
            chatCommand(query, variables);
        } else {
            chatLoops(query, variables, skipReflection);
        }
    }

    private void reflectionLoop(Map<String, Object> variables) {
        ReflectionHistory history = new ReflectionHistory(getId(), getName(), getInput(), reflectionConfig.evaluationCriteria());
        int currentRound = 1;
        setRound(currentRound);
        if (reflectionListener != null)
            reflectionListener.onReflectionStart(this, getInput(), reflectionConfig.evaluationCriteria());
        while (currentRound <= reflectionConfig.maxRound()) {
            setRound(currentRound);
            Instant roundStart = Instant.now();
            String solutionToEvaluate = getOutput();
            logger.debug("Reflection round: {}/{}, agent: {}", currentRound, reflectionConfig.maxRound(), getName());
            if (reflectionListener != null) reflectionListener.onBeforeRound(this, currentRound, solutionToEvaluate);
            var evalRequest = new ReflectionEvaluator.EvaluationRequest(
                    getInput(), getOutput(), getName(), getLLMProvider(),
                    getTemperature(), getModel(), reflectionConfig, variables);
            ReflectionEvaluator.EvaluationResult evalResult = ReflectionEvaluator.evaluate(evalRequest);
            addTokenCost(evalResult.usage());
            String evaluationJson = evalResult.evaluationJson();
            ReflectionEvaluation evaluation = JSON.fromJSON(ReflectionEvaluation.class, evaluationJson);
            if (!AgentHelper.isValidEvaluation(evaluation)) {
                logger.error("Invalid evaluation score: {}, terminating reflection", evaluation.getScore());
                history.complete(ReflectionStatus.FAILED);
                if (reflectionListener != null) reflectionListener.onError(this, currentRound,
                        new IllegalStateException("Invalid evaluation score: " + evaluation.getScore()));
                return;
            }
            logger.debug("Round {} evaluation: score={}, pass={}, continue={}",
                    currentRound, evaluation.getScore(), evaluation.isPass(), evaluation.isShouldContinue());
            history.addRound(new ReflectionHistory.ReflectionRound(currentRound, solutionToEvaluate, evaluationJson,
                    evaluation, Duration.between(roundStart, Instant.now()), (long) getCurrentTokenUsage().getTotalTokens()));
            if (AgentHelper.shouldTerminateReflection(reflectionConfig, evaluation, currentRound)) {
                logger.debug("Reflection terminating: score={}, pass={}", evaluation.getScore(), evaluation.isPass());
                notifyTerminationReason(evaluation, currentRound);
                break;
            }
            doExecute(ReflectionEvaluator.buildImprovementPrompt(evaluationJson, evaluation), variables, true);
            if (reflectionListener != null)
                reflectionListener.onAfterRound(this, currentRound, getOutput(), evaluation);
            currentRound++;
        }
        if (currentRound > reflectionConfig.maxRound() && reflectionListener != null) {
            int finalScore = history.getRounds().isEmpty() ? 0 : history.getRounds().getLast().getEvaluation().getScore();
            reflectionListener.onMaxRoundsReached(this, finalScore);
        }
        history.complete(determineCompletionStatus(history));
        if (reflectionListener != null) reflectionListener.onReflectionComplete(this, history);
    }

    private void notifyTerminationReason(ReflectionEvaluation eval, int round) {
        if (reflectionListener == null) return;
        if (eval.isPass() && eval.getScore() >= 8) reflectionListener.onScoreAchieved(this, eval.getScore(), round);
        else if (!eval.isShouldContinue()) reflectionListener.onNoImprovement(this, eval.getScore(), round);
    }

    private ReflectionStatus determineCompletionStatus(ReflectionHistory history) {
        if (history.getRounds().size() >= reflectionConfig.maxRound()) return ReflectionStatus.COMPLETED_MAX_ROUNDS;
        if (history.getRounds().isEmpty()) return ReflectionStatus.COMPLETED_SUCCESS;
        var lastEval = history.getRounds().getLast().getEvaluation();
        if (lastEval.isPass() && lastEval.getScore() >= 8) return ReflectionStatus.COMPLETED_SUCCESS;
        return lastEval.isShouldContinue() ? ReflectionStatus.COMPLETED_SUCCESS : ReflectionStatus.COMPLETED_NO_IMPROVEMENT;
    }

    protected void chatTurns(String query, Map<String, Object> variables, BiFunction<List<Message>, List<Tool>, Choice> constructionAssistantMsg) {
        buildUserQueryToMessage(query, variables);
        var context = getExecutionContext();
        var currentIteCount = 0;
        var agentOut = new StringBuilder();
        do {
            if (cancelled) break;
            injectBeforeTurnMessages(context);
            var turnMsgList = turn(getMessages(), AgentHelper.toReqTools(toolCalls), constructionAssistantMsg);
            logger.debug("Agent[{}] turn {}: received {} messages", getName(), currentIteCount + 1, turnMsgList.size());
            turnMsgList.forEach(this::addMessage);
            agentOut.append(turnMsgList.stream().filter(m -> RoleType.ASSISTANT.equals(m.role)).map(Message::getTextContent).collect(Collectors.joining("")));
            currentIteCount++;
        } while ((AgentHelper.lastIsToolMsg(getMessages()) || lifecyclesShouldContinueTurns(context))
                && currentIteCount < maxTurnNumber);

        setOutput(agentOut.toString());
        if (currentIteCount >= maxTurnNumber) {
            logger.warn("agent run out of turns: maxTurnNumber - {}", maxTurnNumber);
            throw new MaxTurnsExceededException(maxTurnNumber);
        }
    }

    private void injectBeforeTurnMessages(ExecutionContext context) {
        agentLifecycles.stream()
                .flatMap(lc -> lc.beforeTurn(context).stream())
                .forEach(this::addMessage);
    }

    private boolean lifecyclesShouldContinueTurns(ExecutionContext context) {
        return agentLifecycles.stream().anyMatch(lc -> lc.shouldContinueTurns(context));
    }

    private Choice constructionFakeSlashCommandAssistantMsg(List<Message> messages, List<Tool> tools) {
        logger.debug("all tools size is {}", tools.size());
        String query = messages.getLast().getTextContent();
        var command = SlashCommandParser.parse(query);
        if (command.isNotValid()) {
            return Choice.of(FinishReason.STOP, Message.of(RoleType.ASSISTANT, "Error: Invalid slash command format. Expected: /slash_command:tool_name:arguments"));
        } else {
            var functionCall = FunctionCall.of(AgentHelper.generateToolCallId(), "function", command.getToolName(), command.hasArguments() ? command.getArguments() : "{}");
            return Choice.of(FinishReason.TOOL_CALLS, Message.of(RoleType.ASSISTANT, "", "assistant", null, List.of(functionCall)));
        }
    }

    public List<Message> turn(List<Message> messages, List<Tool> tools, BiFunction<List<Message>, List<Tool>, Choice> constructionAssistantMsg) {
        var resultMsg = new ArrayList<Message>();
        var choice = constructionAssistantMsg.apply(messages, tools);
        resultMsg.add(choice.message.toMessage());
        if (choice.finishReason == FinishReason.TOOL_CALLS) {
            var funcMsg = handleFunc(choice.message.toMessage());
            resultMsg.addAll(funcMsg);
        }
        return resultMsg;
    }

    private Choice handLLM(List<Message> messages, List<Tool> tools) {
        var req = CompletionRequest.of(new CompletionRequest.CompletionRequestOptions(messages, tools, llmProvider.config == null ? 0 : llmProvider.config.getTemperature(), model, this.getName(), null, null, reasoningEffort));
        return aroundLLM(r -> llmProvider.completionStream(r, AgentHelper.elseDefaultCallback(getStreamingCallback())), req);
    }

    private Choice aroundLLM(Function<CompletionRequest, CompletionResponse> func, CompletionRequest request) {
        agentLifecycles.forEach(alc -> alc.beforeModel(request, getExecutionContext()));
        var resp = callLLM(func, request);

        for (var lifecycle : agentLifecycles) {
            var retryMessages = lifecycle.onModelResponse(request, resp, getExecutionContext());
            if (retryMessages != null && !retryMessages.isEmpty()) {
                retryMessages.forEach(this::addMessage);
                resp = callLLM(func, request);
                break;
            }
        }

        return resp.choices.getFirst();
    }

    private CompletionResponse callLLM(Function<CompletionRequest, CompletionResponse> func, CompletionRequest request) {
        var resp = func.apply(request);
        addTokenCost(resp.usage);
        agentLifecycles.forEach(alc -> alc.afterModel(request, resp, getExecutionContext()));
        return resp;
    }

    public List<Message> handleFunc(Message funcMsg) {
        return funcMsg.toolCalls.stream().map(tool -> {
            var msg = new ArrayList<Message>();
            var result = getToolExecutor().execute(tool, getExecutionContext());
            if (result.isDirectReturn()) {
                msg.add(AgentHelper.buildToolMessage(tool, result, true));
                msg.add(Message.of(RoleType.ASSISTANT, result.toResultForLLM()));
            } else {
                msg.add(AgentHelper.buildToolMessage(tool, result));
            }
            return msg;
        }).flatMap(List::stream).toList();
    }

    private ToolExecutor getToolExecutor() {
        if (toolExecutor == null) {
            toolExecutor = new ToolExecutor(toolCalls, agentLifecycles, getTracer(), this::updateNodeStatus);
        }
        toolExecutor.setAuthenticated(authenticated);
        return toolExecutor;
    }

    private void buildUserQueryToMessage(String query, Map<String, Object> variables) {
        if (getMessages().isEmpty()) {
            addMessage(buildSystemMessage(variables));
        }

        if (isUseGroupContext() && getParentNode() != null) {
            addMessages(getParentNode().getMessages());
        }

        var reqMsg = AgentHelper.buildUserMessage(query, getExecutionContext());
        removeLastAssistantToolCallMessageIfNotToolResult(reqMsg);
        addMessage(reqMsg);
    }

    private void removeLastAssistantToolCallMessageIfNotToolResult(Message reqMsg) {
        var lastMsg = getMessages().getLast();
        if (lastMsg.role == RoleType.ASSISTANT && lastMsg.toolCalls != null
                && !lastMsg.toolCalls.isEmpty() && reqMsg.role != RoleType.TOOL) {
            removeMessage(lastMsg);
        }
    }

    @Override
    void setChildrenParentNode() {
    }

    private Message buildSystemMessage(Map<String, Object> variables) {
        var prompt = systemPrompt;
        if (getParentNode() != null && isUseGroupContext()) {
            this.putSystemVariable(getParentNode().getSystemVariables());
        }
        Map<String, Object> var = Maps.newConcurrentHashMap();
        if (variables != null) var.putAll(variables);
        var.putAll(getSystemVariables());
        prompt = new MustachePromptTemplate().execute(prompt, var, Hash.md5Hex(promptTemplate));
        return Message.of(RoleType.SYSTEM, prompt);
    }

    private void rag(String query, Map<String, Object> variables) {
        if (ragConfig.vectorStore() == null || ragConfig.llmProvider() == null)
            throw new RuntimeException("vectorStore/llmProvider cannot be null if useRag flag is enabled");
        var ragQuery = query;
        if (ragConfig.enableQueryRewriting()) {
            ragQuery = DefaultRagQueryRewriteAgent.of(ragConfig.llmProvider()).run(query);
        }
        var rsp = ragConfig.llmProvider().embeddings(new EmbeddingRequest(List.of(ragQuery)));
        addTokenCost(rsp.usage);
        var embedding = rsp.embeddings.getFirst().embedding;
        var docs = ragConfig.vectorStore().similaritySearch(SimilaritySearchRequest.builder()
                .embedding(embedding)
                .threshold(ragConfig.threshold())
                .topK(ragConfig.topK()).build());
        var context = ragConfig.llmProvider().rerankings(RerankingRequest.of(ragQuery, docs.stream().map(v -> v.content).toList())).rerankedDocuments.getFirst();
        variables.put(RagConfig.AGENT_RAG_CONTEXT_PLACEHOLDER, context);
    }

    public Boolean isUseGroupContext() {
        return this.useGroupContext;
    }
    public List<ToolCall> getToolCalls() {
        return this.toolCalls;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public String getSystemPrompt() {
        return systemPrompt;
    }
    public void setSystemPrompt(String systemPrompt) {
        this.systemPrompt = systemPrompt;
    }
    public Double getTemperature() {
        return temperature;
    }
    public String getModel() {
        return model;
    }
    public LLMProvider getLLMProvider() {
        return llmProvider;
    }
    public Compression getCompression() {
        return compression;
    }
    public void setAuthenticated(boolean authenticated) {
        this.authenticated = authenticated;
    }
    public void setLlmProvider(LLMProvider llmProvider) {
        this.llmProvider = llmProvider;
    }
    public List<SubAgentToolCall> getSubAgents() {
        return subAgents;
    }
    void setSubAgents(List<SubAgentToolCall> subAgents) {
        this.subAgents = subAgents;
    }
    public boolean hasSubAgents() {
        return subAgents != null && !subAgents.isEmpty();
    }
    public SubAgentToolCall toSubAgentToolCall() {
        return SubAgentToolCall.builder().subAgent(this).build();
    }
    public SubAgentToolCall toSubAgentToolCall(Class<?>... classes) {
        return SubAgentToolCall.builder().subAgent(this, classes).build();
    }

    public void addTools(List<ToolCall> tools) {
        if (tools == null) return;
        for (var tool : tools) {
            if (toolCalls.stream().noneMatch(t -> t.getName().equals(tool.getName()))) {
                toolCalls.add(tool);
            }
        }
    }
    public void cancel() {
        this.cancelled = true;
        var cb = getStreamingCallback();
        if (cb != null) cb.cancelConnection();
    }
    public void resetCancellation() {
        this.cancelled = false;
        var cb = getStreamingCallback();
        if (cb != null) cb.reset();
    }
    public boolean isCancelled() {
        return cancelled;
    }
    @Override
    public ExecutionContext getExecutionContext() {
        var context = super.getExecutionContext();
        context.setLlmProvider(llmProvider);
        context.setModel(model);
        context.setStreamingCallback(getStreamingCallback());
        context.setLifecycles(agentLifecycles);
        return context;
    }
}