package ai.core.sse.internal;

import ai.core.sse.SseChannelInterceptor;
import core.framework.http.HTTPMethod;
import core.framework.internal.async.VirtualThread;
import core.framework.internal.log.ActionLog;
import core.framework.internal.log.LogManager;
import core.framework.internal.web.HTTPHandlerContext;
import core.framework.internal.web.controller.WebContextImpl;
import core.framework.internal.web.http.RateControl;
import core.framework.internal.web.request.RequestImpl;
import core.framework.internal.web.service.ErrorResponse;
import core.framework.internal.web.session.ReadOnlySession;
import core.framework.internal.web.session.SessionManager;
import core.framework.internal.web.sse.ServerSentEventHandler;
import core.framework.util.Strings;
import core.framework.web.sse.ChannelListener;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.HeaderMap;
import io.undertow.util.Headers;
import io.undertow.util.HttpString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xnio.ChannelListeners;
import org.xnio.IoUtils;
import org.xnio.channels.StreamSinkChannel;

import java.nio.ByteBuffer;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

//todo: use extends for sse handler
public class PatchedServerSentEventHandler extends ServerSentEventHandler {
    // persistent connection, use longer max process time
    // though LB backend timeout is to 600s, for long time sse, it should be processed via message queue
    static final long MAX_PROCESS_TIME_IN_NANO = Duration.ofSeconds(300).toNanos();
    static final HttpString HEADER_TRACE_ID = new HttpString("x-trace-id");

    private static final HttpString LAST_EVENT_ID = new HttpString("Last-Event-ID");
    private final Logger logger = LoggerFactory.getLogger(PatchedServerSentEventHandler.class);
    private final LogManager logManager;
    private final SessionManager sessionManager;
    private final HTTPHandlerContext handlerContext;
    private final Map<String, PatchedChannelSupport<?>> supports = new HashMap<>();
    private final Set<String> acceptGatedKeys = new HashSet<>();
    private final List<SseChannelInterceptor> interceptors = new ArrayList<>();
    public WebContextImpl webContext;

    public PatchedServerSentEventHandler(LogManager logManager, SessionManager sessionManager, HTTPHandlerContext handlerContext) {
        super(logManager, sessionManager, handlerContext);
        this.logManager = logManager;
        this.sessionManager = sessionManager;
        this.handlerContext = handlerContext;
    }

    @Override
    public boolean check(HttpString method, String path, HeaderMap headers) {
        // Allow OPTIONS requests for CORS preflight (Safari)
        if ("OPTIONS".equals(method.toString())) {
            // Check if any method is registered for this path
            for (String registeredKey : supports.keySet()) {
                if (registeredKey.endsWith(":" + path)) {
                    logger.debug("sse OPTIONS preflight allowed for path={}", path);
                    return true;
                }
            }
            logger.debug("sse OPTIONS preflight rejected, no route registered for path={}", path);
            return false;
        }

        var routeKey = key(method.toString(), path);
        // Check if the path is registered for SSE
        if (!supports.containsKey(routeKey)) {
            logger.debug("sse route not found, method={}, path={}, registered routes={}", method, path, supports.keySet());
            return false;
        }
        logger.debug("sse route found, method={}, path={}", method, path);
        //todo wait implementation check method
//        if (headers != null && headers.getFirst(Headers.ACCEPT) != null) {
//            return headers.getFirst(Headers.ACCEPT).contains("text/event-stream");
//        }
        if (acceptGatedKeys.contains(routeKey)) {
            var accept = headers == null ? null : headers.getFirst(Headers.ACCEPT);
            return accept != null && accept.contains("text/event-stream");
        }
        return true;
    }

    /**
     * Only take over requests on this route when the client sends Accept: text/event-stream,
     * letting non-SSE requests fall through to a regular http route on the same path.
     */
    public void requireEventStreamAccept(HTTPMethod method, String path) {
        acceptGatedKeys.add(key(method.name(), path));
    }

    @Override
    public void handleRequest(HttpServerExchange exchange) {
        // todo: add options support
        // CORS headers
        exchange.getResponseHeaders().put(new HttpString("Access-Control-Allow-Origin"), "*");
        exchange.getResponseHeaders().put(new HttpString("Access-Control-Allow-Methods"), "GET, POST, OPTIONS");
        exchange.getResponseHeaders().put(new HttpString("Access-Control-Allow-Headers"), "Content-Type, Authorization, X-Auth-Request-Email, X-Auth-Request-User, x-trace-id, Last-Event-ID");
        exchange.getResponseHeaders().put(new HttpString("Access-Control-Allow-Credentials"), "true");

        // Handle OPTIONS preflight request (Safari CORS)
        if ("OPTIONS".equals(exchange.getRequestMethod().toString())) {
            exchange.setStatusCode(200);
            exchange.endExchange();
            return;
        }

        exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, "text/event-stream");
        exchange.setPersistent(false);
        StreamSinkChannel sink = exchange.getResponseChannel();
        try {
            if (sink.flush()) {
                exchange.dispatch(() -> handle(exchange, sink));
            } else {
                var listener = ChannelListeners.flushingChannelListener(_ -> exchange.dispatch(() -> handle(exchange, sink)),
                    (_, e) -> {
                        logger.warn("failed to establish sse connection, error={}", e.getMessage(), e);
                        IoUtils.safeClose(exchange.getConnection());
                    });
                sink.getWriteSetter().set(listener);
                sink.resumeWrites();
            }
        } catch (Throwable e) {
            logger.warn("failed to establish sse connection, error={}", e.getMessage(), e);
            IoUtils.safeClose(exchange.getConnection());
        }
    }

    void handle(HttpServerExchange exchange, StreamSinkChannel sink) {
        VirtualThread.COUNT.increase();
        long httpDelay = System.nanoTime() - exchange.getRequestStartTime();

        try {
            logManager.run("sse", null, actionLog -> {
                logger.debug("httpDelay={}", httpDelay);
                actionLog.stats.put("http_delay", (double) httpDelay);

                connect(exchange, sink, actionLog);
                return null;
            });
        } finally {
            VirtualThread.COUNT.decrease();
        }
    }

    public void addInterceptor(SseChannelInterceptor interceptor) {
        interceptors.add(interceptor);
        logger.info("add sse interceptor, interceptor={}", interceptor.getClass().getCanonicalName());
    }

    private void connect(HttpServerExchange exchange, StreamSinkChannel sink, ActionLog actionLog) {
        var request = new RequestImpl(exchange, handlerContext.requestBeanReader);
        PatchedChannelImpl<Object> channel = null;
        try {
            handlerContext.requestParser.parse(request, exchange, actionLog);
            if (handlerContext.accessControl != null) handlerContext.accessControl.validate(request.clientIP());  // check ip before checking routing, return 403 asap

            actionLog.warningContext.maxProcessTimeInNano(MAX_PROCESS_TIME_IN_NANO);
            String path = request.path();
            @SuppressWarnings("unchecked")
            PatchedChannelSupport<Object> support = (PatchedChannelSupport<Object>) supports.get(key(request.method().name(), path));   // ServerSentEventHandler.check() ensures path exists
            actionLog.action("sse:" + path + ":connect");

            if (handlerContext.rateControl != null) {
                limitRate(handlerContext.rateControl, support, request.clientIP());
            }
            if (support.warnings != null) actionLog.initializeWarnings(support.warnings);
            channel = new PatchedChannelImpl<>(exchange, sink, support.context, support.builder, actionLog.id, request);
            sink.getWriteSetter().set(channel.writeListener);
            exchange.addExchangeCompleteListener(new PatchedServerSentEventCloseHandler<>(logManager, channel, support));
            support.context.add(channel);

            actionLog.context("channel", channel.id);
            String traceId = exchange.getRequestHeaders().getFirst(HEADER_TRACE_ID);    // used by frontend to trace request
            if (traceId != null) {
                actionLog.context.put("trace_id", List.of(traceId));
                channel.traceId = traceId;
            }

            channel.sendBytes(Strings.bytes("retry: 5000\n\n"));    // set browser retry to 5s

            request.session = ReadOnlySession.of(sessionManager.load(request, actionLog));
            String lastEventId = exchange.getRequestHeaders().getLast(LAST_EVENT_ID);
            if (lastEventId != null) actionLog.context("last_event_id", lastEventId);

            actionLog.context("listener", support.listener.getClass().getCanonicalName());
            var finalChannel = channel;
            webContext.run(request, () -> {
                for (var interceptor : interceptors) {
                    interceptor.onConnect(request, webContext);
                }
                support.listener.onConnect(request, finalChannel, lastEventId);
            });

            if (!channel.groups.isEmpty()) actionLog.context("group", channel.groups.toArray()); // may join group onConnect
        } catch (Throwable e) {
            logManager.logError(e);

            if (channel != null) {
                String message = errorMessage(handlerContext.responseBeanWriter.toJSON(ErrorResponse.errorResponse(e, actionLog.id)));
                sendErrorAndClose(channel, sink, message);
            }
        }
    }

    private void sendErrorAndClose(PatchedChannelImpl<Object> channel, StreamSinkChannel sink, String message) {
        // write the error synchronously before close: the async sendBytes path can race with
        // close() and drop the buffered message, leaving the client with a silent disconnect
        try {
            var buffer = ByteBuffer.wrap(Strings.bytes(message));
            while (buffer.hasRemaining()) {
                sink.write(buffer);
            }
            sink.flush();
        } catch (Throwable writeError) {
            logger.warn("failed to send sse error event, error={}", writeError.getMessage(), writeError);
        }
        channel.close();    // gracefully shutdown connection to make sure retry/error can be sent
    }

    void limitRate(RateControl rateControl, PatchedChannelSupport<Object> support, String clientIP) {
        if (support.limitRate != null) {
            String group = support.limitRate.value();
            rateControl.validateRate(group, clientIP);
        }
    }

    String errorMessage(String errorResponse) {
        // inject "type":"error" so clients can route the error through the same event dispatcher
        // (regular SSE events carry a `type` field; without it the error would be dropped by switch-on-type handlers)
        String withType = errorResponse.startsWith("{")
                ? errorResponse.replaceFirst("\\{", "{\"type\":\"error\",")
                : errorResponse;
        return "retry: 86400000\n\n"
               + "event: error\n"
               + "data: " + withType + "\n\n";
    }

    public <T> void add(HTTPMethod method, String path, Class<T> eventClass, ChannelListener<T> listener, PatchedServerSentEventContextImpl<T> context) {
        var previous = supports.put(key(method.name(), path), new PatchedChannelSupport<>(listener, eventClass, context));
        if (previous != null) throw new Error(Strings.format("found duplicate sse listener, method={}, path={}", method, path));
    }

    @Override
    public void shutdown() {
        logger.info("close sse connections");
        for (PatchedChannelSupport<?> support : supports.values()) {
            for (var channel : support.context.all()) {
                ((PatchedChannelImpl<?>) channel).shutdown();
            }
        }
    }

    private String key(String method, String path) {
        return method + ":" + path;
    }
}
