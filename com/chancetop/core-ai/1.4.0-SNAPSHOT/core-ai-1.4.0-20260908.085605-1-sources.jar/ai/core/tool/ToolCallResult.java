package ai.core.tool;

import ai.core.llm.LLMModelContextRegistry;
import ai.core.llm.domain.Usage;
import core.framework.util.Strings;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * @author stephen
 */
public final class ToolCallResult {

    public static ToolCallResult completed(String result) {
        var r = new ToolCallResult();
        r.status = Status.COMPLETED;
        r.result = result;
        return r;
    }

    public static ToolCallResult failed(String error) {
        return failed(error, new RuntimeException(error));
    }

    public static ToolCallResult failed(String error, Throwable e) {
        return failed(error, new RuntimeException(e));
    }

    public static ToolCallResult failed(String error, RuntimeException e) {
        var r = new ToolCallResult();
        r.status = Status.FAILED;
        r.result = error;
        r.runtimeException = e;
        return r;
    }

    public static ToolCallResult waitingForInput(String taskId, String message) {
        var r = new ToolCallResult();
        r.status = Status.WAITING_FOR_INPUT;
        r.taskId = taskId;
        r.result = message;
        return r;
    }

    public static ToolCallResult pending(String taskId, String message) {
        var r = new ToolCallResult();
        r.status = Status.PENDING;
        r.taskId = taskId;
        r.result = message;
        return r;
    }

    public static ToolCallResult asyncLaunched(String taskId, String result) {
        var r = new ToolCallResult();
        r.status = Status.ASYNC_LAUNCHED;
        r.taskId = taskId;
        r.result = result;
        return r;
    }

    private Status status;
    private String taskId;
    private String result;

    private String toolName;
    private long durationMs;
    private final Map<String, Object> stats;
    private Boolean directReturn;
    private RuntimeException runtimeException;
    /** Set when this result reports the status of a task that a manager already tracks (a poll relay from async_task_output),
     * never fresh async work — the executor must not register it as a new async task. */
    private boolean managedTask;

    private String llmModel;
    private Usage llmUsage;
    private Double llmCostUsd;

    private ContentType type = ContentType.TEXT;
    private String imageBase64;
    private String imageFormat;

    private ToolCallResult() {
        this.stats = new HashMap<>();
    }

    @Override
    public String toString() {
        return Strings.format(
                "ToolCallResult{status={}, toolName='{}', durationMs={}, result='{}', stats={}, taskId='{}', llmModel='{}', llmCostUsd={}}",
                status, toolName, durationMs, result, stats, taskId, llmModel, llmCostUsd
        );
    }

    public boolean isCompleted() {
        return status == Status.COMPLETED;
    }

    public boolean isPending() {
        return status == Status.PENDING;
    }

    public boolean isWaitingForInput() {
        return status == Status.WAITING_FOR_INPUT;
    }

    public boolean isFailed() {
        return status == Status.FAILED;
    }

    public boolean isAsyncLaunched() {
        return status == Status.ASYNC_LAUNCHED;
    }

    public boolean isTerminal() {
        return status == Status.COMPLETED || status == Status.FAILED;
    }

    public Status getStatus() {
        return status;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getResult() {
        return result;
    }

    public String getToolName() {
        return toolName;
    }

    public long getDurationMs() {
        return durationMs;
    }

    public boolean isDirectReturn() {
        return directReturn != null && directReturn;
    }

    public boolean isManagedTask() {
        return managedTask;
    }

    public ToolCallResult withManagedTask() {
        this.managedTask = true;
        return this;
    }

    public Map<String, Object> getStats() {
        return stats;
    }

    public ToolCallResult withToolName(String toolName) {
        this.toolName = toolName;
        return this;
    }

    public ToolCallResult withDuration(long durationMs) {
        this.durationMs = durationMs;
        return this;
    }

    public ToolCallResult withResult(String result) {
        this.result = result;
        return this;
    }

    public ToolCallResult withStats(String key, Object value) {
        this.stats.put(key, value);
        return this;
    }

    public ToolCallResult withStats(Map<String, Object> stats) {
        this.stats.putAll(stats);
        return this;
    }

    public ToolCallResult withDirectReturn(Boolean directReturn) {
        this.directReturn = directReturn;
        return this;
    }

    public RuntimeException getRuntimeException() {
        return runtimeException;
    }

    public ToolCallResult withRuntimeException(RuntimeException runtimeException) {
        this.runtimeException = runtimeException;
        return this;
    }

    /**
     * Attaches the token usage and estimated cost of an LLM call made inside this tool
     * (e.g. caption_image), so the agent can accumulate them into session usage/cost.
     */
    public ToolCallResult withLlmUsage(String model, Usage usage) {
        this.llmModel = model;
        this.llmUsage = usage;
        if (usage != null) {
            var cachedTokens = usage.getPromptTokensDetails() != null
                    ? usage.getPromptTokensDetails().cachedTokens : 0;
            this.llmCostUsd = LLMModelContextRegistry.getInstance().estimateCostUsd(
                    model, usage.getPromptTokens(), usage.getCompletionTokens(), cachedTokens, Instant.now());
        }
        return this;
    }

    public String getLlmModel() {
        return llmModel;
    }

    public Usage getLlmUsage() {
        return llmUsage;
    }

    public Double getLlmCostUsd() {
        return llmCostUsd;
    }

    public ContentType getType() {
        return type;
    }

    public String getImageBase64() {
        return imageBase64;
    }

    public String getImageFormat() {
        return imageFormat;
    }

    public boolean hasImage() {
        return type == ContentType.IMAGE && imageBase64 != null && !imageBase64.isEmpty();
    }

    public ToolCallResult withImage(String base64, String format) {
        this.type = ContentType.IMAGE;
        this.imageBase64 = base64;
        this.imageFormat = format;
        return this;
    }

    public String toResultForLLM() {
        return switch (status) {
            case COMPLETED -> result;
            case PENDING -> formatPendingMessage();
            case WAITING_FOR_INPUT -> formatWaitingMessage();
            case ASYNC_LAUNCHED -> result;
            case FAILED -> "Error: " + result;
        };
    }

    private String formatPendingMessage() {
        var sb = new StringBuilder(160);
        sb.append("[ASYNC_TASK_STARTED] taskId=").append(taskId).append('\n');
        if (result != null) {
            sb.append(result).append('\n');
        }
        sb.append("The task is running asynchronously. Use 'async_task_output' tool to check progress or wait for completion.");
        return sb.toString();
    }

    private String formatWaitingMessage() {
        var sb = new StringBuilder(100);
        sb.append("[WAITING_FOR_INPUT] taskId=").append(taskId).append('\n');
        if (result != null) {
            sb.append(result).append('\n');
        }
        sb.append("Please ask the user to provide the required input.");
        return sb.toString();
    }


    public enum Status {
        COMPLETED,
        PENDING,
        WAITING_FOR_INPUT,
        ASYNC_LAUNCHED,
        FAILED
    }

    public enum ContentType {
        TEXT,
        IMAGE
    }
}
