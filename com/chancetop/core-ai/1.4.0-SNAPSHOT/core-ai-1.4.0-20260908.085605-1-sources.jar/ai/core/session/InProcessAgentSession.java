package ai.core.session;

import ai.core.agent.Agent;
import ai.core.agent.AttachedContent;
import ai.core.agent.MaxTurnsExceededException;
import ai.core.agent.lifecycle.PlanUpdateLifecycle;
import ai.core.api.server.session.AgentEvent;
import ai.core.api.server.session.AgentEventListener;
import ai.core.api.server.session.AgentSession;
import ai.core.api.server.session.ApprovalDecision;
import ai.core.api.server.session.BatchToolStartEvent;
import ai.core.api.server.session.CompressionEvent;
import ai.core.api.server.session.EnvironmentOutputChunkEvent;
import ai.core.api.server.session.ErrorEvent;
import ai.core.api.server.session.OnToolEvent;
import ai.core.api.server.session.PlanUpdateEvent;
import ai.core.api.server.session.ReasoningChunkEvent;
import ai.core.api.server.session.ReasoningCompleteEvent;
import ai.core.api.server.session.SandboxEvent;
import ai.core.api.server.session.SessionStatus;
import ai.core.api.server.session.StatusChangeEvent;
import ai.core.api.server.session.TaskStatusEvent;
import ai.core.api.server.session.TextChunkEvent;
import ai.core.api.server.session.ToolApprovalRequestEvent;
import ai.core.api.server.session.ToolResultEvent;
import ai.core.api.server.session.ToolStartEvent;
import ai.core.api.server.session.TurnCompleteEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Function;

/**
 * @author stephen
 */
public class InProcessAgentSession implements AgentSession {
    private final Logger logger = LoggerFactory.getLogger(InProcessAgentSession.class);

    private final String sessionId;
    private final Agent agent;
    private final PermissionGate permissionGate;
    private final SessionCommandQueue commandQueue;
    private final TurnDriver turnDriver;
    private final List<AgentEventListener> listeners = new CopyOnWriteArrayList<>();
    // Set when RUNNING is dispatched, cleared by whoever dispatches the turn's terminal event.
    // close() races the turn thread for it so a force-closed turn still terminates exactly once.
    private final AtomicBoolean turnActive = new AtomicBoolean();

    public InProcessAgentSession(String sessionId, Agent agent, boolean autoApproveAll, ToolPermissionStore permissionStore) {
        this.sessionId = sessionId;
        this.agent = agent;
        this.permissionGate = new PermissionGate();
        this.commandQueue = new SessionCommandQueue();
        this.turnDriver = new TurnDriver(commandQueue, this::executeCommands);
        var context = agent.getExecutionContext();
        if (context.getSubagentOutputSinkFactory() != null) {
            context.setTaskManager(new BackgroundTaskManager(commandQueue, context.getSubagentOutputSinkFactory(), sessionId, this::dispatch));
        }
        agent.setStreamingCallback(new SessionStreamingCallback(sessionId, this::dispatch, context));
        var permissionLifecycle = new ServerPermissionLifecycle(sessionId, this::dispatch, permissionGate, autoApproveAll, permissionStore, toolTypeResolver());
        agent.addLifecycle(permissionLifecycle);
        agent.addLifecycle(new PlanUpdateLifecycle(this::dispatch));
        agent.setAuthenticated(true);
        setupCompressionListener();
    }

    /**
     * Constructor that skips loading from persistence (used when session is already loaded).
     */
    public InProcessAgentSession(String sessionId, Agent agent, boolean autoApproveAll, ToolPermissionStore permissionStore, boolean skipLoad) {
        this.sessionId = sessionId;
        this.agent = agent;
        this.permissionGate = new PermissionGate();
        this.commandQueue = new SessionCommandQueue();
        this.turnDriver = new TurnDriver(commandQueue, this::executeCommands);
        var context = agent.getExecutionContext();
        if (context.getSubagentOutputSinkFactory() != null) {
            context.setTaskManager(new BackgroundTaskManager(commandQueue, context.getSubagentOutputSinkFactory(), sessionId, this::dispatch));
        }
        agent.setStreamingCallback(new SessionStreamingCallback(sessionId, this::dispatch, context));
        var permissionLifecycle = new ServerPermissionLifecycle(sessionId, this::dispatch, permissionGate, autoApproveAll, permissionStore, toolTypeResolver());
        agent.addLifecycle(permissionLifecycle);
        agent.addLifecycle(new PlanUpdateLifecycle(this::dispatch));
        agent.setAuthenticated(true);
        setupCompressionListener();
        // Skip loading when skipLoad is true (session already loaded by caller)
    }

    @Override
    public String id() {
        return sessionId;
    }

    public Agent agent() {
        return agent;
    }

    @Override
    public void sendMessage(String message) {
        sendMessage(message, null);
    }

    @Override
    public void sendMessage(String message, Map<String, Object> variables) {
        sendMessage(message, variables, null);
    }

    public void sendMessage(String message, Map<String, Object> variables, List<AttachedContent> attachedContents) {
        commandQueue.enqueueUserInput(message, variables, attachedContents);
    }

    private void executeCommands(SessionCommandQueue.CommandBatch batch) {
        var executingThread = Thread.currentThread();
        var turnToken = agent.getCancellationToken().createChild();
        agent.getExecutionContext().setCancellationToken(turnToken);
        var threadUnbind = turnToken.bindThread(executingThread);
        turnActive.set(true);
        dispatch(StatusChangeEvent.of(sessionId, SessionStatus.RUNNING));

        var usageBefore = agent.getCurrentTokenUsage();
        long inputBefore = usageBefore.getPromptTokens();
        long outputBefore = usageBefore.getCompletionTokens();
        double costBefore = agent.getCurrentCostUsd();

        try {
            if (batch.mode() == SessionCommandQueue.CommandMode.USER_INPUT) {
                executeUserInput(batch.values(), inputBefore, outputBefore, costBefore);
            } else if (batch.mode() == SessionCommandQueue.CommandMode.TASK_NOTIFICATION) {
                executeTaskNotifications(batch.values(), inputBefore, outputBefore, costBefore);
            }
        } catch (ToolCallDeniedException e) {
            debug("tool call denied: " + e.getMessage());
            dispatchTerminal(TurnCompleteEvent.cancelled(sessionId), SessionStatus.IDLE);
            commandQueue.drainTaskNotifications();
        } catch (Throwable e) {
            if (agent.isCancelled()) {
                debug("agent run cancelled");
                dispatchTerminal(TurnCompleteEvent.cancelled(sessionId), SessionStatus.IDLE);
                commandQueue.drainTaskNotifications();
                return;
            }
            debug("agent run failed: " + e);
            logger.warn("agent session run failed, sessionId={}", sessionId, e);
            persistOnFailure();
            dispatchTerminal(ErrorEvent.of(sessionId, e.getMessage(), ""), SessionStatus.ERROR);
        } finally {
            threadUnbind.run();
            turnToken.disconnect();
        }
    }

    private void persistOnFailure() {
        if (!agent.hasPersistenceProvider()) return;
        if (!agent.hasUserMessage()) return;
        try {
            agent.save(sessionId);
        } catch (RuntimeException e) {
            logger.warn("failed to persist session after run failure, sessionId={}", sessionId, e);
        }
    }

    private void persistCancelledTurn() {
        // runTurnsLoop may have added partial assistant messages (incl. reasoning) before
        // unwinding — persist them so the cancelled turn is not lost.
        if (!agent.hasPersistenceProvider()) return;
        if (!agent.hasUserMessage()) return;
        try {
            agent.save(sessionId);
        } catch (RuntimeException e) {
            logger.warn("failed to persist session after cancelled turn, sessionId={}", sessionId, e);
        }
    }

    private void executeUserInput(List<SessionCommandQueue.QueuedMessage> values, long inputBefore, long outputBefore, double costBefore) {
        var combined = String.join("\n", values.stream().map(SessionCommandQueue.QueuedMessage::value).toList());
        debug("agent run starting");
        String result;
        var context = agent.getExecutionContext();
        var lastMessage = values.getLast();
        var newVariables = lastMessage.variables();
        if (newVariables != null && !newVariables.isEmpty()) {
            context.getCustomVariables().putAll(newVariables);
        }
        context.setAttachedContents(lastMessage.attachedContents());
        try {
            result = agent.run(combined, context);
        } catch (MaxTurnsExceededException e) {
            debug("agent exceeded max turns: " + e.maxTurns);
            if (agent.hasPersistenceProvider()) {
                agent.save(sessionId);
            }
            var turnComplete = TurnCompleteEvent.of(sessionId, agent.getOutput() != null ? agent.getOutput() : "");
            populateTokenUsage(turnComplete, inputBefore, outputBefore, costBefore);
            turnComplete.maxTurnsReached = Boolean.TRUE;
            dispatchTerminal(turnComplete, SessionStatus.IDLE);
            return;
        } finally {
            context.setAttachedContents(null);
        }
        if (agent.isCancelled()) {
            debug("agent run cancelled");
            persistCancelledTurn();
            // carry partial output so server chat history records what was produced before ESC
            dispatchTerminal(TurnCompleteEvent.cancelled(sessionId, agent.getOutput()), SessionStatus.IDLE);
            commandQueue.drainTaskNotifications();
            return;
        }
        if (agent.hasPersistenceProvider()) {
            agent.save(sessionId);
        }
        debug("agent run completed");
        var turnComplete = TurnCompleteEvent.of(sessionId, result != null ? result : "");
        populateTokenUsage(turnComplete, inputBefore, outputBefore, costBefore);
        dispatchTerminal(turnComplete, SessionStatus.IDLE);
    }

    private void executeTaskNotifications(List<SessionCommandQueue.QueuedMessage> values, long inputBefore, long outputBefore, double costBefore) {
        var xml = String.join("\n", values.stream().map(SessionCommandQueue.QueuedMessage::value).toList());
        debug("injecting task notifications");
        String result;
        try {
            agent.injectUserMessage(xml);
            result = agent.continueWithInjectedMessage();
        } catch (MaxTurnsExceededException e) {
            debug("agent exceeded max turns on notification: " + e.maxTurns);
            if (agent.hasPersistenceProvider()) {
                agent.save(sessionId);
            }
            var turnComplete = TurnCompleteEvent.of(sessionId, agent.getOutput() != null ? agent.getOutput() : "");
            populateTokenUsage(turnComplete, inputBefore, outputBefore, costBefore);
            turnComplete.maxTurnsReached = Boolean.TRUE;
            dispatchTerminal(turnComplete, SessionStatus.IDLE);
            return;
        }
        if (agent.isCancelled()) {
            debug("agent run cancelled");
            persistCancelledTurn();
            // carry partial output so server chat history records what was produced before ESC
            dispatchTerminal(TurnCompleteEvent.cancelled(sessionId, agent.getOutput()), SessionStatus.IDLE);
            commandQueue.drainTaskNotifications();
            return;
        }
        if (agent.hasPersistenceProvider()) {
            agent.save(sessionId);
        }
        debug("task notifications processed");
        var turnComplete = TurnCompleteEvent.of(sessionId, result);
        populateTokenUsage(turnComplete, inputBefore, outputBefore, costBefore);
        dispatchTerminal(turnComplete, SessionStatus.IDLE);
    }

    private void populateTokenUsage(TurnCompleteEvent event, long inputBefore, long outputBefore, double costBefore) {
        var usageAfter = agent.getCurrentTokenUsage();
        event.inputTokens = usageAfter.getPromptTokens() - inputBefore;
        event.outputTokens = usageAfter.getCompletionTokens() - outputBefore;
        var costAfter = agent.getCurrentCostUsd();
        event.costUsd = costAfter - costBefore;
    }

    @Override
    public void cancelTurn() {
        debug("cancelling current turn");
        var token = agent.getExecutionContext().getCancellationToken();
        if (token != null) {
            boolean cancelled = token.cancel();
            // Persist the interrupted turn immediately (interruption marker + user message)
            // so it survives process death (e.g. CLI ESC, time limit) before the next save point.
            if (cancelled) {
                agent.persistInterruption(token.getReason());
            }
        } else {
            agent.cancel();
        }
    }

    public void interruptTurn() {
        debug("interrupting current turn");
        var token = agent.getExecutionContext().getCancellationToken();
        if (token != null) {
            token.interrupt();
        }
    }

    @Override
    public void onEvent(AgentEventListener listener) {
        listeners.add(listener);
    }

    @Override
    public void removeEvent(AgentEventListener listener) {
        listeners.remove(listener);
    }

    @Override
    public void approveToolCall(String callId, ApprovalDecision decision) {
        logger.debug("approveToolCall: callId={}, decision={}, sessionId={}", callId, decision, sessionId);
        permissionGate.respond(callId, decision);
    }

    /**
     * True while the driver thread is actually executing a turn. A turn whose thread died without
     * terminating cleanly reports false, so callers can expire stale turn state instead of trusting it.
     */
    public boolean isTurnRunning() {
        return turnDriver.isProcessing();
    }

    @Override
    public void close() {
        logger.debug("closing agent session, sessionId={}", sessionId);
        turnDriver.shutdown();
        // A forced close (idle cleanup, explicit close, pod shutdown) interrupts the turn thread
        // mid-flight and it may never reach its own terminal dispatch. Emit one here so listeners —
        // turn-state registry, message persistence, SSE clients — never see a turn that runs forever.
        // dispatchTerminal is a CAS, so whichever side gets there first is the only one that fires.
        if (turnActive.get()) {
            logger.warn("session closed while a turn was still running, aborting it, sessionId={}", sessionId);
            dispatchTerminal(TurnCompleteEvent.cancelled(sessionId, agent.getOutput()), SessionStatus.IDLE);
        }
    }

    public void setOnIdle(Runnable onIdle) {
        turnDriver.setOnIdle(onIdle);
    }

    public void loadTools(List<ai.core.tool.ToolCall> tools) {
        agent.addTools(tools);
        logger.info("loaded {} tools to session, sessionId={}", tools.size(), sessionId);
    }

    public void dispatchEvent(AgentEvent event) {
        dispatch(event);
    }

    /**
     * Delivers the terminal state of a long-running tool call the same way a background agent's
     * completion is delivered: queued as a task notification (a turn starts when the session is idle)
     * plus a status event for the UI.
     */
    public void notifyTask(String taskId, String status, String notificationXml) {
        commandQueue.enqueueTaskNotification(notificationXml);
        dispatch(TaskStatusEvent.of(sessionId, taskId, status));
    }

    private void setupCompressionListener() {
        var compression = agent.getCompression();
        if (compression == null) return;
        compression.setListener((beforeCount, afterCount, completed) ->
            dispatch(CompressionEvent.of(sessionId, beforeCount, afterCount, completed)));
    }

    /**
     * Ends the current turn exactly once: dispatches the turn-ending event followed by the matching
     * status change. Both the turn thread and {@link #close()} call this, and the CAS guarantees only
     * one of them wins — a turn can neither be terminated twice nor left without a terminal event.
     */
    private void dispatchTerminal(AgentEvent turnEnd, SessionStatus status) {
        if (!turnActive.compareAndSet(true, false)) return;
        dispatch(turnEnd);
        dispatch(StatusChangeEvent.of(sessionId, status));
    }

    private void dispatch(AgentEvent event) {
        logger.debug("dispatching event: {}, sessionId={}, thread={}", event.getClass().getSimpleName(), sessionId, Thread.currentThread().getName());
        for (AgentEventListener listener : listeners) {
            try {
                switch (event) {
                    case TextChunkEvent e -> listener.onTextChunk(e);
                    case ReasoningChunkEvent e -> listener.onReasoningChunk(e);
                    case ReasoningCompleteEvent e -> listener.onReasoningComplete(e);
                    case ToolStartEvent e -> listener.onToolStart(e);
                    case ToolResultEvent e -> listener.onToolResult(e);
                    case ToolApprovalRequestEvent e -> listener.onToolApprovalRequest(e);
                    case TurnCompleteEvent e -> listener.onTurnComplete(e);
                    case ErrorEvent e -> listener.onError(e);
                    case StatusChangeEvent e -> listener.onStatusChange(e);
                    case OnToolEvent e -> listener.onOnTool(e);
                    case PlanUpdateEvent e -> listener.onPlanUpdate(e);
                    case CompressionEvent e -> listener.onCompression(e);
                    case SandboxEvent e -> listener.onSandbox(e);
                    case EnvironmentOutputChunkEvent e -> listener.onEnvironmentOutput(e);
                    case BatchToolStartEvent e -> listener.onBatchToolStart(e);
                    case TaskStatusEvent e -> listener.onTaskStatus(e);
                    default -> {
                    }
                }
            } catch (RuntimeException e) {
                logger.error("failed to dispatch event to listener, event={}, sessionId={}", event.getClass().getSimpleName(), sessionId, e);
            }
        }
    }

    private void debug(String message) {
        if ("true".equals(System.getProperty("core.ai.debug"))) {
            logger.debug("[DEBUG] {}, sessionId={}", message, sessionId);
        }
    }

    private Function<String, String> toolTypeResolver() {
        return toolName -> {
            var tools = agent.getToolCalls();
            for (var tool : tools) {
                if (tool.getName().equalsIgnoreCase(toolName)) return tool.getSourceType();
            }
            for (var tool : tools) {
                if (tool.getName().endsWith(toolName)) return tool.getSourceType();
            }
            return "builtin";
        };
    }
}
