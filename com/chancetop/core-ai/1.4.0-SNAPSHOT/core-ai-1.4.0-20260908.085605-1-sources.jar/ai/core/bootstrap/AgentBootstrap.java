package ai.core.bootstrap;

import ai.core.document.Tokenizer;
import ai.core.llm.LLMProvider;
import ai.core.llm.LLMProviderConfig;
import ai.core.llm.LLMProviderType;
import ai.core.llm.LLMProviders;
import ai.core.llm.providers.LiteLLMProvider;
import ai.core.mcp.client.McpClientManager;
import ai.core.mcp.client.McpClientManagerRegistry;
import ai.core.persistence.PersistenceProviderType;
import ai.core.persistence.PersistenceProviders;
import ai.core.persistence.providers.FilePersistenceProvider;
import ai.core.persistence.providers.RedisPersistenceProvider;
import ai.core.persistence.providers.TemporaryPersistenceProvider;
import ai.core.prompt.langfuse.LangfusePromptConfig;
import ai.core.prompt.langfuse.LangfusePromptProvider;
import ai.core.prompt.langfuse.LangfusePromptProviderRegistry;
import ai.core.prompt.system.SystemPromptConfig;
import ai.core.prompt.system.SystemPromptProvider;
import ai.core.telemetry.AgentTracer;
import ai.core.telemetry.FlowTracer;
import ai.core.telemetry.GroupTracer;
import ai.core.telemetry.LLMTracer;
import ai.core.telemetry.TelemetryConfig;
import ai.core.telemetry.TracerBundle;
import ai.core.telemetry.TracerRegistry;
import ai.core.utils.JsonUtil;
import ai.core.vectorstore.VectorStoreProvider;
import ai.core.vectorstore.VectorStoreType;
import ai.core.vectorstore.VectorStores;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.ServiceLoader;

/**
 * @author stephen
 */
public class AgentBootstrap {
    private final Logger logger = LoggerFactory.getLogger(AgentBootstrap.class);
    private final PropertySource props;
    private LLMTracer llmTracer;

    public AgentBootstrap(PropertySource props) {
        this.props = props;
    }

    public BootstrapResult initialize() {
        var result = new BootstrapResult();
        configurePersistenceProviders(result);
        configureVectorStores(result);
        configureTelemetry(result);
        configureLangfusePrompts(result);
        configureSystemPromptProvider(result);
        configureLLMProviders(result);
        configureMcpClient(result);
        warmup();
        return result;
    }

    private void warmup() {
        logger.debug("Warming up tokenizer...");
        Tokenizer.warmup();
        logger.debug("Tokenizer warmup completed");
    }

    private void configurePersistenceProviders(BootstrapResult result) {
        var providers = new PersistenceProviders();
        result.persistenceProviders = providers;

        props.property("sys.redis.host").ifPresent(host -> {
            var provider = new RedisPersistenceProvider();
            result.redisPersistenceProvider = provider;
            providers.addPersistenceProvider(PersistenceProviderType.REDIS, provider);
        });

        var temporaryProvider = new TemporaryPersistenceProvider();
        result.temporaryPersistenceProvider = temporaryProvider;
        providers.addPersistenceProvider(PersistenceProviderType.TEMPORARY, temporaryProvider);

        props.property("sys.persistence.file.directory").ifPresent(dir -> {
            var provider = new FilePersistenceProvider(dir);
            result.filePersistenceProvider = provider;
            providers.addPersistenceProvider(PersistenceProviderType.FILE, provider);
        });
    }

    private void configureVectorStores(BootstrapResult result) {
        var vectorStores = new VectorStores();
        result.vectorStores = vectorStores;

        var providers = ServiceLoader.load(VectorStoreProvider.class).stream()
                .map(ServiceLoader.Provider::get)
                .toList();
        for (var provider : providers) {
            if (provider.enabled(props::property)) {
                vectorStores.addVectorStore(provider.type(), provider.create(props::property));
            }
        }
        failIfConfiguredButMissing(vectorStores, "sys.milvus.uri", VectorStoreType.MILVUS);
        failIfConfiguredButMissing(vectorStores, "sys.hnswlib.path", VectorStoreType.HNSW_LIB);
    }

    private void failIfConfiguredButMissing(VectorStores vectorStores, String property, VectorStoreType type) {
        if (props.property(property).isPresent() && vectorStores.getVectorStore(type) == null) {
            throw new IllegalStateException(property + " is configured but no " + type
                    + " vector store provider found on classpath; add the corresponding core-ai-vectorstore module");
        }
    }

    private void configureTelemetry(BootstrapResult result) {
        var endpoint = props.property("trace.otlp.endpoint").orElse(null);
        var serviceName = props.property("trace.service.name").orElse("core-ai");
        var serviceVersion = props.property("trace.service.version").orElse("1.0.0");
        var environment = props.property("trace.environment").orElse("production");

        var telemetryConfigBuilder = TelemetryConfig.builder()
                .serviceName(serviceName)
                .serviceVersion(serviceVersion)
                .environment(environment)
                .otlpEndpoint(endpoint)
                .enabled(true);

        var publicKey = props.property("trace.otlp.public.key");
        var secretKey = props.property("trace.otlp.secret.key");
        if (publicKey.isPresent() && secretKey.isPresent()) {
            var credentials = publicKey.get() + ":" + secretKey.get();
            var encodedCredentials = Base64.getEncoder().encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
            telemetryConfigBuilder.addHeader("Authorization", "Basic " + encodedCredentials);
            logger.debug("Langfuse Basic Auth configured for OTLP export");
        }

        var telemetryConfig = telemetryConfigBuilder.build();
        result.telemetryConfig = telemetryConfig;

        var openTelemetry = telemetryConfig.getOpenTelemetry();
        var enabled = telemetryConfig.isEnabled();

        llmTracer = new LLMTracer(openTelemetry, enabled);
        var agentTracer = new AgentTracer(openTelemetry, enabled);
        var flowTracer = new FlowTracer(openTelemetry, enabled);
        var groupTracer = new GroupTracer(openTelemetry, enabled);

        result.llmTracer = llmTracer;
        result.agentTracer = agentTracer;
        result.flowTracer = flowTracer;
        result.groupTracer = groupTracer;
        result.tracerBundle = new TracerBundle(agentTracer, flowTracer, groupTracer);

        TracerRegistry.setAgentTracer(agentTracer);
        TracerRegistry.setFlowTracer(flowTracer);
        TracerRegistry.setGroupTracer(groupTracer);

        if (endpoint != null && !endpoint.isEmpty()) {
            logger.debug("OpenTelemetry tracing enabled - service: {}, version: {}, environment: {}, endpoint: {}",
                    serviceName, serviceVersion, environment, endpoint);
        } else {
            logger.debug("OpenTelemetry tracing enabled in local mode - service: {}, version: {}, environment: {}",
                    serviceName, serviceVersion, environment);
        }
    }

    private void configureLangfusePrompts(BootstrapResult result) {
        props.property("langfuse.prompt.base.url").ifPresent(baseUrl -> {
            logger.debug("Initializing Langfuse prompt management with base URL: {}", baseUrl);

            var configBuilder = LangfusePromptConfig.builder()
                    .baseUrl(baseUrl);

            var publicKey = props.property("langfuse.prompt.public.key");
            var secretKey = props.property("langfuse.prompt.secret.key");
            if (publicKey.isPresent() && secretKey.isPresent()) {
                configBuilder.credentials(publicKey.get(), secretKey.get());
                logger.debug("Langfuse prompt credentials configured");
            }

            props.property("langfuse.prompt.timeout.seconds").ifPresent(timeout ->
                    configBuilder.timeoutSeconds(Integer.parseInt(timeout))
            );

            var config = configBuilder.build();
            var promptProvider = new LangfusePromptProvider(config, true);

            result.langfusePromptConfig = config;
            result.langfusePromptProvider = promptProvider;

            LangfusePromptProviderRegistry.setProvider(promptProvider);

            logger.debug("Langfuse prompt management enabled and registered globally");
        });

        if (props.property("langfuse.prompt.base.url").isEmpty()) {
            logger.debug("Langfuse prompt management disabled - langfuse.prompt.base.url not configured");
            LangfusePromptProviderRegistry.clear();
        }
    }

    private void configureSystemPromptProvider(BootstrapResult result) {
        props.property("system.prompt.api.base.url").ifPresent(baseUrl -> {
            var configBuilder = SystemPromptConfig.builder().baseUrl(baseUrl);
            props.property("system.prompt.api.key").ifPresent(configBuilder::apiKey);
            props.property("system.prompt.timeout.seconds").ifPresent(timeout ->
                configBuilder.timeoutSeconds(Integer.parseInt(timeout)));
            configBuilder.trustAll(Boolean.parseBoolean(props.property("system.prompt.api.trust.all").orElse("false")));
            var config = configBuilder.build();
            var provider = new SystemPromptProvider(config, true);

            result.systemPromptProvider = provider;
            logger.debug("System prompt provider initialized with base URL: {}", baseUrl);
        });

        if (props.property("system.prompt.api.base.url").isEmpty()) {
            logger.debug("System prompt provider disabled - system.prompt.api.base.url not configured");
        }
    }

    private void configureLLMProviders(BootstrapResult result) {
        var providers = new LLMProviders();
        result.llmProviders = providers;
        var config = setupLLMProperties();

        // LiteLLM
        props.property("litellm.api.base").ifPresent(base -> {
            var providerConfig = createProviderConfig(config, "litellm");
            var provider = new LiteLLMProvider(providerConfig, props.requiredProperty("litellm.api.base"), props.property("litellm.api.key").orElse(""));
            injectTracerIfAvailable(provider);
            result.liteLLMProvider = provider;
            providers.addProvider(LLMProviderType.LITELLM, provider);
        });

        // OpenRouter
        props.property("openrouter.api.key").ifPresent(key -> {
            var providerConfig = createProviderConfig(config, "openrouter");
            var provider = new LiteLLMProvider(providerConfig, "https://openrouter.ai/api/v1", key);
            injectTracerIfAvailable(provider);
            result.openRouterProvider = provider;
            providers.addProvider(LLMProviderType.OPENROUTER, provider);
        });

        // DeepSeek
        props.property("deepseek.api.key").ifPresent(key -> {
            var providerConfig = createProviderConfig(config, "deepseek");
            var provider = new LiteLLMProvider(providerConfig, "https://api.deepseek.com/v1", key);
            injectTracerIfAvailable(provider);
            result.deepSeekProvider = provider;
            providers.addProvider(LLMProviderType.DEEPSEEK, provider);
        });

        // Azure OpenAI
        props.property("azure.api.key").ifPresent(key -> props.property("azure.api.base").ifPresent(base -> {
            var providerConfig = createProviderConfig(config, "azure");
            var provider = new LiteLLMProvider(providerConfig, props.requiredProperty("azure.api.base"), key);
            injectTracerIfAvailable(provider);
            result.azureProvider = provider;
            providers.addProvider(LLMProviderType.AZURE, provider);
        }));

        // OpenAI
        props.property("openai.api.key").ifPresent(key -> {
            var providerConfig = createProviderConfig(config, "openai");
            var provider = new LiteLLMProvider(providerConfig, props.requiredProperty("openai.api.base"), key);
            injectTracerIfAvailable(provider);
            result.openAIProvider = provider;
            providers.addProvider(LLMProviderType.OPENAI, provider);
        });
    }

    @SuppressWarnings("unchecked")
    private void configureMcpClient(BootstrapResult result) {
        props.property("mcp.servers.json").ifPresent(json -> {
            try {
                var mcpServersConfig = (Map<String, Object>) JsonUtil.fromJson(Map.class, json);
                var manager = McpClientManager.fromConfig(mcpServersConfig);
                McpClientManagerRegistry.notifyCreation(manager);
                manager.warmup();
                result.mcpClientManager = manager;
                McpClientManagerRegistry.setManager(manager);

                logger.debug("McpClientManager initialized with {} servers: {}",
                        manager.getServerNames().size(),
                        manager.getServerNames());
            } catch (Exception e) {
                logger.error("Failed to parse mcp.servers.json", e);
            }
        });

        if (props.property("mcp.servers.json").isEmpty()) {
            logger.debug("MCP client disabled - mcp.servers.json not configured");
            McpClientManagerRegistry.clear();
        }
    }

    private LLMProviderConfig setupLLMProperties() {
        var config = new LLMProviderConfig(null, 0.7d, "text-embedding-3-large");
        applyConfigProperties(config, "llm");
        if (config.getModel() == null) {
            config.setModel("deepseek/deepseek-v4-flash");
        }
        if (config.getMultiModalModel() == null) {
            config.setMultiModalModel("azure/responses/gpt-5-mini");
        }
        return config;
    }

    private LLMProviderConfig createProviderConfig(LLMProviderConfig baseConfig, String prefix) {
        var config = new LLMProviderConfig(baseConfig);
        applyConfigProperties(config, prefix);
        return config;
    }

    private void applyConfigProperties(LLMProviderConfig config, String prefix) {
        props.property(prefix + ".model").ifPresent(config::setModel);
        props.property(prefix + ".model.multimodal").ifPresent(config::setMultiModalModel);
        props.property(prefix + ".temperature").ifPresent(v -> config.setTemperature(Double.parseDouble(v)));
        props.property(prefix + ".embeddings.model").ifPresent(config::setEmbeddingModel);
        props.property(prefix + ".request.extra_body").ifPresent(config::setRequestExtraBody);
        props.property(prefix + ".timeout.seconds").ifPresent(v -> config.setTimeout(Long.valueOf(v)));
        props.property(prefix + ".connect.timeout.seconds").ifPresent(v -> config.setConnectTimeout(Long.valueOf(v)));
        props.property(prefix + ".stream.buffer.size").ifPresent(v -> config.setStreamBufferSize(Integer.parseInt(v)));
        applyModelExtraBodies(config, prefix);
    }

    private void applyModelExtraBodies(LLMProviderConfig config, String prefix) {
        var extraBodyPrefix = prefix + ".request.extra_body.";
        for (var key : props.propertyNames()) {
            if (key.startsWith(extraBodyPrefix) && key.length() > extraBodyPrefix.length()) {
                var modelName = key.substring(extraBodyPrefix.length());
                props.property(key).ifPresent(extraBody -> config.addModelExtraBody(modelName, extraBody));
            }
        }
    }

    private void injectTracerIfAvailable(LLMProvider provider) {
        if (llmTracer != null) {
            provider.setTracer(llmTracer);
        }
    }
}
