package ai.core.agent.internal;

import ai.core.agent.AttachedContent;
import ai.core.agent.ExecutionContext;
import ai.core.llm.InputModality;
import ai.core.llm.ModalityRuntimeOverrides;
import ai.core.llm.ModalitySupport;
import ai.core.llm.ModelModalityRegistry;
import ai.core.llm.streaming.DefaultStreamingCallback;
import ai.core.llm.streaming.StreamingCallback;
import ai.core.llm.domain.Content;
import ai.core.llm.domain.FunctionCall;
import ai.core.llm.domain.Message;
import ai.core.llm.domain.RoleType;
import ai.core.llm.domain.Tool;
import ai.core.prompt.Prompts;
import ai.core.reflection.ReflectionConfig;
import ai.core.reflection.ReflectionEvaluation;
import ai.core.tool.ToolCall;
import ai.core.tool.ToolCallResult;
import ai.core.tool.tools.CaptionImageTool;
import ai.core.tool.tools.GenerateImageTool;
import ai.core.utils.ImageDownscaler;
import ai.core.utils.ImageFormats;
import core.framework.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * @author stephen
 */
public class AgentHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger(AgentHelper.class);

    public static List<Tool> toReqTools(List<ToolCall> toolCalls) {
        return toolCalls.stream().filter(ToolCall::isLlmVisible).map(ToolCall::toTool).toList();
    }

    public static String specialReminder(String toolName, String toolResult) {
        return Prompts.TOOL_DIRECT_RETURN_REMINDER_PROMPT.formatted(toolName, toolResult);
    }

    public static StreamingCallback elseDefaultCallback(StreamingCallback streamingCallback) {
        return streamingCallback == null ? new DefaultStreamingCallback() : streamingCallback;
    }

    public static boolean lastIsToolMsg(List<Message> messages) {
        return RoleType.TOOL == messages.getLast().role;
    }

    public static String lastUserMessageText(List<Message> messages) {
        if (messages == null || messages.isEmpty()) return null;
        var lastMessage = messages.getLast();
        if (lastMessage == null || !RoleType.USER.equals(lastMessage.role)) return null;
        return lastMessage.getTextContent();
    }

    public static boolean isValidEvaluation(ReflectionEvaluation evaluation) {
        return evaluation.getScore() >= 1 && evaluation.getScore() <= 10;
    }

    public static String buildRequestName(boolean isToolCall) {
        return isToolCall ? "tool" : "user";
    }

    public static boolean shouldTerminateReflection(ReflectionConfig reflectionConfig, ReflectionEvaluation eval, int round) {
        if (eval.isPass() && eval.getScore() >= ReflectionConfig.DEFAULT_REFLECTION_CONTINUE_SCORE) return true;
        if (!eval.isShouldContinue()) return true;
        return round >= reflectionConfig.minRound() && eval.getScore() >= ReflectionConfig.DEFAULT_REFLECTION_CONTINUE_SCORE;
    }

    public static String generateToolCallId() {
        return "slash_command_" + UUID.randomUUID().toString().replace("-", "").substring(0, 16);
    }

    public static Message buildToolMessage(FunctionCall tool, ToolCallResult result) {
        return buildToolMessage(tool, result, false, null);
    }

    public static Message buildToolMessage(FunctionCall tool, ToolCallResult result, boolean isDirectReturn) {
        return buildToolMessage(tool, result, isDirectReturn, null);
    }

    public static Message buildToolMessage(FunctionCall tool, ToolCallResult result, boolean isDirectReturn, ExecutionContext context) {
        return switch (result.getType()) {
            case TEXT -> Message.of(RoleType.TOOL, buildTextContent(result, isDirectReturn, context),
                    tool.function.name, tool.id, null);
            case IMAGE -> context != null && !context.isVisionNative()
                    ? Message.of(RoleType.TOOL, buildImageReference(tool, result, context), tool.function.name, tool.id, null)
                    : Message.of(new Message.MessageRecord(RoleType.TOOL, buildImageContent(result), "", tool.function.name, tool.id, null));
        };
    }

    public static boolean resolveVisionNative(String model, ModelModalityRegistry registry) {
        return registry.supports(model, InputModality.IMAGE) != ModalitySupport.UNSUPPORTED;
    }

    // a natively-seeing model misuses a redundant caption tool; hide it and let images flow inline.
    // once 400 auto-heal marks the effective model text-only, the tool must reappear or the
    // downgraded placeholders would point at a tool the model cannot call
    public static List<Tool> filterRedundantVisionTools(List<Tool> tools, boolean visionNative, String effectiveModel) {
        if (!visionNative || tools == null) return tools;
        if (ModalityRuntimeOverrides.isMarkedUnsupported(effectiveModel, InputModality.IMAGE)) return tools;
        return tools.stream()
                .filter(tool -> tool.function == null || !CaptionImageTool.TOOL_NAME.equals(tool.function.name))
                .toList();
    }

    // text-model path: persist the image and hand the model a reference it can inspect via caption_image
    private static String buildImageReference(FunctionCall tool, ToolCallResult result, ExecutionContext context) {
        var url = persistImage(result.getImageBase64(), result.getImageFormat(), context);
        if (url != null) {
            return Strings.format("[Image result: {}] The current model cannot view images directly. Call caption_image with this url to inspect it.", url);
        }
        return Strings.format("[Image result from tool {}] The current model cannot view images directly. Call caption_image with the original image path or url to inspect it.", tool.function.name);
    }

    private static String persistImage(String base64, String format, ExecutionContext context) {
        var sink = context.getCustomVariable(GenerateImageTool.IMAGE_OUTPUT_SINK_CONTEXT_KEY, GenerateImageTool.ImageOutputSink.class);
        if (sink == null) return null;
        try {
            var extension = format != null && format.contains("/") ? format.substring(format.indexOf('/') + 1) : "png";
            var contentType = format != null && format.contains("/") ? format : "image/" + extension;
            var bytes = Base64.getDecoder().decode(base64);
            return sink.save("tool-image-" + UUID.randomUUID() + "." + extension, contentType, bytes);
        } catch (Exception e) {
            LOGGER.warn("failed to persist image, falling back to reference without url", e);
            return null;
        }
    }

    private static String buildTextContent(ToolCallResult result, boolean isDirectReturn, ExecutionContext context) {
        var text = isDirectReturn
                ? specialReminder(result.getToolName(), result.toResultForLLM())
                : result.toResultForLLM();
        return appendBudgetStatus(text, result, context);
    }

    private static String appendBudgetStatus(String text, ToolCallResult result, ExecutionContext context) {
        if (context == null) return text;
        var budget = context.getRunBudget();
        if (budget == null) return text;
        var sb = new StringBuilder(text == null ? "" : text);
        if (!sb.isEmpty()) sb.append("\n\n");
        sb.append("[run budget @ ")
                .append(DateTimeFormatter.ISO_INSTANT.format(Instant.now().truncatedTo(ChronoUnit.SECONDS)))
                .append("] ").append(budget.briefStatus());
        var requested = number(result.getStats().get("budget.timeout.requested_ms"));
        var effective = number(result.getStats().get("budget.timeout.effective_ms"));
        if (requested != null && effective != null && effective < requested) {
            sb.append(", timeout reduced ").append(requested / 1000).append("s -> ")
                    .append(effective / 1000).append('s');
        }
        sb.append('.');
        return sb.toString();
    }

    private static Long number(Object value) {
        return value instanceof Number number ? number.longValue() : null;
    }

    private static List<Content> buildImageContent(ToolCallResult result) {
        // the image is carried in the history and resent on every later turn, so an unreadable payload (an
        // error body saved as probe.png, a non-image MCP content part) must not reach the model: the API
        // rejects the whole request with HTTP 400 and the run dies far away from the mistake
        var format = ImageFormats.detectBase64(result.getImageBase64());
        if (!ImageFormats.isModelReadable(format)) {
            LOGGER.warn("dropping image content that is not a readable image, tool={}, declaredFormat={}, detectedFormat={}",
                    result.getToolName(), result.getImageFormat(), format);
            return List.of(Content.of(Strings.format(
                    "[Image result from tool {} was dropped: its content is not a readable image ({}), so it was not sent to the model.]",
                    result.getToolName(), ImageFormats.READABLE_FORMAT_LIST)));
        }
        // the image is carried in the history and resent on every later turn, so shrink it once here
        var image = ImageDownscaler.shrink(result.getImageBase64(), ImageFormats.mimeType(format));
        return List.of(Content.of(Prompts.IMAGE_CAPTIONING_PROMPT),
                Content.of(Content.ImageUrl.of(Strings.format("data:{};base64,{}", image.format(), image.data()), image.format())));
    }

    public static Message buildUserMessage(String query, ExecutionContext context) {
        var attachedContents = context.getAttachedContents();
        if (attachedContents == null || attachedContents.isEmpty()) {
            return Message.of(RoleType.USER, query, buildRequestName(false), null, null);
        }
        var contents = new java.util.ArrayList<Content>(attachedContents.size() * 2 + 1);
        contents.add(Content.of(withoutDuplicateAttachmentUrls(query, attachedContents)));
        var imageOrdinal = 0;
        var fileOrdinal = 0;
        for (var attachedContent : attachedContents) {
            if (attachedContent.type == AttachedContent.AttachedContentType.VIDEO) continue;
            String label;
            if (attachedContent.type == AttachedContent.AttachedContentType.IMAGE) {
                imageOrdinal++;
                label = attachmentLabel("Image", imageOrdinal, attachedContent.filename);
            } else {
                fileOrdinal++;
                label = attachmentLabel("File", fileOrdinal, attachedContent.filename);
            }
            // The label sits directly before its content part so the model binds the name by adjacency;
            // this works the same on the native vision path and on the caption/tool reference path.
            contents.add(Content.of(label));
            contents.add(buildAttachedContent(attachedContent, context));
        }
        attachedContents.stream()
                .filter(attachedContent -> attachedContent.type == AttachedContent.AttachedContentType.VIDEO)
                .map(AgentHelper::buildVideoReferenceHint)
                .map(Content::of)
                .forEach(contents::add);
        return Message.of(new Message.MessageRecord(
            RoleType.USER,
            contents,
            null,
            buildRequestName(false),
            null,
            null));
    }

    public static Message buildUserMessage(String query, AttachedContent attachedContent) {
        if (attachedContent == null) {
            return Message.of(RoleType.USER, query, buildRequestName(false), null, null);
        }
        return Message.of(new Message.MessageRecord(
            RoleType.USER,
            List.of(Content.of(query), buildAttachedContent(attachedContent)),
            null,
            buildRequestName(false),
            null,
            null));
    }

    private static String attachmentLabel(String kind, int ordinal, String filename) {
        if (filename == null || filename.isBlank()) return "[" + kind + " " + ordinal + "]";
        return "[" + kind + " " + ordinal + ": " + filename + "]";
    }

    private static String buildVideoReferenceHint(AttachedContent attachedContent) {
        var name = attachedContent.filename != null ? attachedContent.filename : "video";
        return "[Video attachment: " + name + "]\n"
                + "reference: " + attachedContent.url + "\n"
                + "The video content cannot be read or downloaded directly. To answer any question about this video, "
                + "you MUST call the understand_video tool with attachment_reference_id=\"" + attachedContent.url + "\".";
    }

    public static Content buildAttachedContent(AttachedContent attachedContent) {
        return buildAttachedContent(attachedContent, null);
    }

    private static Content buildAttachedContent(AttachedContent attachedContent, ExecutionContext context) {
        return switch (attachedContent.type) {
            case IMAGE -> buildImageAttachedContent(attachedContent, context);
            case PDF -> buildPdfAttachedContent(attachedContent, context);
            case VIDEO -> throw new IllegalStateException("video references must be resolved by understand_video tool");
        };
    }

    private static Content buildImageAttachedContent(AttachedContent attachedContent, ExecutionContext context) {
        if (!attachedContent.isBase64()) {
            var captionPath = context != null && !context.isVisionNative();
            if (captionPath) return Content.of(imageReferenceText(attachedContent.url));
            return Content.of(Content.ImageUrl.of(attachedContent.url, null));
        }
        var referenceUrl = captionPathUrl(attachedContent, context);
        if (referenceUrl != null) {
            return Content.of(imageReferenceText(referenceUrl));
        }
        var format = ImageFormats.detectBase64(attachedContent.data);
        if (!ImageFormats.isModelReadable(format)) {
            LOGGER.warn("dropping attachment that is not a readable image, filename={}, declaredMediaType={}, detectedFormat={}",
                    attachedContent.filename, attachedContent.mediaType, format);
            var name = attachedContent.filename == null || attachedContent.filename.isBlank()
                    ? "Image attachment" : "Image attachment " + attachedContent.filename;
            return Content.of(Strings.format("[{} was dropped: its content is not a readable image ({}), so it was not sent to the model.]",
                    name, ImageFormats.READABLE_FORMAT_LIST));
        }
        var image = ImageDownscaler.shrink(attachedContent.data, ImageFormats.mimeType(format));
        var dataUri = Strings.format("data:{};base64,{}", image.format(), image.data());
        return Content.of(Content.ImageUrl.of(dataUri, image.format()));
    }

    private static String imageReferenceText(String url) {
        return Strings.format("[Image attachment: {}] The current model cannot view images directly. Call caption_image with this url to inspect it.", url);
    }

    private static String captionPathUrl(AttachedContent attachedContent, ExecutionContext context) {
        if (context == null || context.isVisionNative()) return null;
        if (attachedContent.url != null && !attachedContent.url.isBlank()) return attachedContent.url;
        return persistImage(attachedContent.data, attachedContent.mediaType, context);
    }

    private static String withoutDuplicateAttachmentUrls(String query, List<AttachedContent> attachedContents) {
        if (query == null || query.isBlank()) return query;
        var urls = attachedContents.stream()
                .map(content -> content.url)
                .filter(url -> url != null && !url.isBlank())
                .collect(Collectors.toSet());
        if (urls.isEmpty()) return query;
        return query.lines()
                .filter(line -> !urls.contains(line.strip()))
                .collect(Collectors.joining("\n"))
                .stripTrailing();
    }

    private static Content buildPdfAttachedContent(AttachedContent attachedContent, ExecutionContext context) {
        if (!attachedContent.isBase64()) return Content.ofFileUrl(attachedContent.url);
        var referenceUrl = captionPathUrl(attachedContent, context);
        if (referenceUrl != null) {
            return Content.of(Strings.format("[File attachment: {}] The current model cannot read files directly. Call summarize_pdf with this url to inspect it.", referenceUrl));
        }
        var filename = attachedContent.filename != null ? attachedContent.filename : "document.pdf";
        return Content.ofFileBase64(attachedContent.data, attachedContent.mediaType, filename);
    }
}
