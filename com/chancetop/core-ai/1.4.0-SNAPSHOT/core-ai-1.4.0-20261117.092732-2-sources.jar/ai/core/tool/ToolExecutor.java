package ai.core.tool;

import ai.core.agent.ExecutionContext;
import ai.core.agent.NodeStatus;
import ai.core.agent.lifecycle.AbstractLifecycle;
import ai.core.llm.domain.FunctionCall;
import ai.core.llm.domain.Usage;
import ai.core.sandbox.SandboxImageReader;
import ai.core.telemetry.AgentTracer;
import ai.core.tool.async.AsyncToolTaskExecutor;
import ai.core.tool.tools.AsyncTaskOutputTool;
import ai.core.tool.tools.ReadFileTool;
import ai.core.tool.tools.WriteFileTool;
import ai.core.tool.tools.WriteTodosTool;
import ai.core.utils.JsonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import core.framework.json.JSON;
import core.framework.util.Strings;
import io.opentelemetry.api.trace.SpanContext;
import io.opentelemetry.context.Context;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * @author stephen
 */
public class ToolExecutor {
    private static final Logger LOGGER = LoggerFactory.getLogger(ToolExecutor.class);

    private static String timestamp() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
    }

    private static String prettyContent(String content) {
        try {
            var parsed = JsonUtil.OBJECT_MAPPER.readValue(content, Object.class);
            return JsonUtil.OBJECT_MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(parsed);
        } catch (JsonProcessingException ignored) {
            return content;
        }
    }

    private final List<AbstractLifecycle> lifecycles;
    private final AgentTracer tracer;
    private final Consumer<NodeStatus> statusUpdater;
    // Receives the token usage of an LLM call made inside a tool (e.g. caption_image),
    // so the agent can accumulate it into session usage/cost.
    private final BiConsumer<String, Usage> llmUsageConsumer;
    // Supplies the span context of the LLM call that triggered the current tool batch, scoped to the owning agent.
    // Provided by the agent so a sub-agent's tool spans nest under the sub-agent's own LLM span.
    private final Supplier<SpanContext> llmSpanContextSupplier;
    private boolean authenticated = false;

    public ToolExecutor(List<AbstractLifecycle> lifecycles, AgentTracer tracer, Consumer<NodeStatus> statusUpdater,
                        Supplier<SpanContext> llmSpanContextSupplier) {
        this(lifecycles, tracer, statusUpdater, null, llmSpanContextSupplier);
    }

    public ToolExecutor(List<AbstractLifecycle> lifecycles, AgentTracer tracer, Consumer<NodeStatus> statusUpdater,
                        BiConsumer<String, Usage> llmUsageConsumer, Supplier<SpanContext> llmSpanContextSupplier) {
        this.lifecycles = lifecycles;
        this.tracer = tracer;
        this.statusUpdater = statusUpdater;
        this.llmUsageConsumer = llmUsageConsumer;
        this.llmSpanContextSupplier = llmSpanContextSupplier;
    }

    public void setAuthenticated(boolean authenticated) {
        this.authenticated = authenticated;
    }

    public ToolCallResult execute(ToolCall tool, FunctionCall functionCall, ExecutionContext context) {
        Map<String, Object> args;
        try {
            args = tool.parseArguments(functionCall.function.arguments);
        } catch (RuntimeException e) {
            return malformedArgumentsResult(tool, e);
        }
        tool.applyContextArguments(args, context);
        tool.normalizeArguments(args);
        functionCall.function.arguments = JsonUtil.toJson(args);

        lifecycles.forEach(lc -> lc.beforeTool(functionCall, context));
        var result = executeWithoutLifecycle(tool, functionCall, args, context);
        lifecycles.forEach(lc -> lc.afterTool(functionCall, context, result));
        return result;
    }

    public ToolCallResult executeWithoutLifecycle(ToolCall tool, FunctionCall functionCall, ExecutionContext context) {
        try {
            var args = tool.parseArguments(functionCall.function.arguments);
            applyContextArguments(tool, functionCall, args, context);
            return doExecute(tool, functionCall, args, context);
        } catch (RuntimeException e) {
            return malformedArgumentsResult(tool, e);
        }
    }

    public ToolCallResult executeWithoutLifecycle(ToolCall tool, FunctionCall functionCall, Map<String, Object> args, ExecutionContext context) {
        applyContextArguments(tool, functionCall, args, context);
        return doExecute(tool, functionCall, args, context);
    }

    private void applyContextArguments(ToolCall tool, FunctionCall functionCall, Map<String, Object> args, ExecutionContext context) {
        if (tool.applyContextArguments(args, context)) {
            functionCall.function.arguments = JsonUtil.toJson(args);
        }
    }

    private ToolCallResult malformedArgumentsResult(ToolCall tool, RuntimeException error) {
        if (WriteTodosTool.WT_TOOL_NAME.equals(tool.getName())) {
            LOGGER.warn("ignoring malformed write_todos arguments: {}", error.getMessage());
            return ToolCallResult.completed("The todo update was ignored because its arguments were not valid JSON. Continue with the current task.");
        }
        return ToolCallResult.failed(malformedArgumentsMessage(tool), error);
    }

    private String malformedArgumentsMessage(ToolCall tool) {
        if (WriteFileTool.TOOL_NAME.equals(tool.getName())) {
            return "write_file arguments are not valid JSON. The content is likely too large or contains heavily escaped code. "
                + "Write the file skeleton first, then use edit_file to append one chapter or logical section at a time.";
        }
        return "Tool arguments are not valid JSON. Fix the arguments and retry this tool call.";
    }

    @SuppressWarnings({"try", "PMD.UnusedLocalVariable"})
    private ToolCallResult doExecute(ToolCall tool, FunctionCall functionCall, Map<String, Object> args, ExecutionContext context) {
        // Caller identity rides the OpenTelemetry Context so async tool threads (supplyAsync + makeCurrent)
        // see it too; outbound HTTP injection points read it via OutboundCallerContext.current().
        var caller = context.getCaller();
        if (caller != null) {
            try (var scope = OutboundCallerContext.set(caller)) {
                return doExecuteWithCaller(tool, functionCall, args, context);
            }
        }
        return doExecuteWithCaller(tool, functionCall, args, context);
    }

    private ToolCallResult doExecuteWithCaller(ToolCall tool, FunctionCall functionCall, Map<String, Object> args, ExecutionContext context) {
        var sandbox = context.getSandbox();
        var useSandbox = sandbox != null && sandbox.shouldIntercept(tool.getName());

        // strip save_to_file from args before validation and tool execution
        String saveToFile = extractSaveToFile(args);
        if (saveToFile != null) {
            functionCall.function.arguments = JsonUtil.toJson(args);
        }

        var validationResult = validate(tool, args, useSandbox);
        if (validationResult != null) {
            return validationResult;
        }

        LOGGER.debug("tool {}: {}", functionCall.function.name, functionCall.function.arguments);
        var startTime = System.currentTimeMillis();

        ToolCallResult result;
        if (useSandbox) {
            LOGGER.debug("sandbox intercepting tool: {}", tool.getName());
            // a sandbox that cannot be acquired (docker daemon unreachable, pool exhausted) is a failed tool call the
            // agent can report and route around — not a dead turn with nothing shown to the user
            result = traceToolSpan(functionCall, tool.isSubAgent(), () -> executeInSandbox(tool, functionCall, args, context, sandbox));
            result.withStats("executionMode", "sandbox");
            result.withStats("sandboxId", sandbox.getId());
        } else {
            result = executeWithTimeout(tool, functionCall, context);
        }

        result.withToolName(tool.getName()).withDuration(System.currentTimeMillis() - startTime);
        consumeLlmUsage(result, context);
        handleAsyncResult(result, tool, functionCall, context);
        if (result.isCompleted()) markTaskOutputRead(tool, args, context);

        if (saveToFile != null && result.isCompleted()) {
            result = saveResultToFile(saveToFile, result, sandbox, tool.getName());
        } else if (result.isCompleted()) {
            result = ToolResultBudgetPolicy.autoSaveIfNeeded(result, tool, context,
                    (path, savedResult, name) -> saveResultToFile(path, savedResult, sandbox, name));
        }

        LOGGER.debug("tool {} completed in {}ms, stats: {}", result.getToolName(), result.getDurationMs(), result.getStats());
        return result;
    }

    private String extractSaveToFile(Map<String, Object> args) {
        var value = args.remove(ToolCall.SAVE_TO_FILE_PARAM);
        if (value == null) return null;
        var saveToFile = value.toString();
        if (saveToFile.isBlank() || "auto".equals(saveToFile)) {
            return "/workspace/tool_result_" + timestamp() + ".json";
        }
        if (!saveToFile.startsWith("/")) {
            return "/workspace/" + saveToFile;
        }
        return saveToFile;
    }

    private ToolCallResult saveResultToFile(String filePath, ToolCallResult result, ai.core.sandbox.Sandbox sandbox, String toolName) {
        var content = result.getResult();
        if (content == null) return result;
        if (content.length() > ToolCall.MAX_SAVE_TO_FILE_SIZE) {
            double mb = content.length() / (1024.0 * 1024.0);
            return result.withResult(String.format(
                "save_to_file failed: result size (%.1f MB) exceeds limit (10 MB). Use pagination or filtering to reduce result size.", mb));
        }
        try {
            var prettyContent = prettyContent(content);
            writeFile(sandbox, filePath, prettyContent.getBytes(StandardCharsets.UTF_8));

            var schemaJson = ToolResultFormatter.buildSchemaJson(content);
            if (schemaJson != null) {
                var schemaPath = filePath.replaceAll("\\.json$", "") + ".schema.json";
                writeFile(sandbox, schemaPath, schemaJson.getBytes(StandardCharsets.UTF_8));
            }

            return result.withResult(ToolResultFormatter.buildSaveResultMessage(content, filePath));
        } catch (Exception e) {
            LOGGER.warn("save_to_file failed for tool {}, falling back to inline result", toolName, e);
            return result;
        }
    }

    private void writeFile(ai.core.sandbox.Sandbox sandbox, String path, byte[] bytes) throws Exception {
        if (sandbox != null) {
            sandbox.uploadFile(path, bytes);
            return;
        }
        var localPath = path.startsWith("/workspace/") ? path.substring("/workspace/".length()) : path;
        Files.write(Path.of(localPath), bytes);
    }

    private ToolCallResult validate(ToolCall tool, Map<String, Object> args, boolean useSandbox) {
        if (!useSandbox && !authenticated && Boolean.TRUE.equals(tool.isNeedAuth())) {
            statusUpdater.accept(NodeStatus.WAITING_FOR_USER_INPUT);
            return ToolCallResult.failed("This tool call requires user authentication, please ask user to confirm it.");
        }

        var missingParams = tool.findMissingRequiredParams(args);
        if (!missingParams.isEmpty()) {
            LOGGER.warn("tool [{}] call rejected: missing required parameters: {}", tool.getName(), missingParams);
            return ToolCallResult.failed(Strings.format("Tool [{}] call failed: missing required parameters: [{}]. Please provide all required parameters and retry.",
                    tool.getName(), String.join(", ", missingParams)));
        }

        return null;
    }

    private ToolCallResult executeToolCall(ToolCall tool, FunctionCall functionCall, ExecutionContext context) {
        context.setCurrentToolCallId(functionCall.id);
        try {
            return traceToolSpan(functionCall, tool.isSubAgent(), () -> tool.execute(functionCall.function.arguments, context));
        } finally {
            context.clearCurrentToolCallId();
        }
    }

    // The sandbox HTTP call has no per-call timeout of its own (the runtime bounds the command), so a run that is
    // cancelled or timed out must not stay parked on it: the wait is bound to the cancellation token and returns
    // as soon as the token fires, while the abandoned call finishes on its own thread and is discarded.
    @SuppressWarnings({"try", "PMD.UnusedLocalVariable"})
    private ToolCallResult executeInSandbox(ToolCall tool, FunctionCall functionCall, Map<String, Object> args, ExecutionContext context, ai.core.sandbox.Sandbox sandbox) {
        var budget = context.getRunBudget();
        if (budget != null) {
            var requested = tool.getRequestedTimeoutMs(functionCall.function.arguments);
            var decision = budget.admitToolCall(tool.budgetProfile(functionCall.function.arguments, context), requested);
            if (!decision.allowed()) {
                return ToolCallResult.failed(decision.reason());
            }
        }
        var token = context.getCancellationToken();
        if (token == null) {
            return callSandbox(tool, functionCall, args, context, sandbox);
        }
        var otelContext = Context.current();
        var threadRef = new AtomicReference<Thread>();
        var future = CompletableFuture.supplyAsync(() -> {
            threadRef.set(Thread.currentThread());
            try (var scope = otelContext.makeCurrent()) {
                return callSandbox(tool, functionCall, args, context, sandbox);
            }
        }, AsyncToolTaskExecutor.getInstance().getExecutor());
        var unbind = token.onCancel(() -> future.cancel(true));
        try {
            token.throwIfCancelled();
            return ToolCallWait.await(future, 0, tool.getName(), context, threadRef).result();
        } catch (CancellationException e) {
            LOGGER.warn("sandbox tool call abandoned after cancel, tool={}, reason={}", tool.getName(), token.getReason());
            return ToolCallResult.failed(Strings.format("tool call cancelled while running in sandbox (reason={}): {}", token.getReason(), tool.getName()));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            future.cancel(true);
            return ToolCallResult.failed(Strings.format("tool call interrupted: {}", tool.getName()));
        } catch (ExecutionException e) {
            var cause = e.getCause();
            return ToolCallResult.failed(Strings.format("tool call failed<sandbox>: {}", cause != null ? cause.getMessage() : e.getMessage()), cause instanceof Exception ex ? ex : e);
        } finally {
            unbind.run();
        }
    }

    private ToolCallResult callSandbox(ToolCall tool, FunctionCall functionCall, Map<String, Object> args, ExecutionContext context, ai.core.sandbox.Sandbox sandbox) {
        try {
            var imageResult = SandboxImageReader.tryRead(tool.getName(), args, sandbox);
            if (imageResult != null) return imageResult;
            return sandbox.execute(tool.getName(), functionCall.function.arguments, context);
        } catch (RuntimeException e) {
            LOGGER.warn("sandbox execution failed, tool={}", tool.getName(), e);
            return ToolCallResult.failed("SANDBOX_UNAVAILABLE: the sandbox could not run this tool (" + e.getMessage()
                + "). Tell the user; do not retry sandbox tools until it is fixed.", e);
        }
    }

    @SuppressWarnings({"try", "PMD.UnusedLocalVariable"})
    private ToolCallResult executeWithTimeout(ToolCall tool, FunctionCall functionCall, ExecutionContext context) {
        long timeoutMs = tool.getRequestedTimeoutMs(functionCall.function.arguments);
        long requestedTimeout = timeoutMs;
        var budget = context.getRunBudget();
        if (budget != null) {
            var decision = budget.admitToolCall(tool.budgetProfile(functionCall.function.arguments, context), timeoutMs);
            if (!decision.allowed()) {
                return ToolCallResult.failed(decision.reason());
            }
            timeoutMs = decision.effectiveTimeoutMs();
        }

        var otelContext = Context.current();

        var threadRef = new AtomicReference<Thread>();
        var future = CompletableFuture.supplyAsync(() -> {
            threadRef.set(Thread.currentThread());
            try (var scope = otelContext.makeCurrent()) {
                return executeToolCall(tool, functionCall, context);
            }
        }, AsyncToolTaskExecutor.getInstance().getExecutor());

        try {
            var outcome = ToolCallWait.await(future, timeoutMs, functionCall.function.name, context, threadRef);
            if (timeoutMs < requestedTimeout && !outcome.timedOut() && !outcome.cancelled()) {
                outcome.result().withStats("budget.timeout.requested_ms", requestedTimeout)
                        .withStats("budget.timeout.effective_ms", timeoutMs);
            }
            return outcome.result();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            future.cancel(true);
            var asyncThread = threadRef.get();
            if (asyncThread != null) {
                asyncThread.interrupt();
            }
            return ToolCallResult.failed(Strings.format("tool call interrupted: {}", functionCall.function.name));
        } catch (ExecutionException e) {
            var cause = e.getCause();
            return ToolCallResult.failed(Strings.format("tool call failed<execute>:\n{}, cause:\n{}", JSON.toJSON(functionCall), cause != null ? cause.getMessage() : e.getMessage()), cause instanceof Exception ex ? ex : e);
        }
    }

    // Run the action inside a tool span nested under the triggering LLM span; runs the action directly when tracing is off.
    private ToolCallResult traceToolSpan(FunctionCall functionCall, boolean isSubAgent, Supplier<ToolCallResult> action) {
        if (tracer == null) {
            return action.get();
        }
        var llmSpanContext = llmSpanContextSupplier != null ? llmSpanContextSupplier.get() : null;
        return tracer.traceToolCall(functionCall.function.name, functionCall.function.arguments, llmSpanContext, isSubAgent, action);
    }

    private void consumeLlmUsage(ToolCallResult result, ExecutionContext context) {
        if (result.getLlmUsage() != null) {
            if (llmUsageConsumer != null) {
                llmUsageConsumer.accept(result.getLlmModel(), result.getLlmUsage());
            }
            var budget = context.getRunBudget();
            if (budget != null) {
                budget.recordExternalUsage("tool", result.getLlmModel(), result.getLlmUsage());
            }
        } else if (result.getCostUsd() != null) {
            var budget = context.getRunBudget();
            if (budget != null) {
                budget.settleToolCost(result.getCostUsd(), "tool");
            }
        }
    }

    private boolean isFreshTask(ToolCallAsyncTaskManager asyncTaskManager, String taskId, ToolCall tool) {
        var existing = asyncTaskManager.loadTask(taskId);
        if (existing.isEmpty()) return true;
        return existing.get().isTerminal() && tool.getName().equals(existing.get().tool().getName());
    }

    /**
     * A background task's output file is its result. Once the model reads that file the completion
     * notification has nothing left to deliver, so the run is marked consumed and its notification turn
     * is skipped.
     */
    private void markTaskOutputRead(ToolCall tool, Map<String, Object> args, ExecutionContext context) {
        if (!ReadFileTool.TOOL_NAME.equals(tool.getName())) return;
        var taskManager = context.getTaskManager();
        if (taskManager == null) return;
        var path = ToolCall.getStringValue(args, "file_path");
        if (path != null) taskManager.markOutputRead(path);
    }

    private void handleAsyncResult(ToolCallResult result, ToolCall tool, FunctionCall functionCall, ExecutionContext context) {
        if (!result.isPending() && !result.isWaitingForInput()) {
            return;
        }
        // async_task_output only relays another task's status. A relay for a task the manager does not track yet
        // (e.g. one owned by AsyncToolTaskExecutor) must not be registered here: the record would carry a tool that
        // cannot poll, and the next check would drop the task with "does not support polling".
        if (AsyncTaskOutputTool.TOOL_NAME.equals(tool.getName())) return;

        var asyncTaskManager = context.getAsyncTaskManager();
        // Register only fresh async work. A pending result that polls a task the manager already tracks or that a
        // manager owns (poll relay from async_task_output) must not be re-registered: the overwrite would replace
        // the stored tool with the polling tool, which does not support poll and can never turn the task terminal.
        // A finished record under the same id from the same tool is a previous batch, not a live task (tools that
        // key a task per subject, e.g. one render queue per episode, reuse ids): the new work replaces it, otherwise
        // nobody polls it and the session waits for a completion notice that never comes.
        if (asyncTaskManager != null && !result.isManagedTask() && isFreshTask(asyncTaskManager, result.getTaskId(), tool)) {
            var asyncTask = new ToolCallAsyncTask(result.getTaskId(), tool, functionCall, result);
            // tagged with the issuing session so the terminal notification finds its way back
            asyncTaskManager.storeTask(asyncTask, context.getSessionId());
        }

        if (result.isPending()) {
            statusUpdater.accept(NodeStatus.WAITING_FOR_ASYNC_TASK);
        } else {
            statusUpdater.accept(NodeStatus.WAITING_FOR_USER_INPUT);
        }
    }
}
