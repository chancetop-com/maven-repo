package ai.core.sse.internal;

import ai.core.sse.RawSseChannel;
import ai.core.sse.SseQueueLimits;
import core.framework.internal.web.request.RequestImpl;
import core.framework.log.ActionLogContext;
import core.framework.util.Sets;
import core.framework.util.StopWatch;
import core.framework.util.Strings;
import core.framework.web.sse.Channel;
import io.undertow.server.HttpServerExchange;
import org.jspecify.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xnio.ChannelListener;
import org.xnio.channels.StreamSinkChannel;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

class PatchedChannelImpl<T> implements java.nio.channels.Channel, RawSseChannel<T>, Channel.Context {
    private static final Logger LOGGER = LoggerFactory.getLogger(PatchedChannelImpl.class);

    // a writer stuck holding the lock must never stall app shutdown: k8s sigkills the pod once the grace period expires
    static final long SHUTDOWN_LOCK_TIMEOUT_IN_MILLIS = 500;

    // extracted so the framing logic (id:/event:/data: line construction) is unit-testable
    // without standing up the Undertow exchange/sink this class otherwise requires
    static String frame(String id, String event, String data) {
        int capacity = 32 + (id == null ? 0 : id.length()) + (event == null ? 0 : event.length()) + (data == null ? 0 : data.length() + 8);
        var builder = new StringBuilder(capacity);
        if (id != null && !id.isBlank()) builder.append("id: ").append(id).append('\n');
        if (event != null && !event.isBlank()) builder.append("event: ").append(event).append('\n');
        if (data != null) {
            for (String line : data.split("\\R", -1)) {
                builder.append("data: ").append(line).append('\n');
            }
        }
        builder.append('\n');
        return builder.toString();
    }

    final String id = UUID.randomUUID().toString();
    final Set<String> groups = Sets.newConcurrentHashSet();
    final String refId;
    final long startTime = System.nanoTime();
    final String path;
    final String clientIP;

    final WriteListener writeListener = new WriteListener();
    final Deque<byte[]> queue = new ConcurrentLinkedDeque<>();
    // what the queue currently holds: a client that stopped reading must not grow it without bound
    private final AtomicInteger queuedEvents = new AtomicInteger();
    private final AtomicLong queuedBytes = new AtomicLong();

    private final PatchedServerSentEventContextImpl<T> serverSentEventContext;
    private final PatchedServerSentEventWriter<T> builder;

    private final ReentrantLock lock = new ReentrantLock();
    private final HttpServerExchange exchange;
    private final StreamSinkChannel sink;
    private final Map<String, Object> context = new ConcurrentHashMap<>();

    long lastSentTime = startTime;
    long eventCount;
    long eventSize;

    @Nullable
    String traceId;

    PatchedChannelImpl(HttpServerExchange exchange, StreamSinkChannel sink, PatchedServerSentEventContextImpl<T> serverSentEventContext, PatchedServerSentEventWriter<T> builder, String refId, RequestImpl request) {
        this.exchange = exchange;
        this.sink = sink;
        this.serverSentEventContext = serverSentEventContext;
        this.builder = builder;
        this.refId = refId;
        this.path = request.path();
        this.clientIP = request.clientIP();
    }

    @Override
    public boolean send(@Nullable String id, T event) {
        String message = builder.toMessage(id, event);
        return sendBytes(Strings.bytes(message));
    }

    @Override
    public Context context() {
        return this;
    }

    boolean sendBytes(byte[] event) {
        if (exchange.isResponseComplete()) return false;

        var watch = new StopWatch();
        try {
            if (overCapacity()) {
                // the client is not consuming: drop the backlog and close instead of buffering for it
                LOGGER.warn("sse channel queue over capacity, closing, channel={}, queued={}, queuedBytes={}",
                        id, queuedEvents.get(), queuedBytes.get());
                shutdown();
                return false;
            }
            queue.add(event);
            queuedEvents.incrementAndGet();
            queuedBytes.addAndGet(event.length);
            sink.getIoThread().execute(() -> writeListener.handleEvent(sink));

            lastSentTime = System.nanoTime();
            eventCount++;
            eventSize += event.length;

            return true;
        } finally {
            long elapsed = watch.elapsed();
            ActionLogContext.track("sse", elapsed, 0, 1, 0, event.length);
//            LOGGER.debug("send sse message, channel={}, message={}, elapsed={}", id, new BytesLogParam(event), elapsed); // message is not in json format, not masked, assume sse won't send any sensitive event
        }
    }

    @Override
    public boolean sendRawData(String data) {
        return sendBytes(Strings.bytes("data: " + data + "\n\n"));
    }

    @Override
    public boolean sendRawEvent(String event, String data) {
        return sendBytes(Strings.bytes(frame(null, event, data)));
    }

    @Override
    public boolean sendRawEvent(String id, String event, String data) {
        return sendBytes(Strings.bytes(frame(id, event, data)));
    }

    @Override
    public boolean isOpen() {
        return !exchange.isResponseComplete();
    }

    @Override
    public void close() {
        LOGGER.debug("close sse connection, channel={}", id);
        sink.getIoThread().execute(() -> {
            try {
                lock.lock();
                if (exchange.isResponseComplete()) return;

                // for flow like
                // channel.sendBytes("error");
                // channel.close();
                // the close logic (this closure) could run first in different IO thread while sendBytes is blocked due to lock
                // so here we should try to send remaining messages in queue before close
                if (!queue.isEmpty()) {
                    writeListener.handleEvent(sink);
                }
                exchange.endExchange();
            } finally {
                lock.unlock();
            }
        });
    }

    public void shutdown() {
        if (!tryLockForShutdown()) {
            LOGGER.warn("failed to acquire sse channel lock to shutdown after {}ms, channel={}", SHUTDOWN_LOCK_TIMEOUT_IN_MILLIS, id);
            forceEndExchange();
            return;
        }

        try {
            if (exchange.isResponseComplete()) return;

            LOGGER.debug("shutdown sse connection, channel={}", id);
            queue.clear();
            queuedEvents.set(0);
            queuedBytes.set(0);
            exchange.endExchange();
        } finally {
            lock.unlock();
        }
    }

    private boolean tryLockForShutdown() {
        try {
            return lock.tryLock(SHUTDOWN_LOCK_TIMEOUT_IN_MILLIS, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    private void forceEndExchange() {
        try {
            if (!exchange.isResponseComplete()) exchange.endExchange();
        } catch (Throwable e) {
            LOGGER.warn("failed to end sse exchange on shutdown, channel={}, error={}", id, e.getMessage(), e);
        }
    }

    @Override
    public void join(String group) {
        serverSentEventContext.join(this, group);
    }

    @Override
    public void leave(String group) {
        serverSentEventContext.leave(this, group);
    }

    private boolean overCapacity() {
        return queuedEvents.get() >= SseQueueLimits.maxQueueDepth() || queuedBytes.get() >= SseQueueLimits.maxQueueBytes();
    }

    ByteBuffer poll() {
        List<byte[]> bytes = new ArrayList<>(queue.size());

        while (true) {
            var data = queue.poll();
            if (data == null) break;
            bytes.add(data);
            queuedEvents.decrementAndGet();
            queuedBytes.addAndGet(-data.length);
        }

        if (bytes.size() == 1)
            return ByteBuffer.wrap(bytes.getFirst());

        int length = 0;
        for (byte[] array : bytes) {
            length += array.length;
        }

        byte[] result = new byte[length];
        int index = 0;
        for (byte[] array : bytes) {
            System.arraycopy(array, 0, result, index, array.length);
            index += array.length;
        }

        return ByteBuffer.wrap(result);
    }

    @Nullable
    @Override
    public Object get(String key) {
        return context.get(key);
    }

    @Override
    public void put(String key, @Nullable Object value) {
        if (value == null) context.remove(key);
        else context.put(key, value);
    }

    final class WriteListener implements ChannelListener<StreamSinkChannel> {
        @Nullable
        private ByteBuffer buffer;

        @Override
        public void handleEvent(StreamSinkChannel channel) {
            try {
                lock.lock();

                if (buffer == null && queue.isEmpty()) {    // be called on browser refreshing, to notify old connection
                    if (channel.flush()) {                  // check if connection is broken, will trigger end exchange event
                        channel.suspendWrites();
                    }
                    return;
                }

                if (buffer == null) {
                    buffer = poll();
                }

                while (true) {
                    int written = channel.write(buffer);
                    boolean flushed = channel.flush();

                    // write() returns 0 once the socket buffer is full, while xnio flush() reports true for a buffer
                    // that was not drained: retrying here would pin this io thread at 100% cpu while holding the lock,
                    // so hand the channel back to the io thread and wait for the writable event instead
                    if (written == 0 || !flushed) {
                        channel.resumeWrites();
                        return;
                    }
                    if (!buffer.hasRemaining()) {
                        buffer = null;
                        channel.suspendWrites();
                        return;
                    }
                }
            } catch (Throwable e) {
                LOGGER.warn("failed to write sse message, error={}", e.getMessage(), e);
                exchange.endExchange();
            } finally {
                lock.unlock();
            }
        }
    }
}

