package ai.core.media;

import ai.core.media.domain.ImageData;
import ai.core.media.domain.ImageGenerationRequest;
import ai.core.media.domain.ImageGenerationResponse;
import ai.core.media.domain.MediaReference;
import ai.core.media.domain.Usage;
import ai.core.media.domain.VideoGenerationRequest;
import ai.core.media.domain.VideoGenerationResponse;
import ai.core.media.domain.VideoStatusResponse;
import ai.core.utils.JsonUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * @author Stephen
 */
public class KieMediaProvider implements MediaProvider {
    private static final Logger LOGGER = LoggerFactory.getLogger(KieMediaProvider.class);
    private static final String DEFAULT_UPLOAD_URL = "https://kieai.redpandaai.co";

    // docs.kie.ai model pages: seedance takes 480p/720p/1080p, wan 2.7 takes 720p/1080p
    private static final List<Integer> SEEDANCE_RESOLUTIONS = List.of(480, 720, 1080);
    private static final List<Integer> WAN_RESOLUTIONS = List.of(720, 1080);

    private static final ModelFamily DEFAULT_FAMILY =
            new ModelFamily("", KieVideoReferenceRouter.Mode.ARRAY, "image_urls", DurationType.STRING);

    // longest prefix first; the first match wins
    private static final List<ModelFamily> MODEL_FAMILIES = List.of(
            new ModelFamily("minimax-h3/reference-to-video", KieVideoReferenceRouter.Mode.ARRAY, "reference_image_urls", DurationType.INT),
            new ModelFamily("minimax-h3/image-to-video", KieVideoReferenceRouter.Mode.FIRST_LAST, "first_frame_url", DurationType.INT),
            new ModelFamily("minimax-h3/text-to-video", KieVideoReferenceRouter.Mode.NONE, null, DurationType.INT),
            new ModelFamily("wan/2-7-image-to-video", KieVideoReferenceRouter.Mode.FIRST_LAST, "first_frame_url", DurationType.INT, WAN_RESOLUTIONS),
            new ModelFamily("wan/2-7-r2v", KieVideoReferenceRouter.Mode.ARRAY, "reference_image", DurationType.INT, WAN_RESOLUTIONS),
            new ModelFamily("wan/2-7-", KieVideoReferenceRouter.Mode.NONE, null, DurationType.INT, WAN_RESOLUTIONS),
            new ModelFamily("wan/", KieVideoReferenceRouter.Mode.ARRAY, "image_urls", DurationType.STRING),
            new ModelFamily("bytedance/seedance-2", KieVideoReferenceRouter.Mode.ARRAY, "reference_image_urls", DurationType.INT, SEEDANCE_RESOLUTIONS),
            new ModelFamily("bytedance/seedance-1", KieVideoReferenceRouter.Mode.ARRAY, "input_urls", DurationType.INT, SEEDANCE_RESOLUTIONS),
            new ModelFamily("bytedance/v1-", KieVideoReferenceRouter.Mode.SINGLE, "image_url", DurationType.STRING),
            new ModelFamily("kling-2.6/", KieVideoReferenceRouter.Mode.ARRAY, "image_urls", DurationType.STRING),
            new ModelFamily("kling-3.0/", KieVideoReferenceRouter.Mode.ARRAY, "image_urls", DurationType.STRING),
            new ModelFamily("kling/v3-", KieVideoReferenceRouter.Mode.ARRAY, "image_urls", DurationType.STRING),
            new ModelFamily("kling/v2-", KieVideoReferenceRouter.Mode.SINGLE, "image_url", DurationType.STRING),
            new ModelFamily("grok-imagine/", KieVideoReferenceRouter.Mode.ARRAY, "image_urls", DurationType.STRING),
            new ModelFamily("hailuo/", KieVideoReferenceRouter.Mode.SINGLE, "image_url", DurationType.STRING),
            new ModelFamily("pixverse/", KieVideoReferenceRouter.Mode.ARRAY, "image_urls", DurationType.INT),
            new ModelFamily("happyhorse", KieVideoReferenceRouter.Mode.ARRAY, "image_urls", DurationType.INT)
    );

    // consecutive transient poll failures tolerated before giving up on a running task
    private static final int MAX_IMAGE_POLL_FAILURES = 3;

    private final Map<String, Object> defaultInputParams;
    private final KieImageInputMapper imageInputMapper;
    private final KieTaskClient client;
    // image tasks are async on KIE but the MediaProvider contract is synchronous, so generateImage polls;
    // package-private so tests do not have to wait on the production cadence
    Duration imagePollInterval = Duration.ofSeconds(2);
    // seedream high-quality multi-reference tasks run past five minutes; a task dropped at the deadline is a paid render
    // whose artifact is never collected (2026-10-04: a seedream-5-pro quality=high task was abandoned at PT5M)
    Duration imagePollTimeout = Duration.ofMinutes(10);

    public KieMediaProvider(String baseUrl, String token) {
        this(baseUrl, DEFAULT_UPLOAD_URL, token, null);
    }

    public KieMediaProvider(String baseUrl, String token, String requestExtraBody) {
        this(baseUrl, DEFAULT_UPLOAD_URL, token, requestExtraBody);
    }

    public KieMediaProvider(String baseUrl, String uploadBaseUrl, String token, String requestExtraBody) {
        this.defaultInputParams = defaultInputParams(requestExtraBody);
        this.imageInputMapper = new KieImageInputMapper(defaultInputParams, this::referenceUrls);
        this.client = new KieTaskClient(baseUrl, uploadBaseUrl, token);
    }

    /**
     * Per-family KIE contract differences (verified against docs.kie.ai model pages):
     * some families send references as an array field, some as a single image_url,
     * some as first/last frame URLs, and some accept integer durations while others
     * require string enum values. Unknown models default to the image_urls array +
     * string duration mapping.
     */
    private ModelFamily modelFamily(String model) {
        if (model == null) return DEFAULT_FAMILY;
        for (var family : MODEL_FAMILIES) {
            if (model.startsWith(family.prefix())) return family;
        }
        return DEFAULT_FAMILY;
    }

    @Override
    public ImageGenerationResponse generateImage(ImageGenerationRequest request) {
        if (request.model() == null || request.model().isBlank()) throw new IllegalArgumentException("image model is required");
        if (request.prompt() == null || request.prompt().isBlank()) throw new IllegalArgumentException("image prompt is required");
        if (request.mask() != null) throw new IllegalArgumentException("KIE image generation does not support masks");
        if (request.previousInteractionId() != null && !request.previousInteractionId().isBlank())
            throw new IllegalArgumentException("KIE image generation does not support previous_interaction_id");
        if (request.n() != null && request.n() > 1)
            throw new IllegalArgumentException("KIE image models generate one image per task, got n=" + request.n());

        var body = new LinkedHashMap<String, Object>();
        body.put("model", request.model());
        var input = imageInputMapper.input(request);
        body.put("input", input);
        mergeProviderExtra(body, input, request.providerExtra());

        var task = client.createTask(body, request.model(), MediaModelParameterHints.imageHint(request.model()), "image generation");
        var taskId = KieTaskClient.stringValue(task, "taskId");
        if (taskId == null || taskId.isBlank()) throw new IllegalStateException("KIE image task response is missing taskId");
        var images = awaitImages(taskId, request.model());
        return new ImageGenerationResponse(images, new Usage(null, images.size(), null));
    }

    private List<ImageData> awaitImages(String taskId, String model) {
        var deadline = System.nanoTime() + imagePollTimeout.toNanos();
        var failures = 0;
        while (true) {
            // always wait first: the task was created milliseconds ago and is never ready yet, and KIE
            // drops the pooled connection after createTask, so an immediate poll reuses a stale one
            sleep(imagePollInterval);
            Map<String, Object> task = null;
            try {
                task = client.recordInfo(taskId, "image status");
                failures = 0;
            } catch (RuntimeException e) {
                failures++;
                // the HTTP client runs with retryOnConnectionFailure(false) by design, so transient
                // faults are ours to absorb — dropping a task that is already running (and billed)
                // over one failed poll is far worse than polling again
                if (failures > MAX_IMAGE_POLL_FAILURES) throw e;
            }
            if (task != null) {
                var images = terminalImages(task, taskId, model);
                if (images != null) return images;
            }
            if (System.nanoTime() >= deadline) {
                // the task id is logged so an abandoned task can be reconciled upstream: it may still complete (and be
                // billed) after this call has given up, and nothing else on this path records it
                LOGGER.warn("KIE image task did not complete within {}, model={}, taskId={} — giving up on the poll; the task may still run upstream",
                        imagePollTimeout, model, taskId);
                throw new IllegalStateException("KIE image task did not complete within " + imagePollTimeout
                        + ", model=" + model + ", taskId=" + taskId);
            }
        }
    }

    /** Images once the task succeeded, null while it is still running; throws when it ended in failure. */
    private List<ImageData> terminalImages(Map<String, Object> task, String taskId, String model) {
        var state = normalizeStatus(KieTaskClient.stringValue(task, "state"));
        if ("failed".equals(state)) {
            var failMsg = KieTaskClient.stringValue(task, "failMsg");
            throw new IllegalStateException("KIE image task failed, taskId=" + taskId
                    + (failMsg == null || failMsg.isBlank() ? "" : ": " + failMsg)
                    + KieTaskClient.parameterHint(model, MediaModelParameterHints.imageHint(model), failMsg));
        }
        if (!"completed".equals(state)) return null;
        var urls = client.resultUrls(task);
        if (urls.isEmpty()) throw new IllegalStateException("completed KIE image task did not include result URLs");
        return downloadImages(urls);
    }

    // KIE result URLs expire; download eagerly so callers that persist artifacts or inline the image
    // (media jobs, GenerateImageTool) keep working after the link goes away
    private List<ImageData> downloadImages(List<String> urls) {
        var images = new ArrayList<ImageData>();
        for (var url : urls) {
            var bytes = client.download(url, "image download");
            if (bytes.length == 0) throw new IllegalStateException("downloaded KIE image is empty, url=" + url);
            images.add(new ImageData(Base64.getEncoder().encodeToString(bytes), url, null));
        }
        return images;
    }

    private void sleep(Duration duration) {
        try {
            Thread.sleep(duration.toMillis());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("interrupted while waiting for KIE image task", e);
        }
    }

    @Override
    public VideoGenerationResponse generateVideo(VideoGenerationRequest request) {
        if (request.model() == null || request.model().isBlank()) throw new IllegalArgumentException("video model is required");
        if (request.prompt() == null || request.prompt().isBlank()) throw new IllegalArgumentException("video prompt is required");
        if (request.previousInteractionId() != null && !request.previousInteractionId().isBlank())
            throw new IllegalArgumentException("KIE video generation does not support previous_video_id");

        var body = new LinkedHashMap<String, Object>();
        body.put("model", request.model());
        var input = input(request);
        body.put("input", input);
        mergeProviderExtra(body, input, request.providerExtra());

        var task = client.createTask(body, request.model(), MediaModelParameterHints.videoHint(request.model()), "video generation");
        var taskId = KieTaskClient.stringValue(task, "taskId");
        if (taskId == null || taskId.isBlank()) throw new IllegalStateException("KIE video task response is missing taskId");
        return new VideoGenerationResponse(taskId, "pending", null, null);
    }

    @Override
    public VideoStatusResponse getVideoStatus(String videoId) {
        var task = client.recordInfo(videoId, "video status");
        var state = KieTaskClient.stringValue(task, "state");
        return new VideoStatusResponse(videoId, normalizeStatus(state), KieTaskClient.intValue(task, "progress"),
                KieTaskClient.stringValue(task, "failMsg"), null, KieTaskClient.doubleValue(task, "creditsConsumed"), null, null);
    }

    @Override
    public byte[] downloadVideo(String videoId) {
        var status = getVideoStatus(videoId);
        if (!"completed".equals(status.status())) {
            throw new IllegalStateException("KIE video is not completed, state=" + status.status());
        }
        var resultUrl = firstResultUrl(videoId);
        if (resultUrl == null) throw new IllegalStateException("completed KIE task did not include result URLs");
        var bytes = client.download(resultUrl, "video download");
        if (bytes.length == 0) {
            throw new IllegalStateException("downloaded KIE video is empty");
        }
        return bytes;
    }

    private Map<String, Object> input(VideoGenerationRequest request) {
        var input = new LinkedHashMap<>(defaultInputParams);
        input.put("prompt", request.prompt());
        var family = modelFamily(request.model());
        var profile = VideoModelProfiles.lookup(request.model());
        var framesSent = false;
        if (request.inputReferences() != null && !request.inputReferences().isEmpty()) {
            framesSent = KieVideoReferenceRouter.apply(input, new KieVideoReferenceRouter.Target(request.model(), family.referenceMode(), family.referenceField(), profile),
                    request.inputReferences(), this::referenceUrls);
        }
        var aspectRatio = MediaOutputSize.aspectRatio(request.size());
        // seedance frame mode derives the aspect ratio from the frame image and rejects an explicit one
        if (framesSent && profile.frameExclusive() && !profile.frames().positional()) aspectRatio = "adaptive";
        if (aspectRatio != null) input.put("aspect_ratio", aspectRatio);
        var resolution = MediaOutputSize.resolution(request.size(), family.resolutions());
        if (resolution != null) input.put("resolution", resolution);
        if (request.seconds() != null) input.put("duration", duration(request, family, profile));
        // native audio is the reason to pick these families for dialogue; kling defaults it OFF
        if (profile.audioParam() != null) input.putIfAbsent(profile.audioParam(), Boolean.TRUE);
        return input;
    }

    // snapped to what the family accepts: a rejected 3s or 7s request helps nobody, the clip is trimmed at edit time
    private Object duration(VideoGenerationRequest request, ModelFamily family, VideoModelProfiles.Profile profile) {
        var seconds = profile.durations().snap(request.seconds());
        return family.durationType() == DurationType.INT ? seconds : String.valueOf(seconds);
    }

    private List<String> referenceUrls(List<MediaReference> references) {
        var urls = new ArrayList<String>();
        for (var reference : references) {
            if (reference.url() != null && !reference.url().isBlank()) {
                urls.add(reference.url());
            } else if (reference.b64Json() != null && !reference.b64Json().isBlank()) {
                urls.add(client.uploadReferenceImage(reference.b64Json()));
            } else {
                throw new IllegalArgumentException("video reference image requires base64 data or a URL");
            }
        }
        return urls;
    }

    private String firstResultUrl(String videoId) {
        var urls = client.resultUrls(client.recordInfo(videoId, "video status"));
        return urls.isEmpty() ? null : urls.getFirst();
    }

    private String normalizeStatus(String state) {
        if (state == null) return "processing";
        return switch (state.toLowerCase(Locale.ROOT)) {
            case "success", "succeeded", "completed", "complete" -> "completed";
            case "fail", "failed", "error", "cancelled", "canceled" -> "failed";
            default -> "processing";
        };
    }

    @SuppressWarnings("unchecked")
    private void mergeProviderExtra(Map<String, Object> body, Map<String, Object> input, String providerExtra) {
        if (providerExtra == null || providerExtra.isBlank()) return;
        Map<String, Object> extra;
        try {
            extra = (Map<String, Object>) JsonUtil.fromJson(Map.class, providerExtra);
        } catch (RuntimeException e) {
            throw new RuntimeException("invalid providerExtra JSON: " + e.getMessage(), e);
        }
        var extraInput = extra.get("input");
        if (extraInput instanceof Map<?, ?> inputMap) {
            input.putAll((Map<String, Object>) inputMap);
            var remaining = new LinkedHashMap<>(extra);
            remaining.remove("input");
            body.putAll(remaining);
        } else {
            body.putAll(extra);
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> defaultInputParams(String requestExtraBody) {
        if (requestExtraBody == null || requestExtraBody.isBlank()) return new LinkedHashMap<>();
        try {
            var extra = (Map<String, Object>) JsonUtil.fromJson(Map.class, requestExtraBody);
            var input = extra.get("input");
            if (input instanceof Map<?, ?> inputMap) return new LinkedHashMap<>((Map<String, Object>) inputMap);
            return new LinkedHashMap<>(extra);
        } catch (RuntimeException e) {
            throw new RuntimeException("invalid request extra body JSON: " + e.getMessage(), e);
        }
    }

    private enum DurationType { INT, STRING }

    /**
     * @param resolutions short-side tiers this family accepts, largest-wins against the requested size.
     *                    Empty means "not verified against the model page": no resolution is sent and the
     *                    model uses its own default, which is what happened for every family before.
     */
    private record ModelFamily(String prefix, KieVideoReferenceRouter.Mode referenceMode, String referenceField, DurationType durationType,
                               List<Integer> resolutions) {
        ModelFamily(String prefix, KieVideoReferenceRouter.Mode referenceMode, String referenceField, DurationType durationType) {
            this(prefix, referenceMode, referenceField, durationType, List.of());
        }
    }
}
