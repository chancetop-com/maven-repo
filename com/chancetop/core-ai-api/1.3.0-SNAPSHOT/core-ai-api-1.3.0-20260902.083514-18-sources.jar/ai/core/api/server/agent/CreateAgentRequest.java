package ai.core.api.server.agent;

import ai.core.api.server.tool.ToolRefView;
import core.framework.api.json.Property;
import core.framework.api.validate.NotNull;

import java.util.List;
import java.util.Map;

/**
 * @author stephen
 */
public class CreateAgentRequest {
    @NotNull
    @Property(name = "name")
    public String name;

    @Property(name = "description")
    public String description;

    @Property(name = "system_prompt")
    public String systemPrompt;

    @Property(name = "system_prompt_id")
    public String systemPromptId;

    @Property(name = "model")
    public String model;

    @Property(name = "multi_modal_model")
    public String multiModalModel;

    @Property(name = "prefer_caption_path")
    public Boolean preferCaptionPath;

    @Property(name = "temperature")
    public Double temperature;

    @Property(name = "thinking_effort")
    public String thinkingEffort;

    @Property(name = "max_turns")
    public Integer maxTurns;

    @Property(name = "timeout_seconds")
    public Integer timeoutSeconds;

    @Property(name = "enable_memory")
    public Boolean enableMemory;

    @Property(name = "tools")
    public List<ToolRefView> tools;

    @Property(name = "input_template")
    public String inputTemplate;

    @Property(name = "variables")
    public Map<String, String> variables;

    @Property(name = "type")
    public String type;

    @Property(name = "response_schema")
    public String responseSchema;

    @Property(name = "subagent_ids")
    public List<String> subAgentIds;

    @Property(name = "skill_ids")
    public List<String> skillIds;

    @Property(name = "sandbox_config")
    public SandboxConfigView sandboxConfig;

    @Property(name = "dataset_config")
    public List<AgentDatasetConfigView> datasetConfig;

    @Property(name = "system_default")
    public Boolean systemDefault;
}
