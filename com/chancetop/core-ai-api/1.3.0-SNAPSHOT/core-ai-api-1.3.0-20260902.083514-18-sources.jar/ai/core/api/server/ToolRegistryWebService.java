package ai.core.api.server;

import ai.core.api.server.tool.BuiltinGroupToolsResponse;
import ai.core.api.server.tool.CreateMcpServerRequest;
import ai.core.api.server.tool.ImportMcpServersRequest;
import ai.core.api.server.tool.ImportMcpServersResponse;
import ai.core.api.server.tool.ListApiAppServicesResponse;
import ai.core.api.server.tool.ListApiAppsResponse;
import ai.core.api.server.tool.ListToolCategoriesResponse;
import ai.core.api.server.tool.ListToolsRequest;
import ai.core.api.server.tool.ListToolsResponse;
import ai.core.api.server.tool.McpServerStatusResponse;
import ai.core.api.server.tool.McpServerToolsResponse;
import ai.core.api.server.tool.TestApiToolRequest;
import ai.core.api.server.tool.TestApiToolResponse;
import ai.core.api.server.tool.TestMcpToolRequest;
import ai.core.api.server.tool.TestMcpToolResponse;
import ai.core.api.server.tool.ToolRegistryView;
import ai.core.api.server.tool.UpdateMcpServerRequest;
import core.framework.api.web.service.DELETE;
import core.framework.api.web.service.GET;
import core.framework.api.web.service.POST;
import core.framework.api.web.service.PUT;
import core.framework.api.web.service.Path;
import core.framework.api.web.service.PathParam;

/**
 * @author stephen
 */
public interface ToolRegistryWebService {
    @GET
    @Path("/api/tools")
    ListToolsResponse list(ListToolsRequest request);

    @GET
    @Path("/api/tools/categories")
    ListToolCategoriesResponse categories();

    @GET
    @Path("/api/tools/:id")
    ToolRegistryView get(@PathParam("id") String id);

    @POST
    @Path("/api/tools/mcp-servers")
    ToolRegistryView createMcpServer(CreateMcpServerRequest request);

    @POST
    @Path("/api/tools/mcp-servers/import")
    ImportMcpServersResponse importMcpServers(ImportMcpServersRequest request);

    @PUT
    @Path("/api/tools/mcp-servers/:id")
    ToolRegistryView updateMcpServer(@PathParam("id") String id, UpdateMcpServerRequest request);

    @DELETE
    @Path("/api/tools/mcp-servers/:id")
    void deleteMcpServer(@PathParam("id") String id);

    @PUT
    @Path("/api/tools/mcp-servers/:id/enable")
    ToolRegistryView enableMcpServer(@PathParam("id") String id);

    @PUT
    @Path("/api/tools/mcp-servers/:id/disable")
    ToolRegistryView disableMcpServer(@PathParam("id") String id);

    @GET
    @Path("/api/tools/mcp-servers/:id/tools")
    McpServerToolsResponse listMcpServerTools(@PathParam("id") String id);

    @GET
    @Path("/api/tools/builtin/:id/tools")
    BuiltinGroupToolsResponse listBuiltinGroupTools(@PathParam("id") String id);

    @GET
    @Path("/api/tools/mcp-servers/:id/status")
    McpServerStatusResponse getMcpServerStatus(@PathParam("id") String id);

    @POST
    @Path("/api/tools/mcp-servers/:id/connect")
    McpServerStatusResponse connectMcpServer(@PathParam("id") String id);

    @POST
    @Path("/api/tools/mcp-servers/:id/test-tool")
    TestMcpToolResponse testMcpServerTool(@PathParam("id") String id, TestMcpToolRequest request);

    @GET
    @Path("/api/tools/service-api/apps")
    ListApiAppsResponse listServiceApiApps();

    @GET
    @Path("/api/tools/service-api/apps/:appName/services")
    ListApiAppServicesResponse listApiAppServices(@PathParam("appName") String appName);

    @POST
    @Path("/api/tools/service-api/test-tool")
    TestApiToolResponse testServiceApiTool(TestApiToolRequest request);
}
