package ai.core.api.session;

import core.framework.api.json.Property;
import core.framework.api.validate.NotNull;

/**
 * @author stephen
 */
public class ApproveToolCallRequest {
    @NotNull
    @Property(name = "callId")
    public String callId;

    @NotNull
    @Property(name = "decision")
    public ApprovalDecision decision;
}
