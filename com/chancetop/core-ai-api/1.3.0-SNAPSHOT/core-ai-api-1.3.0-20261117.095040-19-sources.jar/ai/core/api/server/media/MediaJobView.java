package ai.core.api.server.media;

import core.framework.api.json.Property;

import java.time.ZonedDateTime;
import java.util.List;

/**
 * @author stephen
 */
public class MediaJobView {
    @Property(name = "id")
    public String id;

    @Property(name = "userId")
    public String userId;

    @Property(name = "userName")
    public String userName;

    @Property(name = "providerId")
    public String providerId;

    @Property(name = "requestedModel")
    public String requestedModel;

    @Property(name = "resolvedModel")
    public String resolvedModel;

    @Property(name = "prompt")
    public String prompt;

    /** The references, mask and edited-from video this generation ran with; empty for text-to-image runs. */
    @Property(name = "inputs")
    public List<MediaJobInputView> inputs;

    @Property(name = "requestedSize")
    public String requestedSize;

    @Property(name = "requestedQuality")
    public String requestedQuality;

    @Property(name = "requestedCount")
    public Integer requestedCount;

    @Property(name = "outputFormat")
    public String outputFormat;

    @Property(name = "outputCompression")
    public Integer outputCompression;

    @Property(name = "background")
    public String background;

    @Property(name = "mediaType")
    public String mediaType;

    @Property(name = "state")
    public String state;

    @Property(name = "requestedSeconds")
    public Integer requestedSeconds;

    @Property(name = "mediaUnits")
    public Double mediaUnits;

    @Property(name = "mediaUnitType")
    public String mediaUnitType;

    @Property(name = "creditsConsumed")
    public Double creditsConsumed;

    @Property(name = "costUsd")
    public Double costUsd;

    @Property(name = "costSource")
    public String costSource;

    @Property(name = "pricingModelId")
    public String pricingModelId;

    @Property(name = "progress")
    public Integer progress;

    @Property(name = "error")
    public String error;

    @Property(name = "fileId")
    public String fileId;

    @Property(name = "fileName")
    public String fileName;

    @Property(name = "contentType")
    public String contentType;

    @Property(name = "artifactState")
    public String artifactState;

    @Property(name = "artifactError")
    public String artifactError;

    @Property(name = "artifactSize")
    public Long artifactSize;

    @Property(name = "posterFileId")
    public String posterFileId;

    @Property(name = "posterUrl")
    public String posterUrl;

    @Property(name = "durationSeconds")
    public Double durationSeconds;

    @Property(name = "playable")
    public Boolean playable;

    @Property(name = "contentUrl")
    public String contentUrl;

    @Property(name = "createdAt")
    public ZonedDateTime createdAt;

    @Property(name = "completedAt")
    public ZonedDateTime completedAt;
}
