package ai.core.api.server;

import ai.core.api.server.agent.AgentDefinitionView;
import ai.core.api.server.agent.AgentQualityReportView;
import ai.core.api.server.agent.AgentQualityRunListResponse;
import ai.core.api.server.agent.ConvertJavaToSchemaRequest;
import ai.core.api.server.agent.ConvertJavaToSchemaResponse;
import ai.core.api.server.agent.CreateAgentRequest;
import ai.core.api.server.agent.ExportAgentResponse;
import ai.core.api.server.agent.ImportAgentRequest;
import ai.core.api.server.agent.ImportAgentResponse;
import ai.core.api.server.agent.ListAgentsRequest;
import ai.core.api.server.agent.ListAgentsResponse;
import ai.core.api.server.agent.UpdateAgentRequest;
import ai.core.api.server.utils.GenerateRequest;
import ai.core.api.server.utils.GenerateResponse;
import core.framework.api.http.HTTPStatus;
import core.framework.api.web.service.DELETE;
import core.framework.api.web.service.GET;
import core.framework.api.web.service.POST;
import core.framework.api.web.service.PUT;
import core.framework.api.web.service.Path;
import core.framework.api.web.service.PathParam;
import core.framework.api.web.service.ResponseStatus;

/**
 * @author stephen
 */
public interface AgentDefinitionWebService {
    @POST
    @Path("/api/agents")
    @ResponseStatus(HTTPStatus.CREATED)
    AgentDefinitionView create(CreateAgentRequest request);

    @GET
    @Path("/api/agents")
    ListAgentsResponse list(ListAgentsRequest request);

    @GET
    @Path("/api/agents/favorites")
    ListAgentsResponse favorites();

    @POST
    @Path("/api/agents/:id/favorite")
    void favorite(@PathParam("id") String id);

    @DELETE
    @Path("/api/agents/:id/favorite")
    void unfavorite(@PathParam("id") String id);

    @GET
    @Path("/api/agents/:id")
    AgentDefinitionView get(@PathParam("id") String id);

    @GET
    @Path("/api/agents/:id/export")
    ExportAgentResponse export(@PathParam("id") String id);

    @POST
    @Path("/api/agents/import")
    ImportAgentResponse importAgent(ImportAgentRequest request);

    @GET
    @Path("/api/agents/name/:name")
    AgentDefinitionView getByName(@PathParam("name") String name);

    @PUT
    @Path("/api/agents/:id")
    AgentDefinitionView update(@PathParam("id") String id, UpdateAgentRequest request);

    @POST
    @Path("/api/agents/:id/publish")
    AgentDefinitionView publish(@PathParam("id") String id);

    @POST
    @Path("/api/agents/:id/quality-checks")
    AgentQualityReportView checkQuality(@PathParam("id") String id);

    @GET
    @Path("/api/agents/:id/quality-checks")
    AgentQualityRunListResponse qualityRuns(@PathParam("id") String id);

    /**
     * {@code runId} may be literal {@code latest}: the editor reads the newest report after a publish
     * that returned WARN results without remembering a run id.
     */
    @GET
    @Path("/api/agents/:id/quality-checks/:runId")
    AgentQualityReportView qualityReport(@PathParam("id") String id, @PathParam("runId") String runId);

//    @POST
//    @Path("/api/agents/from-session")
//    @ResponseStatus(HTTPStatus.CREATED)
//    AgentDefinitionView createFromSession(CreateAgentFromSessionRequest request);

    @DELETE
    @Path("/api/agents/:id")
    void delete(@PathParam("id") String id);

    @POST
    @Path("/api/utils/java-to-schema")
    ConvertJavaToSchemaResponse convertJavaToSchema(ConvertJavaToSchemaRequest request);

    @POST
    @Path("/api/utils/generate")
    GenerateResponse generate(GenerateRequest request);
}
