package ai.core.api.server.schedule;

import core.framework.api.json.Property;
import core.framework.api.validate.NotNull;

import java.util.Map;

/**
 * @author stephen
 */
public class CreateScheduleRequest {
    @NotNull
    @Property(name = "agent_id")
    public String agentId;

    @Property(name = "name")
    public String name;

    @Property(name = "remark")
    public String remark;

    @NotNull
    @Property(name = "cron_expression")
    public String cronExpression;

    @Property(name = "timezone")
    public String timezone;

    @Property(name = "input")
    public String input;

    @Property(name = "variables")
    public Map<String, String> variables;

    @Property(name = "channel_id")
    public String channelId;

    @Property(name = "channel_recipient_id")
    public String channelRecipientId;

    // optional project binding: runs and their artifacts are attributed to this subject deterministically
    @Property(name = "project_id")
    public String projectId;

    @Property(name = "subject_id")
    public String subjectId;

    @Property(name = "concurrency_policy")
    public String concurrencyPolicy;
}
