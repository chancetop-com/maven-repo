package ai.core.api.server.auth;

import ai.core.api.server.apiuser.request.UpdateApiUserConfigRequest;
import ai.core.api.server.user.GenerateApiKeyResponse;
import core.framework.api.http.HTTPStatus;
import core.framework.api.web.service.GET;
import core.framework.api.web.service.POST;
import core.framework.api.web.service.PUT;
import core.framework.api.web.service.Path;
import core.framework.api.web.service.PathParam;
import core.framework.api.web.service.ResponseStatus;

/**
 * @author stephen
 */
public interface AuthWebService {
    @POST
    @Path("/api/auth/register")
    @ResponseStatus(HTTPStatus.CREATED)
    RegisterResponse register(RegisterRequest request);

    @POST
    @Path("/api/auth/login")
    LoginResponse login(LoginRequest request);

    @POST
    @Path("/api/auth/logout")
    void logout();

    @GET
    @Path("/api/auth/me")
    UserProfileView me();

    @POST
    @Path("/api/auth/invite")
    void invite(InviteRequest request);

    @GET
    @Path("/api/auth/users")
    ListUsersResponse listUsers();

    @PUT
    @Path("/api/auth/users/:userId/config")
    @ResponseStatus(HTTPStatus.OK)
    void updateUserConfig(@PathParam("userId") String userId, UpdateApiUserConfigRequest request);

    @POST
    @Path("/api/auth/users/:userId/quota/reset")
    @ResponseStatus(HTTPStatus.OK)
    void resetUserQuota(@PathParam("userId") String userId);

    @POST
    @Path("/api/auth/users/update-status")
    void updateUserStatus(UpdateUserStatusRequest request);

    @POST
    @Path("/api/auth/users/delete")
    void deleteUser(DeleteUserRequest request);

    @POST
    @Path("/api/auth/users/generate-api-key")
    GenerateApiKeyResponse generateApiKeyForUser(GenerateApiKeyForUserRequest request);

    @POST
    @Path("/api/auth/users/revoke-api-key")
    void revokeApiKey(RevokeApiKeyRequest request);

    @POST
    @Path("/api/auth/users/update-role")
    void updateUserRole(UpdateUserRoleRequest request);

    @POST
    @Path("/api/auth/users/reset-password")
    void resetUserPassword(ResetUserPasswordRequest request);
}
