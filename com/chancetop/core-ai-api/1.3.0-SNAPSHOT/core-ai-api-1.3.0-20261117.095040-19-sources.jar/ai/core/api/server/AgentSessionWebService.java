package ai.core.api.server;

import ai.core.api.server.agent.GenerateAgentDraftResponse;
import ai.core.api.server.session.ApproveToolCallRequest;
import ai.core.api.server.session.CreateSessionRequest;
import ai.core.api.server.session.CreateSessionResponse;
import ai.core.api.server.session.LoadSkillsRequest;
import ai.core.api.server.session.LoadSkillsResponse;
import ai.core.api.server.session.LoadSubAgentsRequest;
import ai.core.api.server.session.LoadSubAgentsResponse;
import ai.core.api.server.session.LoadToolsRequest;
import ai.core.api.server.session.LoadToolsResponse;
import ai.core.api.server.session.SendMessageRequest;
import ai.core.api.server.session.SessionHistoryResponse;
import ai.core.api.server.session.SessionInfo;
import ai.core.api.server.session.SessionStatusResponse;
import ai.core.api.server.session.UnloadSkillsRequest;
import ai.core.api.server.session.UnloadSkillsResponse;
import core.framework.api.http.HTTPStatus;
import core.framework.api.web.service.DELETE;
import core.framework.api.web.service.GET;
import core.framework.api.web.service.POST;
import core.framework.api.web.service.Path;
import core.framework.api.web.service.PathParam;
import core.framework.api.web.service.ResponseStatus;

/**
 * @author stephen
 */
public interface AgentSessionWebService {
    @POST
    @Path("/api/sessions")
    @ResponseStatus(HTTPStatus.CREATED)
    CreateSessionResponse create(CreateSessionRequest request);

    @POST
    @Path("/api/sessions/:sessionId/messages")
    void sendMessage(@PathParam("sessionId") String sessionId, SendMessageRequest request);

    @POST
    @Path("/api/sessions/:sessionId/approve")
    void approve(@PathParam("sessionId") String sessionId, ApproveToolCallRequest request);

    @GET
    @Path("/api/sessions/:sessionId")
    SessionInfo getInfo(@PathParam("sessionId") String sessionId);

    @GET
    @Path("/api/sessions/:sessionId/history")
    SessionHistoryResponse history(@PathParam("sessionId") String sessionId);

    @GET
    @Path("/api/sessions/:sessionId/status")
    SessionStatusResponse status(@PathParam("sessionId") String sessionId);

    @POST
    @Path("/api/sessions/:sessionId/cancel")
    void cancel(@PathParam("sessionId") String sessionId);

    @POST
    @Path("/api/sessions/:sessionId/generate-agent-draft")
    GenerateAgentDraftResponse generateAgentDraft(@PathParam("sessionId") String sessionId);

    @POST
    @Path("/api/sessions/:sessionId/tools")
    @ResponseStatus(HTTPStatus.CREATED)
    LoadToolsResponse loadTools(@PathParam("sessionId") String sessionId, LoadToolsRequest request);

    @POST
    @Path("/api/sessions/:sessionId/skills")
    @ResponseStatus(HTTPStatus.CREATED)
    LoadSkillsResponse loadSkills(@PathParam("sessionId") String sessionId, LoadSkillsRequest request);

    @POST
    @Path("/api/sessions/:sessionId/skills/remove")
    UnloadSkillsResponse unloadSkills(@PathParam("sessionId") String sessionId, UnloadSkillsRequest request);

    @POST
    @Path("/api/sessions/:sessionId/subagents")
    @ResponseStatus(HTTPStatus.CREATED)
    LoadSubAgentsResponse loadSubAgents(@PathParam("sessionId") String sessionId, LoadSubAgentsRequest request);

    @DELETE
    @Path("/api/sessions/:sessionId")
    void close(@PathParam("sessionId") String sessionId);
}
